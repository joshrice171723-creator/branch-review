"""Own a coordinator process and its descendants on behalf of Workbench chat."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import uuid

from activity import publish


def process_group():
    return {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP} if os.name == "nt" else {"start_new_session": True}


class WindowsProcessGroup:
    def __init__(self, proc):
        import ctypes
        from ctypes import wintypes
        self.kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        self.kernel.CreateJobObjectW.argtypes = [wintypes.LPVOID, wintypes.LPCWSTR]
        self.kernel.CreateJobObjectW.restype = wintypes.HANDLE
        self.kernel.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
        self.kernel.TerminateJobObject.argtypes = [wintypes.HANDLE, wintypes.UINT]
        self.kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        self.handle = self.kernel.CreateJobObjectW(None, None)
        if not self.handle:
            raise ctypes.WinError(ctypes.get_last_error())
        if not self.kernel.AssignProcessToJobObject(self.handle, int(proc._handle)):
            error = ctypes.WinError(ctypes.get_last_error())
            self.close()
            raise error

    def terminate(self):
        if not self.kernel.TerminateJobObject(self.handle, 1):
            import ctypes
            raise ctypes.WinError(ctypes.get_last_error())

    def close(self):
        self.kernel.CloseHandle(self.handle)


class WorkflowJob:
    def __init__(self, project, task_id, message, answer, codex):
        self.id = uuid.uuid4().hex
        self.log_dir = project / ".harness/chat" / task_id / self.id
        self.log_dir.mkdir(parents=True)
        self.record = dict(id=self.id, task_id=task_id, user_message=message, state="starting",
                           started_at=datetime.now(timezone.utc).isoformat(), events=[], next_cursor=0)
        command = [sys.executable, str(Path(__file__).with_name("audited_flow.py")),
                   "--project", str(project), "--id", task_id]
        if answer:
            command += ["--answer=" + answer]
        if codex:
            command += ["--codex", str(codex)]
        self.group = None
        self.lock = threading.Lock()
        if os.name == "nt":
            command.append("--owned-start")
        self.write("turn.json")
        self.proc = subprocess.Popen(command, cwd=project, stdin=subprocess.PIPE if os.name == "nt" else subprocess.DEVNULL, stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE, text=True, encoding="utf-8", **process_group())
        if os.name == "nt":
            try:
                self.group = WindowsProcessGroup(self.proc)
            except OSError:
                self.proc.kill()
                self.proc.communicate()
                raise
        self.record["state"] = "running"
        self.worker = threading.Thread(target=self.collect, daemon=True)
        self.worker.start()

    def write(self, name):
        path = self.log_dir / name
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.record), encoding="utf-8")
        tmp.replace(path)

    def collect(self):
        out, error = self.proc.communicate(input="run\n" if self.group else None)
        with self.lock:
            cancelled = self.record["state"] == "cancelling"
            if self.group:
                self.group.close()
        state = "cancelled" if cancelled else "failed" if self.proc.returncode else "completed"
        if cancelled:
            folder = self.log_dir.parents[2] / "loops" / self.record["task_id"]
            try:
                stage = json.loads((folder / "state.json").read_text(encoding="utf-8"))["stage"]
            except (OSError, ValueError, KeyError):
                stage = "plan"
            publish(folder, stage, "Workbench", "Run cancelled")
        self.record.update(response=out.strip(), error=error.strip(), exit_code=self.proc.returncode, state=state)
        self.write("result.json")

    def cancel(self):
        with self.lock:
            if self.proc.poll() is not None:
                return False
            if self.group:
                self.group.terminate()
            else:
                try:
                    os.killpg(self.proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    return False
            self.record["state"] = "cancelling"
        return True

    def wait(self, timeout=None):
        self.worker.join(timeout)
        return self.snapshot()

    def snapshot(self, after=0):
        return self.record.copy()
