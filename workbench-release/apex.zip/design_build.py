"""Run approved task plans and roadmap slices with exact-commit review."""
import json
import hashlib
import os
import subprocess
from contextlib import ExitStack, contextmanager
from datetime import datetime

from audited_flow import owned
from chat_workflow import load, write_json
from design_workspace import TASK_MEMBER, TASK_MODE, Workspace, identifier, now, required
from design_host import approved_review, check_project, group_review, origin_for, push_approved
from design_progress import running

CHECKLIST = ["Inspect the commit diff", "Check the included slices", "Review the recorded check results"]
QUALITY_POLICY_FILE = "workbench-quality.json"


def policy_sha(root):
    policy = root / QUALITY_POLICY_FILE
    if policy.resolve() != policy:
        raise ValueError("The Quality policy must belong to this checkout.")
    return hashlib.sha256(policy.read_bytes()).hexdigest() if policy.is_file() else None


def check_preserved_policy(root, saved):
    if "preservedPolicySha" in saved and policy_sha(root) != saved["preservedPolicySha"]:
        raise ValueError("The published Quality policy changed during this build. Restore it or start a new build.")


def git(root, *args, stdin=None):
    result = subprocess.run(["git", *args], cwd=root, capture_output=True, text=True, encoding="utf-8",
                            input=stdin, errors="replace", timeout=90, env=dict(os.environ, GIT_TERMINAL_PROMPT="0"))
    if result.returncode:
        raise ValueError(result.stderr.strip() or "Git could not complete this operation.")
    return result.stdout.rstrip("\r\n")


def validate_branch(root, branch):
    if not isinstance(branch, str) or branch.startswith("-") or not branch:
        raise ValueError("Configure a destination branch.")
    git(root, "check-ref-format", "refs/heads/" + branch)


def local_changes(root):
    status = git(root, "status", "--porcelain", "-z", "--no-renames", "--untracked-files=all",
                 "--", ".", ":(exclude).harness")
    return {entry[3:]: entry[:2] for entry in status.split("\0") if entry and not entry.startswith("?? .idea/")}


def index_entries(root, paths):
    if not paths:
        return {}
    records = git(root, "ls-files", "--stage", "-z").split("\0")
    entries = {}
    for record in filter(None, records):
        metadata, path = record.split("\t", 1)
        if path in paths:
            entries.setdefault(path, []).append(metadata)
    return entries


def checkout(root, branch, preserved, preserved_index):
    validate_branch(root, branch)
    if git(root, "symbolic-ref", "--quiet", "--short", "HEAD") != branch:
        raise ValueError("Check out the configured project branch.")
    if local_changes(root) != preserved or index_entries(root, preserved) != preserved_index:
        raise ValueError("The working changes differ from the recorded project baseline.")
    return git(root, "rev-parse", "--verify", "HEAD^{commit}")


def commit_checked_slice(rt, fingerprint, target):
    """Stage only Git changes present in the coordinator's checked source delta."""
    branch = target["branch"]
    if git(rt.project, "symbolic-ref", "--short", "HEAD") != branch:
        raise ValueError("Restore the reviewed project branch.")
    git(rt.project, "merge-base", "--is-ancestor", target["base"], "HEAD")
    dirty = local_changes(rt.project)
    preserved = target.get("preserved", {})
    preserved_index = target.get("preserved_index", {})
    paths = [path for path in dirty if path not in preserved]
    check_preserved_policy(rt.project, target)
    if paths or preserved:
        if git(rt.project, "rev-parse", "HEAD") != target["base"]:
            raise ValueError("The branch advanced during the build. Inspect the commit before continuing.")
        before = rt.task["initial_snapshot"]["files"]
        snapshots = rt.record / "snapshots"
        checked = load(snapshots / (fingerprint[:20] + ".json"), {})
        if checked.get("snapshot_sha256") != fingerprint:
            checked = load(snapshots / (fingerprint + ".json"), {})
        if checked.get("snapshot_sha256") != fingerprint:
            raise ValueError("The checked source snapshot is missing.")
        after = checked["files"]
        if (index_entries(rt.project, preserved) != preserved_index or
                any(before.get(path) != after.get(path) or dirty.get(path) != status
                    for path, status in preserved.items())):
            raise ValueError("The slice overlaps existing working changes. Inspect these files before continuing.")
        if any(before.get(path) == after.get(path) for path in paths):
            raise ValueError("The Git changes include files outside the checked slice.")
        if rt.status()["snapshot_sha256"] != fingerprint:
            raise ValueError("The checked source changed before the local commit.")
    if paths:
        names = "\0".join(paths) + "\0"
        pathspec = ["--pathspec-from-file=-", "--pathspec-file-nul"]
        git(rt.project, "--literal-pathspecs", "add", "-A", *pathspec, stdin=names)
        git(rt.project, "--literal-pathspecs", "commit", "--only", "-m", rt.task["action"], *pathspec, stdin=names)
    sha = checkout(rt.project, branch, preserved, preserved_index)
    if sha in target["rejected"]:
        raise ValueError("Commit the repair before requesting another Branch Review.")
    if target.get("mode") == TASK_MODE and sha == target["base"]:
        raise ValueError("The task must produce a checked commit before Branch Review.")
    return sha


def resolve_groups(milestones, scope, key, frequency):
    if scope not in {"plan", "milestone", "slice"} or frequency not in {"slice", "milestone", "plan"}:
        raise ValueError("Select a build scope and review frequency.")
    groups = []
    for milestone in milestones:
        if scope == "milestone" and milestone["id"] != key:
            continue
        members = [s["id"] for s in milestone["slices"] if scope != "slice" or s["id"] == key]
        if members:
            groups.extend([[s] for s in members] if frequency == "slice" else [members])
    if not groups:
        raise ValueError("The approved roadmap does not contain this scope.")
    return [[s for group in groups for s in group]] if frequency == "plan" else groups


class Builds:
    def __init__(self, app):
        self.app = app
        self.workspace = Workspace(app)
        self.root = self.workspace.root

    def readiness(self):
        from quality import Quality

        state = self.workspace.read()
        home = self.root / ".harness"
        items = []

        def add(key, ready, yes, no):
            items.append(dict(id=key, status="ready" if ready else "blocked", message=yes if ready else no))

        add("plan", state["approved"] == state["revision"] and not (state["question"] or state.get("plannerRetry")),
            "The current draft is approved.", "Resolve planning and approve the current draft.")
        profile = None
        checks = []
        try:
            if not (home / "profile.disabled").exists():
                applied = load(home / "profile.json")
                if applied and isinstance(applied["profiles"][applied["active"]]["stages"], dict):
                    profile = applied
                    checks = applied["checks"]
        except (KeyError, TypeError, OSError, ValueError):
            profile = None
        add("profile", bool(profile), "A workflow profile is applied.", "Apply a valid workflow profile.")
        checks_ready = isinstance(checks, list) and any(isinstance(check, dict) and check.get("name") and
                                                       (check.get("required") or check.get("benchmark")) for check in checks)
        checks_message = "Configure a required project check or benchmark."
        try:
            quality = Quality(self.root).publication()
            if quality:
                definition = quality["definition"]
                checks_ready = any(check["required"] for check in definition["checks"]) or bool(definition["benchmarks"])
                checks_message = "Publish a Quality policy with a required check or benchmark."
        except (OSError, ValueError) as exc:
            checks_ready, checks_message = False, str(exc)
        add("checks", checks_ready, "Required project checks are configured.", checks_message)
        try:
            branch = state["branch"]
            validate_branch(self.root, branch)
            branch_ready = git(self.root, "symbolic-ref", "--quiet", "--short", "HEAD") == branch
            git(self.root, "rev-parse", "--verify", "HEAD^{commit}")
        except (OSError, ValueError, subprocess.SubprocessError):
            branch_ready = False
        add("branch", branch_ready, "The configured branch is checked out.", "Check out the configured branch with a commit.")
        try:
            origin = origin_for(self.root, state)
            if not origin:
                raise ValueError("Connect Branch Review before reviewing the checked commit.")
            check_project(self.root, origin)
            review_ready, review_message = True, "Branch Review is connected to this project."
        except (OSError, ValueError) as exc:
            review_ready, review_message = False, str(exc)
        add("review", review_ready, review_message, review_message)
        build = state["builds"][-1] if state["builds"] else {}
        active = self.app.active() or {}
        native_ready = (build.get("status") in {None, "closed", "retired"} and not self.app.busy() and
                        active.get("status") not in {"active", "unverified"} and not self.owns_run(active.get("id")))
        add("native", native_ready, "No unfinished build or active native task.", "Finish or pause the current build or native task.")
        return dict(ready=all(item["status"] == "ready" for item in items if item["id"] != "review"), items=items)

    def loop_folder(self, task):
        return self.root / ".harness" / "loops" / task

    def owns_run(self, task):
        return bool(task and running(self.loop_folder(task)))

    @contextmanager
    def coordinator_launch(self, task):
        with ExitStack() as stack:
            try:
                stack.enter_context(owned(self.loop_folder(task) / "launch"))
            except (BlockingIOError, PermissionError) as exc:
                raise ValueError("The coordinator is already starting.") from exc
            if self.owns_run(task):
                raise ValueError("The coordinator still owns this run.")
            builds = self.workspace.read()["builds"]
            build = builds[-1] if builds else {}
            attempt = build["attempts"][-1] if build.get("attempts") else {}
            target = load(self.loop_folder(task) / "design.json")
            if target and (target.get("build") != build.get("id") or attempt.get("task") != task):
                raise ValueError("Select a current Design build.")
            if attempt.get("task") == task:
                if build["status"] in {"closed", "retired", "cancelled"}:
                    raise ValueError("Continue or select a current Design build.")
                if build["status"] in {"working", "cancelling"} and attempt.get("job"):
                    raise ValueError("Reconnect the recorded Design run before starting another.")
            yield

    def native_action(self, action, task, reason=None):
        args = ["task", action, "--id", task]
        if reason:
            args.extend(["--reason", reason])
        self.app.require_success(self.app.cli(args))

    def cancel(self, key):
        with self.app.lock, self.workspace.edit() as state:
            build = self.current(state, key)
            if build["status"] in {"cancelling", "cancelled"}:
                return state
            if build["status"] != "working":
                raise ValueError("Select the active Design run.")
            attempt = build["attempts"][-1]
            job = self.app.jobs.get(attempt.get("job"))
            if not job or getattr(job, "record", {}).get("task_id") != attempt["task"]:
                raise ValueError("This panel does not own the coordinator. Reconnect after the run stops.")
            if job.cancel():
                build["status"] = "cancelling"
            return state

    def history(self, state=None):
        state = state or self.workspace.read()
        rows = []
        home = self.root / ".harness"
        for build in state["builds"]:
            loops = {}
            for attempt in build["attempts"]:
                tid = attempt["task"]
                if tid not in loops:
                    loops[tid] = load(home / "loops" / tid / "state.json", {})
                loop = loops[tid]
                job = self.app.jobs.get(attempt.get("job"))
                result = job.snapshot() if job else {}
                if not job and attempt["outcome"] == "running" and attempt.get("job"):
                    result = load(home / "chat" / tid / attempt["job"] / "result.json", {})
                    if not result and self.owns_run(tid):
                        result = {"state": "running"}
                start = datetime.fromisoformat(attempt["started"]).timestamp()
                end = datetime.fromisoformat(attempt["finished"]).timestamp() if attempt.get("finished") else float("inf")
                entries = [h for h in loop.get("history", []) if start <= h["time"] <= end]
                active = result.get("state") == "running" and bool(entries)
                outcome = result.get("state") if attempt["outcome"] == "running" else attempt["outcome"]
                transitions = []
                counts = {}
                for idx, event in enumerate(entries):
                    stage = event["stage"]
                    counts[stage] = counts.get(stage, 0) + 1
                    detail = event.get("detail")
                    next_step = entries[idx + 1] if idx + 1 < len(entries) else None
                    reason = detail if isinstance(detail, str) and stage in {"build", "plan", "stopped"} else ""
                    verdict = "advanced" if next_step else outcome or "interrupted"
                    if next_step and isinstance(next_step.get("detail"), dict):
                        verdict = next_step["detail"].get("verdict", verdict)
                    transitions.append(dict(stage=stage, time=event["time"], number=counts[stage],
                                            outcome=verdict, reason=reason))
                rows.append(dict(attempt, build=build["id"], active=active, outcome=outcome or "interrupted",
                                 title=next(s["title"] for m in build["roadmap"] for s in m["slices"] if s["id"] == attempt["slice"]),
                                 step=loop.get("stage") if active else attempt.get("step"),
                                 transitions=transitions))
        return rows

    def evidence(self, key, index):
        build = self.current(self.workspace.read(), key)
        if not 0 <= index < len(build["groups"]):
            raise ValueError("Unknown review group.")
        group = build["groups"][index]
        if not group.get("sha"):
            raise ValueError("Wait for the review commit.")
        return dict(sha=group["sha"], branch=build["branch"],
                    diff=git(self.root, "diff", "--no-ext-diff", "--no-textconv", group["base"], group["sha"], "--"))

    def launch(self, payload):
        with self.app.lock, self.workspace.edit() as state:
            self.workspace.check_revision(state, payload)
            self.workspace.check_mode(state, payload)
            if state["approved"] != state["revision"] or state["question"] or state.get("plannerRetry"):
                raise ValueError("Approve this draft revision before building.")
            if state["builds"] and state["builds"][-1]["status"] not in {"closed", "retired"}:
                raise ValueError("Finish the current build first.")
            task = self.app.active() or {}
            if self.app.busy() or task.get("status") in {"active", "unverified"} or self.owns_run(task.get("id")):
                raise ValueError("Finish or pause the active task before starting a build.")
            home = self.root / ".harness"
            if not (home / "profile.json").is_file() or (home / "profile.disabled").exists():
                raise ValueError("Apply a profile before starting a Design build.")
            profile_bytes = (home / "profile.json").read_bytes()
            profile = json.loads(profile_bytes)
            if "stages" in payload and payload["stages"] != profile["profiles"][profile["active"]]["stages"]:
                raise ValueError("The applied workflow changed. Reload the build steps.")
            preserved = local_changes(self.root)
            preserved_index = index_entries(self.root, preserved)
            base = checkout(self.root, state["branch"], preserved, preserved_index)
            task_mode = state.get("mode") == TASK_MODE
            groups = ([[TASK_MEMBER]] if task_mode else
                      resolve_groups(state["roadmap"], payload["scope"], payload.get("key"), payload.get("frequency", "slice")))
            build = dict(id=identifier(), revision=state["revision"], branch=state["branch"], index=0,
                         plan=state["plan"], roadmap=state["roadmap"], attachments=dict(state["attachments"]), base=base,
                         decisions=payload.get("decisions", {}), preserved=preserved,
                         preserved_index=preserved_index, status="ready", attempts=[],
                         profile=hashlib.sha256(profile_bytes).hexdigest(),
                         groups=[dict(slices=members, pending=members.copy(), findings=[], reviews=[], sha=None)
                                 for members in groups])
            if task_mode:
                build.update(mode=TASK_MODE, title=state["title"])
            if QUALITY_POLICY_FILE in preserved:
                build["preservedPolicySha"] = policy_sha(self.root)
            state["builds"].append(build)
        return self.advance(build["id"])

    def advance(self, key):
        with self.app.lock:
            with self.workspace.edit() as state:
                build = self.current(state, key)
                if build["status"] not in {"ready", "failed", "cancelled"}:
                    raise ValueError("This build is not ready to run.")
                if (state["approved"] != build["revision"] or state["revision"] != build["revision"] or
                        state["question"] or state.get("plannerRetry")):
                    raise ValueError("The plan changed. Retire this build and approve the edited draft.")
                if self.app.busy():
                    raise ValueError("Wait for the active job.")
                group = build["groups"][build["index"]]
                group.setdefault("base", build["base"])
                if state["branch"] != build["branch"]:
                    raise ValueError("Restore the configured build branch before continuing.")
                member = group["pending"][0]
                check_preserved_policy(self.root, build)
                last = build["attempts"][-1] if build["attempts"] else {}
                task = self.app.active() or {}
                if self.owns_run(task.get("id")):
                    raise ValueError("The coordinator still owns this run.")
                if (last.get("task") and task.get("id") == last["task"] and last["slice"] == member and
                        task.get("status") in {"active", "paused"}):
                    tid = task["id"]
                    if task["status"] == "paused":
                        self.native_action("resume", tid)
                else:
                    if task.get("status") in {"active", "unverified"}:
                        raise ValueError("Another task is active.")
                    if checkout(self.root, build["branch"], build.get("preserved", {}),
                                build.get("preserved_index", {})) != build["base"]:
                        raise ValueError("The checkout changed before the next run.")
                    home = self.root / ".harness"
                    if ((home / "profile.disabled").exists() or
                            hashlib.sha256((home / "profile.json").read_bytes()).hexdigest() != build["profile"]):
                        raise ValueError("Restore the selected build profile before continuing.")
                    title = next(s["title"] for m in build["roadmap"] for s in m["slices"] if s["id"] == member)
                    findings = [f for f in group["findings"] if member in f["slices"] and not f.get("repaired")]
                    context = dict(title=title, approvedPlan=build["plan"])
                    if build.get("mode") == TASK_MODE:
                        context["reviewFindings"] = [
                            dict(reviewId=f["reviewId"], runId=f["runId"], commit=f["sha"], findings=f["findings"])
                            for f in findings
                        ]
                        scope = ("Address the selected review findings within the approved task plan." if findings else
                                 "Implement the approved task plan.")
                    else:
                        context.update(slice=member, findings=[f["text"] for f in findings])
                        scope = "Implement only the selected slice."
                    asset = build["attachments"].get(member)
                    if asset:
                        context["mockup"] = ".harness/design/assets/" + asset + ".png"
                    scope += " Workbench commits the checked files locally. Leave Git operations to Workbench.\n"
                    result = self.app.cli_with_json(["build", "--answer-channel", "form", "--action", title,
                                                     "--scope", scope + json.dumps(context)], build["decisions"])
                    tid = result["data"]["task_id"]
                build["status"] = "working"
                build.pop("error", None)
                attempt = dict(id=identifier(), slice=member, task=tid, started=now(), outcome="starting",
                               reason=group["findings"][-1]["text"] if group["findings"] else last.get("error", ""))
                build["attempts"].append(attempt)
                target = self.loop_folder(tid) / "design.json"
                pinned = dict(branch=build["branch"], build=key, group=build["index"], slice=member,
                              base=build["base"], preserved=build.get("preserved", {}),
                               preserved_index=build.get("preserved_index", {}),
                               rejected=[f["sha"] for f in group["findings"] if not f["repaired"]])
                if build.get("mode") == TASK_MODE:
                    pinned["mode"] = TASK_MODE
                if "preservedPolicySha" in build:
                    pinned["preservedPolicySha"] = build["preservedPolicySha"]
                prior = load(target)
                if prior is None:
                    write_json(target, pinned)
                elif (prior.get("branch") != pinned["branch"] or prior.get("build") != key or
                      prior.get("base") != pinned["base"] or prior.get("rejected", []) != pinned["rejected"] or
                      prior.get("group", build["index"]) != build["index"] or prior.get("slice", member) != member or
                      prior.get("mode") != pinned.get("mode") or
                      prior.get("preserved", {}) != pinned["preserved"] or
                      prior.get("preservedPolicySha") != pinned.get("preservedPolicySha") or
                      prior.get("preserved_index", {}) != pinned["preserved_index"]):
                    raise ValueError("The recorded slice scope changed. Retire the build before starting another.")
            try:
                job = self.app.post("/api/chat", {"message": "/run"})
                if job.get("id") not in self.app.jobs:
                    raise ValueError(job.get("response", "Complete the task agreement in Live run."))
            except (OSError, ValueError, RuntimeError) as exc:
                with self.workspace.edit() as state:
                    build = self.current(state, key)
                    build["status"] = "failed"
                    build["attempts"][-1].update(outcome="failed", finished=now(), error=str(exc))
                raise
            return self.workspace.read()

    @staticmethod
    def current(state, key):
        if not state["builds"] or state["builds"][-1]["id"] != key:
            raise ValueError("Select the current build.")
        return state["builds"][-1]

    def watch(self, job):
        """Called for all coordinator jobs, including answers submitted in Live run."""
        with self.workspace.edit() as state:
            if not state["builds"]:
                return
            build = state["builds"][-1]
            if not build["attempts"] or build["attempts"][-1]["task"] != job.record["task_id"] or build["status"] in {"closed", "retired"}:
                return
            attempt = build["attempts"][-1]
            if attempt.get("job") == job.id:
                return
            if attempt.get("job"):
                attempt = dict(id=identifier(), slice=attempt["slice"], task=attempt["task"], started=now(),
                               reason=attempt.get("error", "Coordinator resumed"))
                build["attempts"].append(attempt)
            attempt.update(job=job.id, outcome="running")
            build["status"] = "working"
        self.app.pool.submit(self.collect, build["id"], job)

    def collect(self, key, job):
        result = job.wait()
        self.record_result(key, job.id, result)

    def reconnect(self, key):
        with self.app.lock:
            build = self.current(self.workspace.read(), key)
            if build["status"] not in {"working", "cancelling"}:
                raise ValueError("Refresh the current build status.")
            attempt = build["attempts"][-1]
            job_id = attempt.get("job")
            if job_id in self.app.jobs:
                result = self.app.jobs[job_id].snapshot()
                if result["state"] in {"completed", "failed", "cancelled"}:
                    self.record_result(key, job_id, result)
                return self.workspace.read()
            home = self.root / ".harness"
            folder = home / "loops" / attempt["task"]
            try:
                with owned(folder / "launch"), owned(folder):
                    loop = load(folder / "state.json", {})
                    result = load(home / "chat" / attempt["task"] / (job_id or "missing") / "result.json")
                    if not result:
                        status = ("cancelled" if build["status"] == "cancelling" else "completed"
                                  if loop.get("stage") in {"completed", "question", "question_retry"} else "interrupted")
                        result = dict(state=status, error="Recovered from the coordinator checkpoint.")
            except (BlockingIOError, PermissionError):
                raise ValueError("The coordinator still owns this run.")
            self.record_result(key, job_id, result)
            return self.workspace.read()

    def record_result(self, key, job_id, result):
        with self.app.lock:
            with self.workspace.edit() as state:
                build = self.current(state, key)
                attempt = next(a for a in reversed(build["attempts"]) if a.get("job") == job_id)
                if attempt.get("finished"):
                    return
                loop = load(self.root / ".harness/loops" / attempt["task"] / "state.json", {})
                attempt.update(outcome=result["state"], finished=now(), step=loop.get("stage"), error=result.get("error", ""))
                group = build["groups"][build["index"]]
                if loop.get("stage") == "completed" and result["state"] == "completed" and loop.get("design_sha"):
                    group["sha"] = loop["design_sha"]
                    build["base"] = loop["design_sha"]
                    if build.get("mode") == TASK_MODE:
                        attempt["sha"] = loop["design_sha"]
                    group["pending"].remove(attempt["slice"])
                    build["status"] = "ready" if group["pending"] else "review"
                    if not group["pending"]:
                        for finding in group["findings"]:
                            finding["repaired"] = True
                elif result["state"] == "cancelled":
                    build["status"] = "cancelled"
                    active = self.app.active() or {}
                    if active.get("id") == attempt["task"] and active.get("status") == "active":
                        try:
                            self.native_action("pause", attempt["task"], "Design run cancelled.")
                        except (OSError, ValueError, subprocess.SubprocessError) as exc:
                            build["error"] = str(exc)
                elif loop.get("stage") == "question_retry" or (result["state"] == "completed" and loop.get("stage") == "question"):
                    build["status"] = "question"
                    attempt["outcome"] = "retry suggestions" if loop["stage"] == "question_retry" else "waiting for answer"
                else:
                    build["status"] = "failed"
            if build["status"] == "ready":
                try:
                    self.advance(key)
                except (OSError, ValueError) as exc:
                    with self.workspace.edit() as state:
                        self.current(state, key)["error"] = str(exc)

    def decision(self, operation, payload):
        with self.app.lock, self.workspace.edit() as state:
            build = self.current(state, payload["build"])
            if operation == "retire":
                if self.app.busy() or build["status"] in {"closed", "retired", "working", "cancelling"}:
                    raise ValueError("Stop the active run before retiring this build.")
                task = self.app.active() or {}
                last = build["attempts"][-1] if build["attempts"] else {}
                if last.get("task") and task.get("id") == last["task"]:
                    if self.owns_run(task["id"]):
                        raise ValueError("Stop the active run before retiring this build.")
                    if task.get("status") == "active":
                        self.native_action("pause", task["id"], "Design build retired.")
                build.update(status="retired", retired=True)
                return state
            task_mode = build.get("mode") == TASK_MODE
            index = payload.get("group", 0) if task_mode else payload["group"]
            if type(index) is not int or not 0 <= index < len(build["groups"]):
                raise ValueError("Unknown review group.")
            group = build["groups"][index]
            sha = group["sha"]
            requested_slices = payload.get("slices", group["slices"]) if task_mode else payload["slices"]
            if not sha or sha != payload["sha"] or group["slices"] != requested_slices:
                raise ValueError("The review target changed. Refresh Branch Review.")
            check_preserved_policy(self.root, build)
            if operation == "finding":
                closed_review = build["status"] == "closed" and bool(group["reviews"])
                held_review = (build["status"] == "ready" and bool(group["reviews"]) and
                               group["reviews"][-1]["sha"] == sha == build["base"])
                if not (closed_review or held_review or (build["status"] == "review" and index == build["index"])):
                    raise ValueError("Select the pending Branch Review.")
                if held_review and checkout(self.root, build["branch"], build.get("preserved", {}),
                                            build.get("preserved_index", {})) != sha:
                    raise ValueError("The checkout changed since the slice checks.")
                if task_mode:
                    if (state["revision"] != build["revision"] or state["approved"] != build["revision"] or
                            build["branch"] != state["branch"] or
                            checkout(self.root, build["branch"], build["preserved"], build["preserved_index"]) != sha):
                        raise ValueError("The task plan or checkout changed. Refresh Branch Review.")
                    review = group_review(self.root, state, build, group)
                    if (review.get("status") != "changes-requested" or review.get("reviewedCommit") != sha or
                            review.get("base") != group["base"] or not review.get("reviewId") or
                            payload.get("reviewId", review["reviewId"]) != review["reviewId"]):
                        raise ValueError("Select findings from the exact task review.")
                    affected = group["slices"]
                else:
                    review = None
                    affected = payload["affected"]
                if not affected or not isinstance(affected, list) or not set(affected) <= set(group["slices"]):
                    raise ValueError("Select the slices affected by this finding.")
                picked = payload.get("findingIds")
                if task_mode and picked is None:
                    picked = [row["id"] for row in review.get("findings", []) if row.get("status") != "resolved"]
                evidence = {}
                if picked is not None:
                    if (not isinstance(picked, list) or not picked or len(picked) > 100 or
                            not all(isinstance(item, str) for item in picked) or len(set(picked)) != len(picked)):
                        raise ValueError("Select distinct Branch Review findings.")
                    review = review or group_review(self.root, state, build, group)
                    findings = {row["id"]: row for row in review.get("findings", []) if row.get("status") != "resolved"}
                    if any(item not in findings for item in picked):
                        raise ValueError("A Branch Review finding changed. Refresh the group and select it again.")
                    text = "\n\n".join(f"{findings[item]['actual']}\nExpected: {findings[item]['expected']}" for item in picked)
                    if task_mode:
                        evidence = dict(reviewId=review["reviewId"], runId=review["runId"],
                                        findings=[findings[item] for item in picked])
                else:
                    text = required(payload.get("text"), "a finding")
                group["findings"].append(dict(slices=affected, text=text, branchReviewFindings=picked or [],
                                              sha=sha, time=now(), repaired=False, **evidence))
                group.update(pending=[s for s in group["slices"] if s in affected], sha=None)
                build.update(status="ready", index=index)
                return state
            if (build.get("retired") or build["branch"] != state["branch"] or
                    checkout(self.root, build["branch"], build.get("preserved", {}),
                             build.get("preserved_index", {})) != sha):
                raise ValueError("The checkout changed since the slice checks.")
            if state["approved"] != build["revision"] or group["pending"] or any(not f["repaired"] for f in group["findings"]):
                raise ValueError("The group requires repair or renewed plan approval.")
            if operation == "review":
                saved = group["reviews"][-1] if group["reviews"] else {}
                recorded = task_mode and build["status"] == "closed" and saved.get("sha") == sha
                if not recorded and (index != build["index"] or build["status"] != "review"):
                    raise ValueError("Select the group waiting for Branch Review.")
                decision = approved_review(self.root,state,build,group)
                if recorded:
                    if saved["reviewId"] != decision["reviewId"] or saved["runId"] != decision["runId"]:
                        raise ValueError("The Branch Review decision changed. Refresh the review.")
                    return state
                group["reviews"].append(dict(sha=sha, slices=list(group["slices"]), checklist=decision["checklist"],
                                             branch=build["branch"], author=decision["approval"]["reviewer"],
                                             time=decision["approval"]["at"], pushTarget=decision.get("pushTarget"), reviewId=decision["reviewId"],runId=decision["runId"]))
                build["index"] = next((i for i, g in enumerate(build["groups"]) if not g["reviews"]
                                       or g["reviews"][-1]["sha"] != g["sha"]), len(build["groups"]))
                build["status"] = "closed" if build["index"] == len(build["groups"]) else "ready"
            elif operation == "push":
                if not group["reviews"]:
                    raise ValueError("Complete human Branch Review first.")
                review = group["reviews"][-1]
                if review["sha"] != sha or review["slices"] != group["slices"] or review["branch"] != build["branch"]:
                    raise ValueError("The approved group or branch changed.")
                receipt = push_approved(self.root,state,build,group,review,payload.get("expectedTarget"))
                group["pushed"] = dict(sha=receipt["commit"], destination=receipt["remote"], ref=receipt["ref"], time=now())
            else:
                raise ValueError("Unknown branch action.")
        return state

