"""Discover project routes and prepare evidence-backed Quality drafts."""
import argparse
import ast
from collections import deque
from copy import deepcopy
from dataclasses import dataclass, field
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys

from quality import Quality, git, label, now, read, relative, save, validate


HTTP_METHODS = ("GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS")
JS_SUFFIXES = {".js", ".mjs", ".cjs", ".ts", ".mts", ".cts"}
SOURCE_SUFFIXES = JS_SUFFIXES | {".py", ".rb"}
MAX_FILES = 1600
MAX_FILE_BYTES = 750_000
MAX_SOURCE_BYTES = 36_000_000
MAX_ROUTES = 1500
MAX_BOUNDARIES = 30
MAX_SITES = 60
JS_LITERAL = r"""(?:"[^"\n\\]*(?:\\.[^"\n\\]*)*"|'[^'\n\\]*(?:\\.[^'\n\\]*)*')"""
JS_MASK = re.compile(r"//[^\n]*|/\*[\s\S]*?\*/|" + JS_LITERAL + r"|`(?:\\.|[^`\\])*`", re.DOTALL)
JS_METHOD = re.compile(r"\b(?:\w+\.)?method\s*={2,3}\s*(['\"])(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\1")
JS_PATH = re.compile(r"\b(?:\w+\.)?(?:pathname|path|endpoint|route|url)\s*={2,3}\s*(['\"])(/[^'\"\n]*)\1")
JS_REGISTRATION = re.compile(
    r"\b(?:(?P<ipc>ipcMain)\.(?P<ipc_kind>handle|on)|"
    r"(?P<router>app|router|server|fastify|api)\.(?P<method>get|post|put|patch|delete|head|options))"
    r"\s*\(\s*(?P<value>" + JS_LITERAL + r"|[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)?)\s*,",
    re.IGNORECASE,
)
JS_SYMBOL = re.compile(r"\b(?:function\s+|(?:const|let|var)\s+)([A-Za-z_$][\w$]*)"
                       r"\s*(?:=\s*(?:async\s*)?)?\(")
RUBY_METHOD = re.compile(r"(?m)^([ \t]*)def\s+(?:self\.)?([a-z_][\w!?=]*)\b")
RUBY_VERB = re.compile(r"^\s*(get|post|put|patch|delete|head|options)\s+(['\"])(.*?)\2(.*)$")
RUBY_RESOURCE = re.compile(r"^\s*(resources|resource)\s+(?::([\w]+)|['\"]([\w]+)['\"])(.*)$")
RUBY_NAMESPACE = re.compile(r"^\s*(namespace|scope)\s+(?::([\w]+)|['\"]([^'\"]+)['\"])(.*\bdo\b.*)$")
RUBY_ROUTE_TARGET = re.compile(r"""\bto:\s*(['"])([\w/]+)#([\w!?]+)\1|=>\s*(['"])([\w/]+)#([\w!?]+)\4""")
CALL = re.compile(r"(?<![\w$])([A-Za-z_$][\w$]*(?:(?:\.|::)[A-Za-z_$][\w$]*)*)\s*(?=\()")
RUBY_CALL = re.compile(r"\b[A-Z]\w*(?:::[A-Z]\w*)*\.[a-z_]\w*[!?]?|\bself\.[a-z_]\w*[!?]?")
DATA_CALL = re.compile(
    r"\b(?:[A-Za-z_$][\w$]*(?:\.|::))*(?:(?:query|execute|exec_query|find|find_by|findById|findOne|findMany|"
    r"find_by_sql|find_each|where|pluck|select_all|select_one|select_value|aggregate|groupBy|all|count|"
    r"insert|insert_all|insertMany|create|createMany|update|update_all|updateMany|update_columns|"
    r"save|delete|delete_all|deleteMany|destroy|destroy_all|upsert|upsert_all|transaction|"
    r"readFile|readFileSync|writeFile|writeFileSync|read_text|write_text|access|readdir|rename|"
    r"git|gitSync|capture2|capture3)[!?]?)(?![\w!?])"
)
DATA_WRITES = {"insert", "insert_all", "insertMany", "create", "createMany", "update", "update_all", "updateMany",
               "update_columns", "save", "delete", "delete_all", "deleteMany", "destroy", "destroy_all",
               "upsert", "upsert_all"}
DATA_FILES = {"readFile", "readFileSync", "writeFile", "writeFileSync", "read_text", "write_text", "access", "readdir",
              "rename"}
STATIC_CHECK = (
    "import json,re,sys\n"
    "from pathlib import Path\n"
    "def canonical(text):\n"
    " return re.sub(r'\\s+', ' ', text).strip()\n"
    "for argument in sys.argv[1:]:\n"
    " path,token=json.loads(argument)\n"
    " target=Path(path)\n"
    " if not target.is_file() or canonical(token) not in canonical(target.read_text(encoding='utf-8')):\n"
    "  sys.exit('Expected route source evidence in '+path+': '+token)\n"
    "print('Route source evidence present')"
)


@dataclass(frozen=True)
class Boundary:
    path: str
    name: str
    start: int
    end: int


@dataclass
class Route:
    method: str
    path: str
    framework: str
    source: Boundary | None
    handler: Boundary | None
    anchors: list = field(default_factory=list)
    gaps: list = field(default_factory=list)
    provenance: str = "static_source"
    app_root: str = "."
    target: str = ""
    observed_at: str | None = None
    observed_path: str | None = None
    related: list = field(default_factory=list)

    @property
    def id(self):
        owner = self.source.path if self.source else self.app_root
        key = json.dumps([self.method, self.path, owner])
        return "route-" + hashlib.sha256(key.encode()).hexdigest()[:20]


def location(sources, boundary, *, symbol=False):
    if not boundary:
        return None
    value = {"path": boundary.path, "line": sources[boundary.path].count("\n", 0, boundary.start) + 1}
    if symbol:
        value["symbol"] = boundary.name
    return value


def route_data(sources, route):
    handler = location(sources, route.handler)
    if handler:
        handler["name"] = route.handler.name
    elif route.target:
        handler = {"name": route.target, "path": None, "line": None}
    return {"id": route.id, "method": route.method, "path": route.path, "framework": route.framework,
            "transport": "ipc" if route.method == "IPC" else "http", "source": location(sources, route.source),
            "handler": handler, "provenance": route.provenance, "app_root": route.app_root,
            "observed_at": route.observed_at, "observed_path": route.observed_path}


def tracked_files(project):
    result = subprocess.run(["git", "-C", str(project), "ls-files", "-z", "--cached", "--full-name"],
                            capture_output=True, timeout=20)
    if result.returncode:
        raise ValueError("Route discovery needs a Git checkout")
    head = git(project, "rev-parse", "--show-prefix")
    if head:
        files = [name.removeprefix(head) for name in result.stdout.decode("utf-8", errors="replace").split("\0")
                 if name.startswith(head)]
    else:
        files = result.stdout.decode("utf-8", errors="replace").split("\0")
    return sorted({name for name in files if name and not name.startswith(".harness/")})


def get_source(project, name):
    source = project / name
    try:
        resolved = source.resolve(strict=True)
        if not resolved.is_relative_to(project) or not resolved.is_file() or resolved.stat().st_size > MAX_FILE_BYTES:
            return None
        return resolved.read_text(encoding="utf-8-sig")
    except (OSError, UnicodeError):
        return None


def source_map(project, tracked):
    selected = [name for name in tracked if PurePosixPath(name).suffix in SOURCE_SUFFIXES
                and not name.endswith(".min.js")
                and not {"node_modules", "vendor", "dist", "test", "tests", "spec"}.intersection(PurePosixPath(name).parts)]
    sources = {}
    total_bytes = 0
    for name in selected[:MAX_FILES]:
        text = get_source(project, name)
        if text is not None:
            total_bytes += len(text)
            if total_bytes > MAX_SOURCE_BYTES:
                break
            sources[name] = text
    gaps = []
    if len(selected) > MAX_FILES or len(sources) < len(selected[:MAX_FILES]):
        gaps.append("Some tracked source files exceeded the discovery limits or could not be read.")
    return sources, gaps


def mask_js(text):
    return JS_MASK.sub(lambda match: re.sub(r"[^\n]", " ", match[0]), text)


def delimiter_end(code, start, opener, closer):
    depth = 0
    for index in range(start, len(code)):
        if code[index] == opener:
            depth += 1
        elif code[index] == closer:
            depth -= 1
            if depth == 0:
                return index + 1
    return None


def function_body(code, start):
    position = start + (len(code[start:]) - len(code[start:].lstrip()))
    if position >= len(code):
        return None
    if code[position] == "{":
        end = delimiter_end(code, position, "{", "}")
        return (position, end) if end else None
    nesting = 0
    for index in range(position, min(len(code), position + 12_000)):
        char = code[index]
        if char in "({[":
            nesting += 1
        elif char in ")}]":
            if not nesting:
                return position, index
            nesting -= 1
        elif char == ";" and nesting == 0:
            return position, index + 1
    return None


def js_symbols(path, code):
    result = {}
    for match in JS_SYMBOL.finditer(code):
        close = delimiter_end(code, match.end() - 1, "(", ")")
        if close is None:
            continue
        after = re.match(r"\s*(?:=>\s*)?(?=\{)", code[close:])
        if after:
            body = function_body(code, close + after.end())
            if body:
                result[match[1]] = Boundary(path, match[1], *body)
    return result


def js_constants(text):
    constants = {match[1]: match[3] for match in re.finditer(
        r"\b(?:const|let)\s+(\w+)\s*=\s*(['\"])([^'\"\n]+)\2", text)}
    for obj in re.finditer(r"\bconst\s+(\w+)\s*=\s*(?:Object\.freeze\s*\(\s*)?\{([^{}]{1,12000})\}", text):
        for prop in re.finditer(r"\b(\w+)\s*:\s*(['\"])([^'\"\n]+)\2", obj[2]):
            constants[obj[1] + "." + prop[1]] = prop[3]
    return constants


def js_route_constants(path, sources):
    constants = {name: (path, value) for name, value in js_constants(sources[path]).items()}
    for alias, (target, symbol) in import_symbols(sources, path, "javascript").items():
        for name, value in js_constants(sources[target]).items():
            if not symbol:
                constants[alias + "." + name] = (target, value)
            elif name == symbol or name.startswith(symbol + "."):
                constants[alias + name[len(symbol):]] = (target, value)
    return constants


def js_routes(path, text, sources):
    code = mask_js(text)
    symbols = js_symbols(path, code)
    constants = js_route_constants(path, sources)
    imports = import_symbols(sources, path, "javascript")
    rows = []
    gaps = []
    for registration in JS_REGISTRATION.finditer(text):
        if not code[registration.start():].startswith(registration.group("ipc") or registration.group("router")):
            continue
        raw = registration.group("value")
        literal = raw.startswith(("'", '"'))
        value_source, value = (path, raw[1:-1]) if literal else constants.get(raw, (None, None))
        method = "IPC" if registration.group("ipc") else registration.group("method").upper()
        if not value or method != "IPC" and not value.startswith("/"):
            gaps.append(f"{path} contains a route registration with an unresolved path or channel.")
            continue
        prefix = registration.group("ipc") or registration.group("router")
        name = f"{prefix}.{registration.group('ipc_kind') or registration.group('method')}"
        source = Boundary(path, name, registration.start(), registration.end())
        handler = None
        related = []
        bound = delimiter_end(code, text.index("(", registration.start(), registration.end()), "(", ")")
        if bound:
            callback = code[registration.end():bound - 1]
            references = re.findall(r"(?:^|,)\s*([A-Za-z_$][\w$]*)\s*(?=,|$)", callback)
            for reference in references:
                target = symbols.get(reference)
                imported, original = imports.get(reference, (None, None))
                if not target and imported and original:
                    target = js_symbols(imported, mask_js(sources[imported])).get(original)
                if target:
                    related.append(target)
            if related:
                handler = related.pop()
            else:
                handler = Boundary(path, name, registration.end(), bound - 1)
        anchors = [(path, text[registration.start():registration.end()])]
        if not literal:
            anchors.append((value_source, value))
        rows.append(Route(method, value, "Electron IPC" if method == "IPC" else "Node HTTP",
                          source, handler, anchors, related=related))

    conditions = []
    for marker in re.finditer(r"\bif\s*\(", code):
        close = delimiter_end(code, marker.end() - 1, "(", ")")
        if not close:
            continue
        condition = text[marker.end():close - 1]
        path_terms = list(JS_PATH.finditer(condition))
        methods = {item[2] for item in JS_METHOD.finditer(condition)}
        table = re.search(r"\b(\w+)\.has\((?:\w+\.)?(?:pathname|path)\)", condition)
        body = function_body(code, close)
        if body and (path_terms or (methods and table)):
            conditions.append((marker, close, condition, path_terms, methods, table, body))

    tables = {}
    for marker, close, condition, terms, methods, table, body in conditions:
        if branches := sorted(methods):
            for term in terms:
                boundary = Boundary(path, f"{branches[0]} {term[2]}", *body)
                anchors = [(path, text[marker.start():close])]
                for method in branches:
                    rows.append(Route(method, term[2], "Node HTTP", Boundary(path, "HTTP predicate", marker.start(), close),
                                      boundary, anchors))
        if methods and table:
            declaration = re.search(r"\b(?:const|let)\s+" + re.escape(table[1]) + r"\s*=\s*new\s+Set\(\s*\[([^\]]+)\]", text)
            if not declaration:
                gaps.append(f"{path} dispatches routes through an unresolved request table.")
                continue
            tables[table[1]] = (declaration, marker, close, methods, body)
    for table_name, (declaration, marker, close, methods, dispatch_body) in tables.items():
        entries = [(entry[2], declaration.start(1) + entry.start(),
                    [(path, declaration[0]), (path, entry[0])])
                   for entry in re.finditer(r"(['\"])(/[^'\"\n]+)\1", declaration[1])]
        additions = r"\b" + re.escape(table_name) + r"\.add\(\s*(['\"])(/[^'\"\n]+)\1\s*\)"
        entries.extend((entry[2], entry.start(), [(path, entry[0])])
                       for entry in re.finditer(additions, text)
                       if code[entry.start():].startswith(table_name))
        for value, entry_start, membership in entries:
            candidates = [item for item in conditions if not item[4] and any(term[2] == value for term in item[3])]
            chosen = next((item for item in candidates if dispatch_body[0] <= item[0].start() < dispatch_body[1]), None)
            chosen = chosen or next(iter(candidates), None)
            body = chosen[-1] if chosen else dispatch_body
            for method in sorted(methods):
                source = Boundary(path, table_name, entry_start, entry_start + len(value))
                target = Boundary(path, f"{method} {value}", *body)
                anchors = [(path, text[marker.start():close]), *membership]
                if chosen:
                    anchors.append((path, text[chosen[0].start():chosen[1]]))
                route_gaps = [] if chosen else ["The request table is visible, but its route-specific dispatch target could not be resolved."]
                rows.append(Route(method, value, "Node HTTP", source, target, anchors, route_gaps))
    return rows, list(dict.fromkeys(gaps))


def ruby_handler(sources, root, controller, action):
    filename = (root / "app/controllers" / (controller + "_controller.rb")).as_posix()
    text = sources.get(filename)
    if text is None:
        return None
    methods = ruby_symbols(filename, text)
    return methods.get(action)


def ruby_symbols(path, text):
    methods = {}
    for match in RUBY_METHOD.finditer(text):
        limit = re.search(r"(?m)^" + re.escape(match[1]) + r"(?:end\b|def\s)", text[match.end():])
        end = match.end() + limit.end() if limit and limit[0].strip() == "end" else (
            match.end() + limit.start() if limit else len(text))
        methods[match[2]] = Boundary(path, match[2], match.start(), end)
    return methods


def ruby_actions(options, available):
    matcher = r"\b{key}:\s*(\[[^\]]*\]|:\w+|%i\[[^\]]*\])"
    only = re.search(matcher.format(key="only"), options)
    skip = re.search(matcher.format(key="except"), options)
    actions = list(available)
    if only:
        actions = [action for action in actions if re.search(r"\b" + action + r"\b", only[1])]
    if skip:
        actions = [action for action in actions if not re.search(r"\b" + action + r"\b", skip[1])]
    return actions


def singular(resource):
    if resource.endswith("ies"):
        return resource[:-3] + "y"
    if resource.endswith(("ches", "shes", "sses", "xes", "zes")):
        return resource[:-2]
    return resource.removesuffix("s")


def join_rail_segments(*parts):
    return "/" + "/".join(part.strip("/") for part in parts if part.strip("/"))


def rails_routes(path, text, sources):
    root = PurePosixPath(path).parent.parent
    rows = []
    gaps = []
    scopes = []
    offset = 0
    for raw in text.splitlines(keepends=True):
        line = raw.rstrip("\r\n")
        start = offset
        offset += len(raw)
        content = line.lstrip()
        indent = len(line) - len(content)
        if not content or content.startswith("#"):
            continue
        while scopes and indent <= scopes[-1]["indent"]:
            scopes.pop()
        parent = scopes[-1] if scopes else {"path": "", "module": ""}
        if namespace := RUBY_NAMESPACE.match(line):
            value = namespace[2] or namespace[3]
            scopes.append({"indent": indent, "path": join_rail_segments(parent["path"], value),
                           "module": join_rail_segments(parent["module"], value).strip("/") if namespace[1] == "namespace"
                           else parent["module"], "anchor": content})
            continue
        resource = RUBY_RESOURCE.match(line)
        verb = RUBY_VERB.match(line)
        if not (resource or verb):
            if re.match(r"(?:match|mount|draw|concern|constraints)\b", content):
                gaps.append(f"{path} contains Rails route construction that needs runtime inspection.")
            continue
        anchor = [(path, scope["anchor"]) for scope in scopes] + [(path, content)]
        source = Boundary(path, "Rails route", start + indent, start + len(line))
        if verb:
            target = RUBY_ROUTE_TARGET.search(verb[4])
            direct = re.fullmatch(r"([\w/]+)#([\w!?]+)", verb[3])
            if target:
                controller, action = (target[2], target[3]) if target[2] else (target[5], target[6])
                route_path = verb[3]
            elif direct:
                controller, action = direct.groups()
                route_path = controller + "/" + action
            else:
                controller, action, route_path = "", "", verb[3]
                gaps.append(f"{path} contains a Rails route with an unresolved target.")
            rows.append(rails_route(verb[1].upper(), join_rail_segments(parent["path"], route_path), source, anchor,
                                    sources, root, parent["module"], controller, action))
            continue
        kind, value, options = resource[1], resource[2] or resource[3], resource[4]
        controller = value if kind == "resources" else value + "s"
        explicit_controller = re.search(r"""\bcontroller:\s*(?::([\w/]+)|['"]([\w/]+)['"])""", options)
        if explicit_controller:
            controller = explicit_controller[1] or explicit_controller[2]
        path_option = re.search(r"""\bpath:\s*(?::([\w/]+)|['"]([^'"]+)['"])""", options)
        resource_path = join_rail_segments(parent["path"], (path_option[1] or path_option[2]) if path_option else value)
        param_option = re.search(r"\bparam:\s*:(\w+)", options)
        param = param_option[1] if param_option else "id"
        member = resource_path + "/:" + param if kind == "resources" else resource_path
        endpoints = {"new": [("GET", resource_path + "/new")], "create": [("POST", resource_path)],
                     "show": [("GET", member)], "edit": [("GET", member + "/edit")],
                     "update": [("PATCH", member), ("PUT", member)], "destroy": [("DELETE", member)]}
        if kind == "resources":
            endpoints["index"] = [("GET", resource_path)]
        for action in ruby_actions(options, endpoints):
            for method, route_path in endpoints[action]:
                rows.append(rails_route(method, route_path, source, anchor, sources, root,
                                        parent["module"], controller, action))
        if re.search(r"\bdo\b", options):
            scope = resource_path
            if kind == "resources":
                scope += "/:" + singular(value) + "_" + param
            scopes.append({"indent": indent, "path": scope, "module": parent["module"], "anchor": content})
    return rows, list(dict.fromkeys(gaps))


def rails_route(method, route_path, source, anchors, sources, root, module, controller, action):
    controller = join_rail_segments(module, controller).strip("/") if controller else ""
    handler = ruby_handler(sources, root, controller, action) if controller else None
    target = f"{controller}#{action}" if action else ""
    guards = anchors + ([(handler.path, f"def {action}")] if handler else [])
    gaps = [] if handler else ["The assumed Rails controller action could not be located in tracked source."]
    return Route(method, route_path, "Rails", source, handler, guards, gaps, app_root=root.as_posix(), target=target)


def python_methods(test, inherited):
    for child in ast.walk(test):
        if not isinstance(child, ast.Compare) or not any(isinstance(item, ast.Eq) for item in child.ops):
            continue
        if not isinstance(child.left, ast.Attribute) or child.left.attr not in {"method", "command"}:
            continue
        result = {item.value for item in child.comparators if isinstance(item, ast.Constant)
                  and isinstance(item.value, str) and item.value in HTTP_METHODS}
        if result:
            return result
    return inherited


def python_paths(test):
    paths = set()
    for child in ast.walk(test):
        if not isinstance(child, ast.Compare) or not isinstance(child.left, (ast.Name, ast.Attribute)):
            continue
        name = getattr(child.left, "id", None) or child.left.attr
        if name not in {"path", "route", "endpoint", "pathname"}:
            continue
        for op, comparator in zip(child.ops, child.comparators):
            if isinstance(op, ast.Eq) and isinstance(comparator, ast.Constant):
                candidates = [comparator]
            elif isinstance(op, ast.In) and isinstance(comparator, (ast.Set, ast.Tuple, ast.List)):
                candidates = comparator.elts
            else:
                continue
            for item in candidates:
                if isinstance(item, ast.Constant) and isinstance(item.value, str) and item.value.startswith("/"):
                    paths.add(item.value)
    return paths


def python_routes(path, text):
    try:
        tree = ast.parse(text)
    except (SyntaxError, ValueError):
        return []
    offsets = [0]
    for line in text.splitlines(keepends=True):
        offsets.append(offsets[-1] + len(line))
    routes = []

    def visit(node, methods):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            name = node.name.removeprefix("do_").upper()
            if name in HTTP_METHODS:
                methods = {name}
        if isinstance(node, ast.If):
            methods = python_methods(node.test, methods)
            for actual in sorted(python_paths(node.test)):
                for method in sorted(methods):
                    source = Boundary(path, "HTTP predicate", offsets[node.lineno - 1], offsets[node.lineno])
                    action = node.body[0]
                    handler = Boundary(path, f"{method} {actual}", offsets[action.lineno - 1],
                                       offsets[node.body[-1].end_lineno])
                    guard = ast.get_source_segment(text, node.test)
                    routes.append(Route(method, actual, "Python HTTP", source, handler, [(path, guard)]))
        for child in ast.iter_child_nodes(node):
            visit(child, methods)

    visit(tree, set())
    return routes



def static_catalog(project):
    tracked = tracked_files(project)
    sources, gaps = source_map(project, tracked)
    routes = []
    for path, text in sources.items():
        if path == "config/routes.rb" or path.endswith("/config/routes.rb"):
            found, limits = rails_routes(path, text, sources)
        elif PurePosixPath(path).suffix in JS_SUFFIXES:
            found, limits = js_routes(path, text, sources)
        elif PurePosixPath(path).suffix == ".py":
            found, limits = python_routes(path, text), []
        else:
            continue
        routes.extend(found)
        gaps.extend(limits)
    return tracked, sources, routes, list(dict.fromkeys(gaps))


def observation_fingerprint(project, tracked, sources):
    fingerprint = hashlib.sha256()
    try:
        fingerprint.update(git(project, "rev-parse", "HEAD").encode())
    except ValueError:
        pass
    for path in tracked:
        if path.endswith(".rb") or PurePosixPath(path).name in {"Gemfile", "Gemfile.lock"}:
            text = sources.get(path)
            if text is None and PurePosixPath(path).name in {"Gemfile", "Gemfile.lock"}:
                text = get_source(project, path)
            fingerprint.update(path.encode() + b"\0" + (text or "").encode() + b"\0")
    return fingerprint.hexdigest()


def cached_observations(project, tracked, sources, refresh, app=None):
    path = project / ".harness/quality/rails-routes.json"
    if not refresh and not path.is_file():
        return {}, []
    fingerprint = observation_fingerprint(project, tracked, sources)
    try:
        cached = read(path) if path.is_file() else {}
    except (OSError, ValueError):
        cached = {}
    if cached.get("fingerprint") != fingerprint:
        cached = {}
    if not refresh:
        return cached, []
    try:
        from quality_route_runtime import discover_rails_runtime
        observations = discover_rails_runtime(project, app=app)
    except (ImportError, ValueError, RuntimeError, OSError, subprocess.SubprocessError) as error:
        return cached, [f"Rails runtime routes could not be observed: {error}"]
    warnings = list(observations.get("warnings", []))
    if not observations.get("verified"):
        return cached, warnings
    apps = {row.get("app_root", ".") for row in observations.get("routes", [])}
    previous = [row for row in cached.get("routes", []) if row.get("app_root", ".") not in apps]
    stamp = now()
    routes = previous + [dict(row, observed_at=stamp) for row in observations.get("routes", [])]
    cached = {"fingerprint": fingerprint, "routes": routes}
    save(path, cached)
    return cached, warnings


def with_runtime(project, tracked, sources, routes, gaps, *, refresh=False, app=None):
    observations, warnings = cached_observations(project, tracked, sources, refresh, app)
    gaps = gaps + warnings
    if not observations:
        return routes, gaps
    observed = {}
    for item in observations.get("routes", []):
        app = item.get("app_root", ".")
        path = item["path"].removesuffix("(.:format)")
        observed[(item["method"], path, app)] = item
    for route in routes:
        if route.framework != "Rails":
            continue
        item = observed.pop((route.method, route.path, route.app_root), None)
        if item:
            route.provenance = "rails_runtime"
            route.observed_at = item.get("observed_at")
            route.observed_path = item["path"]
            controller, action = item.get("controller"), item.get("action")
            if controller and action and route.target != f"{controller}#{action}":
                route.target = f"{controller}#{action}"
                route.handler = ruby_handler(sources, PurePosixPath(route.app_root), controller, action)
                route.gaps.append("Rails runtime resolved a different controller action from the static declaration.")
                if route.handler:
                    route.anchors = [anchor for anchor in route.anchors if anchor[0] == route.source.path]
                    route.anchors.append((route.handler.path, f"def {action}"))
    for (method, value, app), item in sorted(observed.items()):
        controller, action = item.get("controller"), item.get("action")
        handler = ruby_handler(sources, PurePosixPath(app), controller, action) if controller and action else None
        target = f"{controller}#{action}" if controller and action else ""
        anchors = [(handler.path, f"def {action}")] if handler else []
        routes.append(Route(method, value, "Rails", None, handler, anchors, [
            "Rails runtime observed this route. Its generated check verifies controller source.",
            "A matching tracked route declaration could not be resolved."
        ], "rails_runtime", app, target, item.get("observed_at"), item["path"]))
    return routes, gaps


def put_routes(routes):
    return sorted({route.id: route for route in reversed(routes)}.values(),
                  key=lambda route: (route.method == "IPC", route.path, route.method, route.app_root, route.id))


def discover(project, *, runtime=False, app=None):
    project = Path(project).resolve(strict=True)
    tracked, sources, routes, gaps = static_catalog(project)
    routes, gaps = with_runtime(project, tracked, sources, routes, gaps, refresh=runtime, app=app)
    routes = put_routes(routes)
    if len(routes) > MAX_ROUTES:
        gaps.append("The route list reached the discovery limit. Enter an omitted route manually.")
    if not routes:
        gaps.append("No supported route declarations were found. Enter the method and path manually.")
    rails_apps = {PurePosixPath(name).parent.parent.as_posix() for name in tracked
                  if name == "config/application.rb" or name.endswith("/config/application.rb")}
    rails_apps.update(route.app_root for route in routes if route.framework == "Rails")
    return {"routes": [route_data(sources, route) for route in routes[:MAX_ROUTES]],
            "frameworks": sorted({route.framework for route in routes}), "rails_apps": sorted(rails_apps),
            "gaps": sorted(set(gaps))}


def python_symbols(path, text):
    try:
        tree = ast.parse(text)
    except (SyntaxError, ValueError):
        return {}
    offsets = [0]
    for line in text.splitlines(keepends=True):
        offsets.append(offsets[-1] + len(line))
    return {node.name: Boundary(path, node.name, offsets[node.lineno - 1], offsets[node.end_lineno])
            for node in ast.walk(tree) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}


def module_at(sources, path, module):
    parent = PurePosixPath(path).parent
    parts = []
    for part in (parent / module).parts:
        if part == "..":
            if not parts:
                return None
            parts.pop()
        else:
            parts.append(part)
    candidate = PurePosixPath(*parts).as_posix()
    if candidate in sources:
        return candidate
    for suffix in sorted(JS_SUFFIXES | {".py"}):
        for name in (candidate + suffix, candidate + "/index" + suffix):
            if name in sources:
                return name
    return None


def import_symbols(sources, path, language):
    text = sources[path]
    found = {}
    if language == "javascript":
        # Resolve only explicit relative imports into tracked source.
        for match in re.finditer(r"""(?m)^\s*import\s+(.*?)\s+from\s+(['"])(\.[^'"\n]+)\2""", text, re.DOTALL):
            target = module_at(sources, path, match[3])
            if not target:
                continue
            for namespace in re.finditer(r"\*\s+as\s+([A-Za-z_$][\w$]*)", match[1]):
                found[namespace[1]] = (target, None)
            brace = re.search(r"\{([^{}]+)\}", match[1])
            if brace:
                for name in brace[1].split(","):
                    parts = re.split(r"\s+as\s+", name.strip())
                    if parts[0]:
                        found[parts[-1]] = (target, parts[0])
    elif language == "python":
        for match in re.finditer(r"(?m)^\s*from\s+([\w.]+)\s+import\s+([^\n#]+)", text):
            module = match[1].lstrip(".").replace(".", "/")
            target = module_at(sources, path, module) if module else None
            if not target:
                continue
            for name in match[2].split(","):
                parts = re.split(r"\s+as\s+", name.strip())
                if parts[0]:
                    found[parts[-1]] = (target, parts[0])
    return found


def language_at(path):
    ext = PurePosixPath(path).suffix
    return "javascript" if ext in JS_SUFFIXES else "ruby" if ext == ".rb" else "python"


def snake_case(symbol):
    symbol = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", symbol)
    return re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", symbol).lower()


def rails_call_paths(sources, app_root, constant):
    stub = "/".join(snake_case(part) for part in constant.split("::")) + ".rb"
    prefix = "" if app_root == "." else app_root + "/"
    candidates = [path for path in sources if path.startswith(prefix) and path.endswith("/" + stub)]
    return sorted(candidates, key=lambda path: (len(PurePosixPath(path).parts), path))[:4]


def call_targets(path, body, language, symbols, imports, sources, app_root):
    names = set(match[1] for match in CALL.finditer(body))
    if language == "ruby":
        names.update(match[0] for match in RUBY_CALL.finditer(body))
        names.update(name for name in symbols(path) if re.search(r"(?<![\w.])" + re.escape(name) + r"\b", body))
    targets = []
    for name in sorted(names):
        root, _, tail = name.partition(".")
        local = name if not tail else tail if root in {"self", "this"} else ""
        if local and local in symbols(path):
            targets.append(symbols(path)[local])
        elif root in imports:
            target, symbol = imports[root]
            found = symbols(target)
            candidate = symbol or tail
            if candidate and candidate in found:
                targets.append(found[candidate])
        elif language == "ruby" and tail and re.fullmatch(r"[A-Z]\w*(?:::[A-Z]\w*)*", root):
            for target in rails_call_paths(sources, app_root, root):
                if tail in symbols(target):
                    targets.append(symbols(target)[tail])
    return targets


def data_sites(sources, owner, body, language):
    sites = []
    for match in DATA_CALL.finditer(body):
        token = match[0]
        member = token.split(".")[-1].rstrip("!?")
        if token.startswith(("Promise.", "Object.", "Array.", "Math.")):
            continue
        following = body[match.end():]
        if language != "ruby" and not re.match(r"\s*(?:\?\.)?\s*\(", following):
            continue
        if language == "ruby" and "." not in token:
            continue
        if member in DATA_FILES:
            kind = "filesystem"
        elif member in {"git", "gitSync"}:
            kind = "Git"
        elif member.startswith("capture"):
            kind = "subprocess"
        elif member == "transaction":
            kind = "transaction candidate"
        elif member in DATA_WRITES:
            kind = "write candidate"
        else:
            kind = "query/data access candidate"
        line = sources[owner.path].count("\n", 0, owner.start + match.start()) + 1
        sites.append({"path": owner.path, "line": line, "operation": f"{kind}: {token}", "boundary": owner.name})
    return sites


def native_test_suggestions(project, tracked, route):
    exact = re.compile(r"""(['"])""" + re.escape(route.path) + r"\1")
    rows = []
    for path in tracked:
        name = PurePosixPath(path)
        is_node_test = name.suffix in {".js", ".mjs", ".cjs"} and re.search(r"(?:spec|test)\.[cm]?js$", name.name)
        is_rails_test = name.name.endswith("_test.rb") and (route.framework == "Rails")
        if not is_node_test and not is_rails_test:
            continue
        text = get_source(project, path)
        evidence = exact.search(text or "")
        if not evidence:
            continue
        if is_node_test and re.search(r"""['"]node:test['"]""", text):
            argv = ["node", "--test", path]
            cwd = "."
        elif is_rails_test and "ActionDispatch::IntegrationTest" in text:
            root = PurePosixPath(route.app_root)
            if not name.is_relative_to(root) or (root / "bin/rails").as_posix() not in tracked:
                continue
            argv = ["ruby", "bin/rails", "test", name.relative_to(root).as_posix()]
            cwd = route.app_root
        else:
            continue
        rows.append({"path": path, "line": text.count("\n", 0, evidence.start()) + 1,
                     "argv": argv, "cwd": cwd, "note": "This tracked test mentions the exact route. Coverage needs confirmation."})
        if len(rows) >= 5:
            break
    return rows


def trace_route(project, tracked, sources, route):
    queue = deque([route.handler, *route.related] if route.handler else [])
    visited = set()
    boundaries = []
    sites = []
    definitions = {}

    def symbols(path):
        if path not in definitions:
            language = language_at(path)
            text = sources[path]
            if language == "javascript":
                definitions[path] = js_symbols(path, mask_js(text))
            elif language == "ruby":
                definitions[path] = ruby_symbols(path, text)
            else:
                definitions[path] = python_symbols(path, text)
        return definitions[path]

    while queue and len(visited) < MAX_BOUNDARIES and len(sites) < MAX_SITES:
        owner = queue.popleft()
        if owner in visited:
            continue
        visited.add(owner)
        boundaries.append(location(sources, owner, symbol=True))
        language = language_at(owner.path)
        body = sources[owner.path][owner.start:owner.end]
        if language == "javascript":
            body = mask_js(body)
        sites.extend(data_sites(sources, owner, body, language))
        queue.extend(call_targets(owner.path, body, language, symbols,
                                  import_symbols(sources, owner.path, language), sources, route.app_root))
    gaps = list(route.gaps)
    gaps.append("Static inspection identifies visible call sites. It cannot verify executed queries, branch coverage, or side effects.")
    if queue or len(sites) > MAX_SITES:
        gaps.append("The source trace reached its depth or site limit.")
    if not route.handler:
        gaps.append("A callable implementation boundary could not be resolved.")
    elif not sites:
        gaps.append("No data access calls matched in the source boundaries inspected.")
    gaps.append("Dynamic dispatch, framework callbacks, indirect dependencies, and external services may add operations.")
    return {"sites": list({(row["path"], row["line"], row["operation"]): row for row in sites[:MAX_SITES]}.values()),
            "boundaries": boundaries, "gaps": list(dict.fromkeys(gaps)),
            "suggested_checks": native_test_suggestions(project, tracked, route)}


def manual_route(project, tracked, sources, routes, payload):
    method = label(payload.get("method"), "Route method", 20).upper()
    if method not in HTTP_METHODS + ("IPC",):
        raise ValueError("Select an HTTP method or IPC")
    value = label(payload.get("path"), "Route path or channel", 300).strip()
    if method != "IPC" and not value.startswith("/"):
        raise ValueError("The HTTP path must start with /")
    source_name = payload.get("source_path")
    if source_name:
        source_name = relative(source_name, "Route source file")
    matches = [route for route in routes if route.method == method and route.path == value
               and (not source_name or route.source and route.source.path == source_name)]
    if len(matches) > 1:
        raise ValueError("Several sources declare this route. Select a source file.")
    if matches:
        return matches[0]
    if source_name and source_name not in tracked:
        raise ValueError("The source file must be tracked by Git")
    preliminary = Route(method, value, "Manual", None, None, [], [
        "No auditable tracked source declaration matched this route."
    ])
    if not source_name:
        return preliminary
    text = sources.get(source_name) or get_source(project, source_name)
    if not text:
        return preliminary
    exact = re.search(r"(?<![\w/])" + re.escape(value) + r"(?![\w/])", text)
    if not exact:
        return preliminary
    sources[source_name] = text
    source = Boundary(source_name, "Manual route reference", exact.start(), exact.end())
    return Route(method, value, "Manual", source, None, [(source_name, value)],
                 ["The manual source contains a route reference. Its dispatch behavior and HTTP method are unverified."])


def add_definition(draft, route, trace, sources):
    this_check = route.id
    checks = draft["checks"]
    if not any(item["id"] == this_check for item in checks):
        anchors = [json.dumps([path, token]) for path, token in route.anchors[:12] if 0 < len(token) <= 2000]
        if not anchors:
            raise ValueError("The route needs a bounded tracked source declaration")
        kind = "route source guard" if route.source else "controller source guard"
        checks.append({"id": this_check, "name": (f"{route.method} {route.path} {kind}")[:120],
                       "argv": ["python", "-c", "exec(" + repr(STATIC_CHECK) + ")", *anchors],
                       "cwd": ".", "timeout_seconds": 30,
                       "required": True, "phases": ["after"]})
    rubrics = draft["rubrics"]
    rubric = next((item for item in rubrics if item["stage"] == "build_review"), None)
    if rubric is None:
        key = "route-review"
        used = {item["id"] for item in rubrics}
        while key in used:
            key += "-agent"
        rubric = {"id": key, "name": "Route review", "actor": "agent", "stage": "build_review", "criteria": []}
        rubrics.append(rubric)
    scope = location(sources, route.source or route.handler)
    base = f"{route.method} {route.path}"
    origins = ", ".join(f"{item['path']}:{item['line']}" for item in trace["sites"][:3])
    evidence = f" Inspect candidate sites at {origins}." if origins else ""
    criteria = {
        this_check + "-behavior": (
            f"Trace {base} from {scope['path']}:{scope['line']} through its handler. "
            "Use the agreed request fixtures. Record the response and observable side effects."
        ),
        this_check + "-data": (
            f"Verify reads and writes for the exercised {base} cases.{evidence} "
            "Record fixture inputs and evidence. List untested branches and indirect operations."
        ),
    }
    existing = {item["id"] for item in rubric["criteria"]}
    rubric["criteria"].extend({"id": key, "description": text[:1000], "required": True}
                              for key, text in criteria.items() if key not in existing)
    return {"check_ids": [this_check], "rubric_ids": [rubric["id"]],
            "criterion_ids": list(criteria), "benchmark_ids": []}


def prepare(project, payload, *, actor="human"):
    project = Path(project).resolve(strict=True)
    tracked, sources, routes, gaps = static_catalog(project)
    routes, gaps = with_runtime(project, tracked, sources, routes, gaps)
    route_id = payload.get("route_id")
    if route_id:
        route = next((item for item in put_routes(routes) if item.id == route_id), None)
        if not route:
            if payload.get("method") and payload.get("path"):
                route = manual_route(project, tracked, sources, routes, payload)
            else:
                raise ValueError("The route could not be resolved in tracked source. Refresh the route list or enter it manually.")
    else:
        route = manual_route(project, tracked, sources, routes, payload)
    trace = trace_route(project, tracked, sources, route)
    trace["gaps"].extend(gap for gap in gaps if route.source and gap.startswith(route.source.path))
    result = {"route": route_data(sources, route), "trace": trace}
    if not route.anchors:
        return dict(result, status="needs_source", draft=None,
                    generated={"check_ids": [], "rubric_ids": [], "criterion_ids": [], "benchmark_ids": []})
    quality = Quality(project)
    publication = quality.publication()
    draft = quality.current_draft(publication)
    base = payload.get("base_revision")
    expected = payload.get("expected_revision")
    if base != (publication["revision"] if publication else None):
        raise ValueError("Quality publication changed. Reload before preparing.")
    if expected != draft["revision"]:
        raise ValueError("Quality draft changed. Reload before preparing.")
    definition = deepcopy(draft["definition"])
    generated = add_definition(definition, route, trace, sources)
    revision = validate(definition)["revision"]
    if revision != draft["revision"]:
        draft = quality.draft(definition, base, expected, actor=actor)
    return dict(result, status="prepared", draft=draft, generated=generated)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("discover", "prepare"))
    parser.add_argument("--project", required=True, type=Path)
    args = parser.parse_args()
    try:
        payload = json.loads(sys.stdin.read().strip() or "{}")
        if not isinstance(payload, dict):
            raise ValueError("Route input must be an object")
        if args.command == "discover":
            runtime = payload.get("runtime", False)
            if not isinstance(runtime, bool):
                raise ValueError("Runtime discovery must be true or false")
            result = discover(args.project, runtime=runtime, app=payload.get("app"))
        else:
            result = prepare(args.project, payload, actor="agent")
        print(json.dumps(result, ensure_ascii=True))
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
        print(str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
