"""Capability discovery reports project evidence without running candidates."""
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

from project_capabilities import discover, read_instruction


class ProjectCapabilitiesTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        temp = tempfile.TemporaryDirectory()
        cls.addClassCleanup(temp.cleanup)
        cls.project = Path(temp.name).resolve()
        cls.git("init", "-q")
        samples = {
            "AGENTS.md": "Check changed code and run the nearest tests.\n",
            "package.json": json.dumps({"name": "workspace", "private": True, "packageManager": "pnpm@10.0.0"}),
            "pnpm-lock.yaml": "lockfileVersion: '9.0'\n",
            "apps/ui/package.json": json.dumps({
                "name": "ui", "main": "desktop/main.cjs", "devDependencies": {"electron": "42", "vite": "7"},
                "dependencies": {"react": "19"},
                "scripts": {"test": "node --test", "dev": "vite --port=4100",
                            "benchmark": "node bench.mjs", "desktop": "electron ."},
            }),
            "apps/ui/desktop/main.cjs": "const { app } = require('electron');",
            "apps/ui/tests/navigation.test.js": "import test from 'node:test';\n",
            "apps/ui/tests/fixtures/request.json": "{}",
            "services/api/config/application.rb": "require 'rails/all'\n",
            "services/api/config/routes.rb": "Rails.application.routes.draw do\nend\n",
            "services/api/Gemfile": "gem 'rails'\n",
            "services/api/Gemfile.lock": "GEM\n",
            "services/api/bin/rails": "require 'rails/commands'\n",
            "services/api/test/route_test.rb": "class RouteTest < ActiveSupport::TestCase; end\n",
            "ops/pyproject.toml": "[project]\nname = 'ops'\nversion = '1.0'\n",
            "ops/tests/test_jobs.py": "import unittest\n",
            "agent/go.mod": "module example.invalid/agent\n",
            "agent/main.go": "package main\nfunc main() { http.ListenAndServe(\":9080\", nil) }\n",
            "agent/agent_test.go": "package main\n",
            "legacy/config.dat": "fixture\n",
            "workbench-capabilities.json": json.dumps({
                "schema_version": 1,
                "components": [{"id": "legacy", "label": "Legacy app", "stack": "Custom", "root": "legacy"}],
                "checks": [{"id": "smoke", "label": "Legacy smoke", "argv": ["zig", "build", "test"],
                            "cwd": "legacy", "component_id": "legacy", "kind": "test"}],
                "previews": [{"id": "preview", "label": "Legacy app", "argv": ["zig", "build", "run"],
                              "cwd": "legacy", "url": "http://localhost:8081/", "component_id": "legacy"}],
                "files": [{"id": "legacy-data", "label": "Legacy fixture", "path": "legacy/config.dat", "kind": "fixture"}],
            }),
            ".github/workflows/verify.yml": (
                "jobs:\n  check:\n    steps:\n      - name: Unit checks\n"
                "        run: pnpm run test\n        working-directory: apps/ui\n"
                "      - run: go test ./... && go vet ./...\n"
            ),
        }
        for name, value in samples.items():
            path = cls.project / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(value, encoding="utf-8")
        cls.git("add", ".")
        cls.git("-c", "user.name=Capability test", "-c", "user.email=capability@example.invalid",
                "-c", "commit.gpgsign=false", "commit", "-qm", "Synthetic project scan evidence")
        cls.head = cls.git("rev-parse", "HEAD")
        cls.git("branch", "candidate")
        cls.git("-c", "user.name=Capability test", "-c", "user.email=capability@example.invalid",
                "-c", "tag.gpgsign=false", "tag", "-am", "Synthetic tag", "v1")
        cls.git("update-ref", "refs/remotes/origin/previous", cls.head)

    @classmethod
    def git(cls, *args):
        return subprocess.check_output(["git", "-C", str(cls.project), *args], encoding="utf-8").strip()

    def test_detects_monorepo_commands_files_and_refs_without_execution(self):
        original_run = subprocess.run

        def read_only(argv, *args, **kwargs):
            self.assertEqual(argv[0], "git")
            self.assertIn(argv[3], {"ls-files", "for-each-ref", "rev-parse", "symbolic-ref"})
            return original_run(argv, *args, **kwargs)

        before = self.git("status", "--porcelain")
        with patch("project_capabilities.subprocess.run", side_effect=read_only):
            result = discover(self.project)
            again = discover(self.project)
        self.assertEqual(result, again)
        self.assertEqual(self.git("status", "--porcelain"), before)
        stacks = {(item["root"], item["stack"]) for item in result["components"]}
        self.assertTrue({("apps/ui", "Node.js"), ("services/api", "Rails"), ("ops", "Python"), ("agent", "Go")}
                        .issubset(stacks))
        electron = next(row for row in result["components"] if row["stack"] == "Electron")
        self.assertEqual(electron["entry_point"], "apps/ui/desktop/main.cjs")
        node = next(row for row in result["components"] if row["root"] == "apps/ui" and row["stack"] == "Node.js")
        self.assertIn("React", node["frameworks"])
        commands = {(row["cwd"], tuple(row["argv"])): row for row in result["checks"]}
        ui = commands[("apps/ui", ("pnpm", "run", "test"))]
        sources = {row["path"] for row in ui["source"]}
        self.assertTrue({".github/workflows/verify.yml", "pnpm-lock.yaml"}.intersection(sources))
        self.assertIn(".github/workflows/verify.yml", sources)
        self.assertIn(("services/api", ("ruby", "bin/rails", "test")), commands)
        self.assertIn(("ops", ("python", "-m", "unittest", "discover", "-s", "tests")), commands)
        self.assertIn(("agent", ("go", "test", "./...")), commands)
        self.assertEqual(commands["apps/ui", ("pnpm", "run", "benchmark")]["kind"], "benchmark")
        preview = next(row for row in result["previews"] if row["cwd"] == "apps/ui")
        self.assertEqual(preview["argv"], ["pnpm", "run", "dev"])
        self.assertEqual(preview["url"], "http://127.0.0.1:4100")
        refs = {row["ref"]: row for row in result["git"]["refs"]}
        self.assertEqual(refs["refs/tags/v1"]["sha"], self.head)
        self.assertEqual(refs["refs/remotes/origin/previous"]["kind"], "remote")
        self.assertIn("refs/heads/candidate", refs)
        fixture = next(row for row in result["files"] if row["path"] == "apps/ui/tests/fixtures/request.json")
        self.assertEqual(fixture["kind"], "fixture")

    def test_adapter_preserves_explicit_options(self):
        result = discover(self.project)
        checks = {row["id"]: row for row in result["checks"]}
        self.assertEqual(checks["smoke"]["argv"], ["zig", "build", "test"])
        self.assertEqual(checks["smoke"]["source"][0]["path"], "workbench-capabilities.json")
        self.assertEqual(checks["smoke"]["component_id"], "legacy")
        preview = next(row for row in result["previews"] if row["id"] == "preview")
        self.assertEqual(preview["url"], "http://localhost:8081/")
        fixture = next(row for row in result["files"] if row["id"] == "legacy-data")
        self.assertEqual(fixture["label"], "Legacy fixture")

    def test_reads_only_discovered_instruction_files(self):
        catalog = discover(self.project)
        guideline = next(row for row in catalog["files"] if row["path"] == "AGENTS.md")
        self.assertEqual(guideline["kind"], "instruction")
        self.assertIn("nearest tests", read_instruction(self.project, "AGENTS.md")["content"])
        for path in ("../AGENTS.md", "package.json"):
            with self.assertRaises(ValueError):
                read_instruction(self.project, path)

    def test_non_checkout_supports_manual_configuration(self):
        with tempfile.TemporaryDirectory() as folder:
            result = discover(Path(folder))
        self.assertEqual(result["checks"], [])
        self.assertIn("Manual settings", result["gaps"][0])


if __name__ == "__main__":
    unittest.main()
