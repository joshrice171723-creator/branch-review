from copy import deepcopy
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest import TestCase
from unittest.mock import patch

from design_host import approved_review, group_review


class BranchReviewConnection(TestCase):
    def test_approval_belongs_to_the_selected_project_group_and_commit(self):
        with TemporaryDirectory() as directory:
            root = Path(directory)
            state = {"reviewHost": "http://127.0.0.1:4100"}
            group = {"sha": "a" * 40, "slices": ["notes"]}
            build = {"branch": "feature", "attempts": [
                {"task":"prior","slice":"notes","outcome":"completed"},
                {"task":"final","slice":"notes","outcome":"completed"}]}
            source = {"runId":"final", "commit":group["sha"], "reviewedCommit":group["sha"],
                      "ref":"refs/heads/feature", "reviewId":"review", "status":"approved",
                      "approval":{"reviewer":"Fixture reviewer","at":"2026-11-22"},
                      "checklist":[{"status":"passed"},{"status":"not-applicable"}],
                      "slices":[{"id":"notes"}], "findings":[]}
            with patch("design_host.request", side_effect=[{"project":str(root)},source]):
                self.assertEqual(approved_review(root,state,build,group)["reviewId"], "review")
            with patch("design_host.request", return_value={"project":str(root / "other")}):
                with self.assertRaisesRegex(ValueError, "another project"):
                    group_review(root,state,build,group)
            for field, value in (("runId","prior"), ("commit","moved"), ("ref","refs/heads/demo"),
                                 ("reviewedCommit","different"), ("approval",None), ("slices",[]),
                                 ("status","changes-requested"), ("findings",[{"id":"fix"}]),
                                 ("checklist",[{"status":"not-started"}])):
                with self.subTest(field=field):
                    result = deepcopy(source)
                    result[field] = value
                    with patch("design_host.request", side_effect=[{"project":str(root)},result]):
                        with self.assertRaises(ValueError):
                            approved_review(root,state,build,group)
