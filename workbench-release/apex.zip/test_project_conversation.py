import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from chat_workflow import write_json
from design_workspace import DesignPlanner, Workspace
from project_conversation import guide
from server import Workbench


class ProjectConversationTest(unittest.TestCase):
    def setUp(self):
        folder = TemporaryDirectory()
        self.addCleanup(folder.cleanup)
        self.root = Path(folder.name).resolve()
        write_json(self.root / ".harness/project.json", {"agent": {"model": "fixture", "effort": "low"}})
        self.app = Workbench(self.root)
        self.addCleanup(self.app.pool.shutdown)
        self.workspace = Workspace(self.app)
        state = self.workspace.read()
        state.update(revision=4, approved=4, plan="Approved billing workflow", preview="http://localhost:3000/",
                     roadmap=[{"id": "m", "title": "Milestone", "slices": [{"id": "s", "title": "Slice"}]}])
        write_json(self.workspace.path, state)

    def test_cross_view_guidance_keeps_approved_plan_until_explicit_edit(self):
        reply = {"message": "Use the review preview.", "choices": ["Keep the current address", "Use the test preview"],
                 "proposal": {"kind": "settings", "title": "Preview the test app", "preview": "http://localhost:3001/"}}
        with patch.object(DesignPlanner, "agent", return_value=json.dumps(reply)) as planner:
            next_state = guide(self.app, {"revision": 4, "message": "Show the test preview",
                                         "context": {"view": "history", "ignored": "not context"}})
        self.assertIn("Approved billing workflow", planner.call_args.args[1])
        self.assertEqual((next_state["revision"], next_state["approved"], next_state["preview"]),
                         (4, 4, "http://localhost:3000/"))
        assistant = next_state["messages"][-1]
        self.assertEqual(assistant["context"], {"view": "history"})
        self.assertEqual(assistant["choices"], reply["choices"])
        self.assertEqual(assistant["proposal"]["before"], {"preview": "http://localhost:3000/"})

    def test_stale_design_revision_and_changed_settings_reject_proposals(self):
        with patch.object(DesignPlanner, "agent") as planner:
            with self.assertRaisesRegex(ValueError, "draft changed"):
                guide(self.app, {"revision": 3, "message": "Try this", "context": {"view": "workflow"}})
            planner.assert_not_called()
        first = self.workspace.update("settings", {"revision": 4, "branch": "", "preview": "http://localhost:3001/"})
        with self.assertRaisesRegex(ValueError, "Design settings changed"):
            self.workspace.update("settings", {"revision": 4, "branch": "", "preview": "http://localhost:3002/",
                                                "expected": {"preview": "http://localhost:3000/"}})
        self.assertEqual(self.workspace.read(), first)

    def test_quality_guidance_uses_source_backed_commands_without_publishing(self):
        evidence = {"git": {"branch": "main", "refs": [{"ref": "refs/heads/main", "sha": "a" * 40}]},
                    "checks": [{"id": "observed", "label": "Project checks", "argv": ["npm", "test"], "cwd": "app",
                                "source": [{"path": "app/package.json", "detail": "scripts.test"}]}],
                    "previews": [], "gaps": []}
        with (
            patch("project_capabilities.discover", return_value=evidence) as discover,
            patch.object(DesignPlanner, "agent", return_value='{"message":"Use the observed command."}') as planner,
        ):
            next_state = guide(self.app, {"revision": 4, "message": "Use the existing test runner",
                                         "context": {"view": "quality", "section": "checks"}})
        discover.assert_called_once_with(self.root)
        prompt = planner.call_args.args[1]
        self.assertIn('["npm", "test"]', prompt)
        self.assertIn("app/package.json", prompt)
        self.assertEqual(next_state["approved"], 4)
        self.assertFalse((self.root / ".harness" / "quality").exists())


if __name__ == "__main__":
    unittest.main()
