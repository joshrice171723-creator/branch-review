import http.client
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import socket
import sys
from tempfile import TemporaryDirectory
import threading
import time
import unittest

from preview_process import LOG_BYTES, PreviewProcess


APP = """import http.server, os, sys
print('old-marker' + 'x' * 66000)
print('fixture-cwd=' + os.path.basename(os.getcwd()))
print('fixture-argument=' + sys.argv[2])
host = http.server.ThreadingHTTPServer(('127.0.0.1', int(sys.argv[1])), http.server.SimpleHTTPRequestHandler)
host.serve_forever()
"""


class ManagedPreview(unittest.TestCase):
    def setUp(self):
        temp = TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.project = Path(temp.name).resolve()
        (self.project / "app").mkdir()
        self.preview = PreviewProcess(self.project)
        self.addCleanup(self.preview.close)

    def test_managed_process_uses_literal_arguments_and_has_bounded_logs(self):
        with socket.socket() as source:
            source.bind(("127.0.0.1", 0))
            port = source.getsockname()[1]
        literal = "rooms & notes"
        settings = dict(argv=[sys.executable, "-u", "-c", APP, str(port), literal], cwd="app",
                        url=f"http://127.0.0.1:{port}/")
        self.assertEqual(self.preview.setup(settings)["state"], "stopped")
        self.assertEqual(PreviewProcess(self.project).status()["settings"], settings)
        self.assertTrue(self.preview.start()["owned"])
        deadline = time.monotonic() + 20
        status = self.preview.status()
        while status["state"] == "starting" and time.monotonic() < deadline:
            time.sleep(.05)
            status = self.preview.status()
        self.assertEqual(status["state"], "running", status.get("exitCode"))
        self.assertLessEqual(len(status["log"].encode("utf-8")), LOG_BYTES)
        self.assertNotIn("old-marker", status["log"])
        self.assertIn("fixture-cwd=app", status["log"])
        self.assertIn("fixture-argument=" + literal, status["log"])
        other = PreviewProcess(self.project)
        self.assertEqual(other.start()["state"], "external")
        self.assertFalse(other.stop()["owned"])
        self.assertEqual(self.preview.status()["state"], "running")
        self.assertEqual(self.preview.stop()["state"], "stopped")

    def test_command_output_preview_needs_no_http_server(self):
        settings = dict(argv=[sys.executable, "-u", "-c", "print(12345); __import__('time').sleep(120)"], cwd="app", url="")
        self.assertEqual(self.preview.setup(settings)["url"], "")
        self.assertEqual(self.preview.start()["state"], "running")
        self.assertEqual(self.preview.stop()["state"], "stopped")

    def test_external_listener_is_never_spawned_over_or_stopped(self):
        app = ThreadingHTTPServer(("127.0.0.1", 0), SimpleHTTPRequestHandler)
        worker = threading.Thread(target=app.serve_forever, daemon=True)
        worker.start()
        self.addCleanup(app.server_close)
        self.addCleanup(app.shutdown)
        port = app.server_port
        settings = dict(argv=["absent-managed-command"], cwd=".", url=f"http://127.0.0.1:{port}/")
        self.assertEqual(self.preview.setup(settings)["state"], "external")
        self.assertFalse(self.preview.start()["owned"])
        self.assertEqual(self.preview.stop()["state"], "external")
        connection = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
        self.addCleanup(connection.close)
        connection.request("GET", "/")
        self.assertEqual(connection.getresponse().status, 200)

    def test_rejects_nonlocal_addresses_and_outside_directory(self):
        valid = dict(argv=[sys.executable], cwd=".", url="http://127.0.0.1:8000/")
        for url in ["https://example.com:8000", "http://127.0.0.1/", "http://127.0.0.1:0/", "http://app@localhost:8000/"]:
            with self.subTest(url=url), self.assertRaisesRegex(ValueError, "local HTTP"):
                self.preview.setup(dict(valid, url=url))
        with self.assertRaisesRegex(ValueError, "inside this project"):
            self.preview.setup(dict(valid, cwd=".."))
        self.assertEqual(self.preview.status()["state"], "unconfigured")
