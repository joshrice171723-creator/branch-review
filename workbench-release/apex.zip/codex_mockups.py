"""Generate and revise project mockups with the locally signed-in Codex CLI."""
import json
import os
from pathlib import Path
import subprocess
import tempfile
import uuid

from agent_adapter import build_command, subprocess_environment


def generate_mockup(prompt, previous=None):
    with tempfile.TemporaryDirectory(prefix="workbench-mockup-") as directory:
        cwd = Path(directory)
        command = build_command(None, cwd, model="gpt-6.2-sol", effort="low", sandbox="read-only")
        options = ["--disable", "shell_tool", "--enable", "image_generation", "--ephemeral"]
        if previous:
            reference = cwd / "reference.png"
            reference.write_bytes(previous)
            options.extend(["--image", str(reference)])
        command[-1:-1] = options
        request = ("Use the image-generation tool to produce one PNG mockup for this project. "
                   "Use the attached image as the starting point when revising it. "
                   "Return only the absolute path to the resulting PNG. Do not run shell commands.\n" + prompt)
        try:
            result = subprocess.run(command, cwd=cwd, input=request, capture_output=True, timeout=420,
                                    text=True, encoding="utf-8", errors="replace", env=subprocess_environment())
        except subprocess.TimeoutExpired as error:
            raise ValueError("Mockup generation timed out. Retry from the conversation.") from error
        if result.returncode:
            raise ValueError("Codex could not generate the mockup. Check the local Codex sign-in.")
    events = [json.loads(line) for line in result.stdout.splitlines() if line.strip()]
    thread = next((e.get("thread_id") for e in events if e.get("type") == "thread.started"), None)
    if not thread or not any(e.get("type") == "turn.completed" for e in events):
        raise ValueError("Codex did not finish generating an image.")
    folder = Path(os.environ.get("CODEX_HOME") or Path.home() / ".codex") / "generated_images" / str(uuid.UUID(thread))
    messages = [e["item"].get("text", "") for e in events if e.get("type") == "item.completed"
                and e.get("item", {}).get("type") == "agent_message"]
    candidates = [p for p in folder.glob("*.png") if p.resolve() == p and p.is_file()
                  and 0 < p.stat().st_size <= 32 * 1024 * 1024]
    named = [p for p in candidates if messages and p.name in messages[-1]]
    matches = named or candidates
    if len(matches) != 1:
        raise ValueError("Codex did not return a PNG from this image generation.")
    return matches[0].read_bytes()
