"""Check project separation, real portable setup, and managed cleanup."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from portable.environment import dispatch, inspect, picker_state
from portable.host_links import host_links


class WorkspaceTest(unittest.TestCase):
    def test_registry_worker_correlates_reads_and_rejects_mutations(self):
        with tempfile.TemporaryDirectory() as directory:
            project=Path(directory).resolve()
            registry=project/"registry"
            requests=[
                {"id":11,"name":"catalog","args":{}},
                {"id":12,"name":"list_projects","args":{}},
                {"id":13,"name":"add_project","args":{"path":str(project)}},
                {"id":14,"name":"inspect_environment","args":{"projectId":"0"*20}},
            ]
            result=subprocess.run([sys.executable,str(Path(__file__).with_name("portable")/"environment.py"),
                                   str(registry),"read_worker"],
                                  input="".join(json.dumps(item)+"\n" for item in requests),
                                  encoding="utf-8",capture_output=True,timeout=30,check=True)
            replies={item["id"]:item for item in map(json.loads,result.stdout.splitlines())}
            self.assertEqual(set(replies),{item["id"] for item in requests})
            self.assertIn("inspect_environment",[item["name"] for item in replies[11]["result"]])
            self.assertEqual(replies[12]["result"],{"projects":[]})
            self.assertIn("only read commands",replies[13]["error"])
            self.assertIn("registered project",replies[14]["error"])
            self.assertFalse(registry.exists())

    def test_picker_reads_current_registry_and_inspects_only_the_selected_project(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory).resolve()
            registry=root/"registry"
            self.assertEqual(picker_state(registry,None,None),{"projects":[],"selection":None})
            first,second=(root/"first",root/"second")
            first.mkdir()
            second.mkdir()
            one=dispatch(registry,"add_project",{"path":str(first)})
            two=dispatch(registry,"add_project",{"path":str(second)})
            with patch("portable.environment.inspect",wraps=inspect) as check:
                state=picker_state(registry,two["id"],one["id"])
                check.assert_called_once_with(second)
            self.assertEqual(state["projects"],[one,two])
            self.assertEqual(state["selection"]["environment"]["projectId"],two["id"])
            self.assertEqual(picker_state(registry,"0"*20,one["id"])["selection"]["id"],one["id"])
            second.rmdir()
            stale=picker_state(registry,two["id"],one["id"])
            self.assertEqual(stale["projects"],[one,two])
            self.assertEqual(stale["selection"]["id"],two["id"])
            self.assertIn("error",stale["selection"])
            self.assertNotIn("environment",stale["selection"])

    def test_history_uses_hosts_registered_in_its_own_project(self):
        with tempfile.TemporaryDirectory() as directory:
            first = Path(directory).resolve() / "first"
            second = first.parent / "second"
            hosts = first / ".harness" / "hosts"
            hosts.mkdir(parents=True)
            second.mkdir()
            local = {"version": 1, "name": "Preview", "url": "http://127.0.0.1:8787/#review"}
            (hosts / "preview.json").write_text(json.dumps(local), encoding="utf8")
            (hosts / "remote.json").write_text(json.dumps({**local, "url": "https://example.org/"}), encoding="utf8")
            self.assertEqual(host_links(first), [{"name": local["name"], "url": local["url"]}])
            self.assertEqual(host_links(second), [])

    def test_prepare_and_clean_two_unrelated_projects(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory).resolve()
            registry=root/"registry"
            first=root/"sample"
            second=root/"other"
            first.mkdir()
            second.mkdir()
            (first/"test_sample.py").write_text("import unittest\n",encoding="utf8")
            owned=first/"source.txt"
            owned.write_text("Keep this file",encoding="utf8")
            one=dispatch(registry,"add_project",{"path":str(first)})["id"]
            two=dispatch(registry,"add_project",{"path":str(second)})["id"]
            self.assertEqual(one,dispatch(registry,"add_project",{"path":str(first)})["id"])
            self.assertEqual(len(dispatch(registry,"list_projects",{})["projects"]),2)
            def call(name,**args):
                return dispatch(registry,name,dict(projectId=one,**args))
            result=call("prepare_environment")
            self.assertTrue(result["profileApplied"])
            self.assertEqual(result["checks"],["python_tests"])
            self.assertFalse(dispatch(registry,"inspect_environment",{"projectId":two})["installed"])
            scratch=Path(result["directories"]["scratch"])
            (scratch/"draft.tmp").write_text("old",encoding="utf8")
            stale=call("preview_cleanup")["previewId"]
            (scratch/"new.tmp").write_text("new",encoding="utf8")
            with self.assertRaisesRegex(ValueError,"changed"):
                call("clean_environment",previewId=stale)
            fresh=call("preview_cleanup")
            self.assertEqual(call("clean_environment",previewId=fresh["previewId"])["removed"],2)
            self.assertEqual(owned.read_text(encoding="utf8"),"Keep this file")
            self.assertTrue((first/".harness/profile.json").is_file())
            with self.assertRaisesRegex(ValueError,"registered"):
                dispatch(registry,"inspect_environment",{"projectId":"0"*20})

    def test_refuse_unowned_work_directory(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory).resolve()
            project=root/"app"
            manual=project/".harness/workspace-env"
            manual.mkdir(parents=True)
            (manual/"owner.json").write_text(json.dumps({"projectId":"different"}),encoding="utf8")
            entry=dispatch(root/"registry","add_project",{"path":str(project)})
            with self.assertRaisesRegex(ValueError,"ownership"):
                dispatch(root/"registry","preview_cleanup",{"projectId":entry["id"]})
