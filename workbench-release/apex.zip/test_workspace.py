"""Check project separation, real portable setup, and managed cleanup."""
import json
from pathlib import Path
import tempfile
import unittest

from portable.environment import dispatch
from portable.host_links import host_links


class WorkspaceTest(unittest.TestCase):
    def test_history_uses_hosts_registered_in_its_own_project(self):
        with tempfile.TemporaryDirectory() as directory:
            first = Path(directory).resolve() / "first"
            second = first.parent / "second"
            hosts = first / ".harness" / "hosts"
            hosts.mkdir(parents=True)
            second.mkdir()
            local = {"version": 1, "name": "Preview", "url": "http://127.0.0.1:8787/#review"}
            (hosts / "preview.json").write_text(json.dumps(local), encoding="utf8")
            (hosts / "remote.json").write_text(json.dumps({**local, "url": "https://example.org/"}), encoding="utf8")
            self.assertEqual(host_links(first), [{"name": local["name"], "url": local["url"]}])
            self.assertEqual(host_links(second), [])

    def test_prepare_and_clean_two_unrelated_projects(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory).resolve()
            registry=root/"registry"
            first=root/"sample"
            second=root/"other"
            first.mkdir()
            second.mkdir()
            (first/"test_sample.py").write_text("import unittest\n",encoding="utf8")
            owned=first/"source.txt"
            owned.write_text("Keep this file",encoding="utf8")
            one=dispatch(registry,"add_project",{"path":str(first)})["id"]
            two=dispatch(registry,"add_project",{"path":str(second)})["id"]
            self.assertEqual(one,dispatch(registry,"add_project",{"path":str(first)})["id"])
            self.assertEqual(len(dispatch(registry,"list_projects",{})["projects"]),2)
            def call(name,**args):
                return dispatch(registry,name,dict(projectId=one,**args))
            result=call("prepare_environment")
            self.assertTrue(result["profileApplied"])
            self.assertEqual(result["checks"],["python_tests"])
            self.assertFalse(dispatch(registry,"inspect_environment",{"projectId":two})["installed"])
            scratch=Path(result["directories"]["scratch"])
            (scratch/"draft.tmp").write_text("old",encoding="utf8")
            stale=call("preview_cleanup")["previewId"]
            (scratch/"new.tmp").write_text("new",encoding="utf8")
            with self.assertRaisesRegex(ValueError,"changed"):
                call("clean_environment",previewId=stale)
            fresh=call("preview_cleanup")
            self.assertEqual(call("clean_environment",previewId=fresh["previewId"])["removed"],2)
            self.assertEqual(owned.read_text(encoding="utf8"),"Keep this file")
            self.assertTrue((first/".harness/profile.json").is_file())
            with self.assertRaisesRegex(ValueError,"registered"):
                dispatch(registry,"inspect_environment",{"projectId":"0"*20})

    def test_refuse_unowned_work_directory(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory).resolve()
            project=root/"app"
            manual=project/".harness/workspace-env"
            manual.mkdir(parents=True)
            (manual/"owner.json").write_text(json.dumps({"projectId":"different"}),encoding="utf8")
            entry=dispatch(root/"registry","add_project",{"path":str(project)})
            with self.assertRaisesRegex(ValueError,"ownership"):
                dispatch(root/"registry","preview_cleanup",{"projectId":entry["id"]})
