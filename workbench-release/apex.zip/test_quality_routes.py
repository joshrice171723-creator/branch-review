"""Prepare source-backed draft checks from tracked routes."""
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from textwrap import dedent
import unittest
from unittest.mock import patch

from quality import Quality
from quality_routes import discover, prepare


class QualityRoutesTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        folder = TemporaryDirectory()
        cls.addClassCleanup(folder.cleanup)
        cls.project = Path(folder.name).resolve()
        samples = {
            ".gitignore": ".harness/\n",
            "server.mjs": """
                import { writeRecord } from './storage.mjs';
                const actions = new Set(['/api/default']);
                actions.add('/api/record');
                async function mutate(endpoint) {
                  if (endpoint === '/api/record') return await writeRecord();
                  return null;
                }
                const server = http.createServer(async (req, res) => {
                  const url = new URL(req.url, 'http://localhost');
                  if (req.method === 'POST' && actions.has(url.pathname)) {
                    return await mutate(url.pathname);
                  }
                });
            """,
            "storage.mjs": """
                export async function writeRecord() {
                  return store.query("INSERT INTO audit VALUES (1)");
                }
            """,
            "desktop/channels.cjs": """
                export const channels = { load: 'review:load' };
            """,
            "desktop/main.cjs": """
                import { channels } from './channels.cjs';
                ipcMain.handle(channels.load, async () => await store.findOne());
                ipcMain.on('review:closed', async () => await store.save());
            """,
            "test/record.test.mjs": """
                import test from 'node:test';
                test('POST /api/record', async () => {
                  await fetch('/api/record', {method: 'POST'});
                });
            """,
            "config/application.rb": "module Example; class Application < Rails::Application; end; end",
            "config/routes.rb": """
                Rails.application.routes.draw do
                  namespace :staff do
                    resources :orders, only: %i[index] do
                      resources :lines, only: %i[show]
                    end
                  end
                end
            """,
            "app/controllers/staff/orders_controller.rb": """
                class Staff::OrdersController < ApplicationController
                  def index
                    Order.where(active: true)
                  end
                  def featured
                    Order.find(1)
                  end
                end
            """,
            "app/controllers/staff/lines_controller.rb": """
                class Staff::LinesController < ApplicationController
                  def show
                    LoadLine.call(params[:id])
                  end
                end
            """,
            "app/services/load_line.rb": """
                class LoadLine
                  def self.call(id)
                    LineItem.find(id)
                  end
                end
            """,
            "routes.conf": "GET /reports/custom reports#index",
        }
        subprocess.run(["git", "init", "-q", str(cls.project)], check=True)
        for name, value in samples.items():
            path = cls.project / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(dedent(value).lstrip("\n"), encoding="utf-8")
        subprocess.run(["git", "-C", str(cls.project), "add", "."], check=True)
        subprocess.run(["git", "-C", str(cls.project), "-c", "user.name=Route test", "-c",
                        "user.email=routes@example.invalid", "-c", "commit.gpgsign=false", "commit", "-qm",
                        "Add route fixtures"], check=True)

    def payload(self, route=None, **extras):
        quality = Quality(self.project)
        policy = quality.publication()
        draft = quality.current_draft(policy)
        payload = {"expected_revision": draft["revision"], "base_revision": draft["base_revision"]}
        if route is not None:
            payload["route_id"] = route["id"]
        return dict(payload, **extras)

    def route(self, method, path, catalog=None):
        catalog = catalog or discover(self.project)
        return next(row for row in catalog["routes"] if (row["method"], row["path"]) == (method, path))

    def test_node_route_traces_import_and_reuses_edited_draft(self):
        route = self.route("POST", "/api/record")
        body = self.payload(route)
        result = prepare(self.project, body)
        self.assertEqual(result["status"], "prepared")
        self.assertEqual(route["source"], {"path": "server.mjs", "line": 3})
        self.assertIn({"path": "storage.mjs", "line": 2, "operation": "query/data access candidate: store.query",
                       "boundary": "writeRecord"}, result["trace"]["sites"])
        self.assertEqual(result["trace"]["suggested_checks"][0]["argv"],
                         ["node", "--test", "test/record.test.mjs"])
        self.assertFalse(result["generated"]["benchmark_ids"])
        draft = result["draft"]
        check_id = result["generated"]["check_ids"][0]
        config = draft["definition"]
        check = next(item for item in config["checks"] if item["id"] == check_id)
        command = [sys.executable, *check["argv"][1:]]
        subprocess.run(command, cwd=self.project, check=True, capture_output=True)
        source = self.project / "server.mjs"
        text = source.read_text()
        try:
            source.write_text(text.replace("actions.add('/api/record');", ""))
            self.assertNotEqual(subprocess.run(command, cwd=self.project, capture_output=True).returncode, 0)
        finally:
            source.write_text(text)
        with self.assertRaisesRegex(ValueError, "draft changed"):
            prepare(self.project, body)
        check["name"] = "Edited by reviewer"
        Quality(self.project).draft(config, draft["base_revision"], draft["revision"])
        again = prepare(self.project, self.payload(route))
        current = Quality(self.project).current_draft(None)
        self.assertEqual(again["draft"]["revision"], current["revision"])
        self.assertEqual(next(item["name"] for item in current["definition"]["checks"] if item["id"] == check_id),
                         "Edited by reviewer")

    def test_rails_resources_and_electron_channels(self):
        catalog = discover(self.project)
        self.assertIn(".", catalog["rails_apps"])
        rails = self.route("GET", "/staff/orders/:order_id/lines/:id", catalog)
        result = prepare(self.project, self.payload(rails))
        self.assertIn("app/services/load_line.rb", {item["path"] for item in result["trace"]["boundaries"]})
        self.assertTrue(any(item["operation"].endswith("LineItem.find") for item in result["trace"]["sites"]))
        self.assertFalse(any(row["method"] == "POST" and row["path"] == "/staff/orders" for row in catalog["routes"]))
        ipc = self.route("IPC", "review:load", catalog)
        self.assertEqual(ipc["transport"], "ipc")
        event = prepare(self.project, self.payload(ipc))
        self.assertTrue(any(item["operation"].endswith("store.findOne") for item in event["trace"]["sites"]))
        self.assertEqual(self.route("IPC", "review:closed", catalog)["source"]["path"], "desktop/main.cjs")

    def test_runtime_only_rails_route_prepares_without_second_boot(self):
        rows = {"verified": True, "warnings": [], "routes": [
            {"method": "GET", "path": "/featured(.:format)", "app_root": ".",
             "controller": "staff/orders", "action": "featured", "name": "featured"}
        ]}
        with patch("quality_route_runtime.discover_rails_runtime", return_value=rows) as runtime:
            catalog = discover(self.project, runtime=True, app=".")
            runtime.assert_called_once_with(self.project, app=".")
            observed = self.route("GET", "/featured", catalog)
            self.assertIsNotNone(observed["observed_at"])
            self.assertEqual(observed["provenance"], "rails_runtime")
            result = prepare(self.project, self.payload(observed))
            runtime.assert_called_once()
        self.assertEqual(result["status"], "prepared")
        self.assertEqual(result["route"]["handler"]["name"], "featured")
        self.assertTrue(any("controller source" in text for text in result["trace"]["gaps"]))
        self.assertFalse(result["generated"]["benchmark_ids"])

    def test_manual_requires_tracked_evidence(self):
        result = prepare(self.project, self.payload(method="GET", path="/unknown"))
        self.assertEqual(result["status"], "needs_source")
        self.assertIsNone(result["draft"])
        result = prepare(self.project, self.payload(method="GET", path="/reports/custom", source_path="routes.conf"))
        self.assertEqual(result["status"], "prepared")
        self.assertIn("unverified", " ".join(result["trace"]["gaps"]))
        with self.assertRaisesRegex(ValueError, "tracked by Git"):
            prepare(self.project, self.payload(method="GET", path="/invalid", source_path="missing.conf"))


if __name__ == "__main__":
    unittest.main()
