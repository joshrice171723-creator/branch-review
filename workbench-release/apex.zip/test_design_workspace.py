"""Exercise project decisions, versioned mockups, grouped reviews, and exact Git pushes."""
import json
import base64
import io
import os
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch
import uuid
import zlib

from audited_flow import Runtime, read, run, save
from chat_workflow import load
from design_build import Builds, CHECKLIST, git, resolve_groups
from design_workspace import DesignPlanner, Workspace
from server import Workbench
from test_audited_flow import FakeRuntime
from test_portable_panel import ROOT, DECISIONS, apply, request, service, setup, start, write_json


MAP = [{"id": "m1", "title": "Interface", "slices": [{"id": "a", "title": "Labels"}, {"id": "b", "title": "Buttons"}]},
       {"id": "m2", "title": "Release", "slices": [{"id": "c", "title": "Package"}]}]


def png(rgb):
    def chunk(name, data):
        content = name + data
        return struct.pack(">I", len(data)) + content + struct.pack(">I", zlib.crc32(content))
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">2I5B", 1, 1, 8, 2, 0, 0, 0)) +
            chunk(b"IDAT", zlib.compress(b"\0" + rgb)) + chunk(b"IEND", b""))


class DesignCases(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name).resolve()
        self.app = Workbench(self.root, sys.executable)
        self.addCleanup(self.app.pool.shutdown)
        self.workspace = Workspace(self.app)
        self.home = self.root / ".harness"
        self.home.mkdir()
        write_json(self.home / "project.json", {"agent": {"model": "fixture", "effort": "low"}})

    def test_build_history_retries_atomic_checkpoint_read(self):
        checkpoint = self.home / "loops" / "one" / "state.json"
        checkpoint.parent.mkdir(parents=True)
        write_json(checkpoint, {"stage": "plan", "history": [{"time": time.time(), "stage": "plan"}]})
        state = {"builds": [dict(id="build", roadmap=MAP, attempts=[dict(
            task="one", slice="a", started="2024-01-01T00:00:00+00:00", outcome="running")])]}
        read_text = Path.read_text
        checkpoint_reads = 0

        def deny_first_read(path, **options):
            nonlocal checkpoint_reads
            if path == checkpoint:
                checkpoint_reads += 1
                if checkpoint_reads == 1:
                    raise PermissionError(13, "Permission denied", str(path))
            return read_text(path, **options)

        with patch.object(Path, "read_text", deny_first_read):
            history = Builds(self.app).history(state)
        self.assertEqual(checkpoint_reads, 2)
        self.assertEqual([row["stage"] for row in history[0]["transitions"]], ["plan"])
        with patch.object(Path, "read_text", side_effect=PermissionError), patch("chat_workflow.time.sleep"):
            with self.assertRaises(PermissionError):
                load(checkpoint, {})

    def test_joint_draft_conflict_and_project_asset_versions(self):
        ws = self.workspace
        state = ws.update("draft", dict(revision=0, plan="First", roadmap=MAP))
        arrived, release = threading.Event(), threading.Event()
        def planner(*args):
            arrived.set()
            release.wait(10)
            return json.dumps(dict(plan="Agent proposal", roadmap=MAP))
        with patch.object(DesignPlanner, "agent", side_effect=planner):
            future = self.app.pool.submit(ws.update, "chat", dict(revision=1, message="Improve the plan"))
            self.assertTrue(arrived.wait(10))
            ws.update("draft", dict(revision=1, plan="Concurrent user edit", roadmap=MAP))
            release.set()
            state = future.result(10)
        self.assertEqual(state["plan"], "Concurrent user edit")
        self.assertIn("Agent proposal", [m["text"] for m in state["messages"]])
        with self.assertRaisesRegex(ValueError, "draft changed"):
            ws.update("draft", dict(revision=1, plan="stale", roadmap=MAP))
        with patch.object(DesignPlanner, "agent", return_value=json.dumps(dict(plan="Accepted draft", roadmap=MAP))):
            ws.update("chat", dict(revision=2, message="Update the draft"))
        first, second = png(b"\xff\0\0"), png(b"\0\xff\0")
        responses = [io.BytesIO(json.dumps({"data": [{"b64_json": base64.b64encode(raw).decode()}]}).encode())
                     for raw in (first, second, b"damaged")]
        with patch("design_images.urlopen", side_effect=responses) as provider, patch.dict(os.environ, {"OPENAI_API_KEY": "fixture"}):
            with service(self.root) as base:
                token = request(base, "api/state")["csrf_token"]
                post = lambda route, **p: request(base, "api/design/" + route, p, token)
                row = post("image", revision=3, message="Draw the label")["assets"][0]
                other = post("image", revision=3, message="Make it green", asset=row["id"])["assets"][1]
                edit = provider.call_args.args[0]
                body = json.loads(edit.data)
                self.assertTrue(edit.full_url.endswith("/images/edits"))
                self.assertTrue(provider.call_args_list[0].args[0].full_url.endswith("/images/generations"))
                self.assertEqual(base64.b64decode(body["images"][0]["image_url"].split(",")[1]), first)
                self.assertIn("Draw the label", body["prompt"])
                for item, raw in [(row, first), (other, second)]:
                    self.assertEqual(request(base, "api/design/asset?id=" + item["id"]), raw)
                post("attach", revision=3, slice="a", asset=row["id"])
                post("approve", revision=4)
                with self.assertRaisesRegex(OSError, "400") as failure:
                    post("image", revision=4, message="Another version", asset=other["id"])
                failure.exception.close()
            with service(self.root) as base:
                restored = request(base, "api/design")
                self.assertEqual((restored["attachments"], len(restored["assets"])), ({"a": row["id"]}, 2))
                self.assertEqual(restored["revisions"][-2]["author"], "agent")
                self.assertEqual(restored["roadmap"], MAP)
                self.assertEqual(restored["approved"], 4)
                self.assertEqual(ws.update("draft", dict(revision=4, plan="Edited", roadmap=MAP))["approved"], None)
        self.assertEqual(resolve_groups(MAP, "plan", None, "slice"), [["a"], ["b"], ["c"]])
        self.assertEqual(resolve_groups(MAP, "plan", None, "milestone"), [["a", "b"], ["c"]])
        self.assertEqual(resolve_groups(MAP, "milestone", "m1", "plan"), [["a", "b"]])
        self.assertEqual(resolve_groups(MAP, "slice", "c", "slice"), [["c"]])
        with self.assertRaisesRegex(ValueError, "Approve"):
            Builds(self.app).launch(dict(revision=5, scope="plan"))
        self.assertFalse(self.app.jobs)

    def test_failed_suggestion_repair_hides_question_and_preserves_draft(self):
        ws = self.workspace
        ws.update("draft", dict(revision=0, plan="Use the project labels", roadmap=MAP))
        for invalid in [None, ["  ", "Publish"], ["Publish", " publish "]]:
            with patch.object(DesignPlanner, "agent", return_value=json.dumps({"question": "Which label?", "suggestions": invalid})):
                state = ws.update("retry" if ws.read()["question"] else "chat", dict(revision=1, message="Pick a label"))
            self.assertEqual(state["plan"], "Use the project labels")
            self.assertEqual(state["question"]["suggestions"], [])
            self.assertTrue(state["question"]["error"])
            with self.assertRaises(ValueError):
                ws.update("answer", dict(revision=1, id=state["question"]["id"], message="Anything"))
            with self.assertRaises(ValueError):
                ws.update("approve", dict(revision=1))
        self.assertEqual(len([m for m in state["messages"] if m["author"] == "user"]), 1)
        self.assertFalse(state["builds"])
        with patch.object(DesignPlanner, "agent", return_value=json.dumps({"question": "Which label?", "suggestions": ["Publish", "Save"]})):
            ws.update("retry", dict(revision=1))
        self.assertEqual(self.app.live_state()["design_question"]["suggestions"], ["Publish", "Save"])

    def test_legacy_live_question_repairs_before_accepting_an_answer(self):
        rt = FakeRuntime(self.root)
        save(rt.folder / "state.json", dict(stage="question", question="Which clinic?", history=[], answers=[],
                                            returns={}, finding="", baseline=False, plan="Preserve me"))
        with patch.object(rt, "agent", return_value='{"suggestions":["", ""]}'):
            with self.assertRaisesRegex(ValueError, "Retry planning"):
                run(rt, "premature")
        state = read(rt.folder / "state.json")
        self.assertEqual((state["stage"], state["answers"], state["plan"]), ("question_retry", [], "Preserve me"))
        with patch.object(rt, "agent", return_value='{"suggestions":["Central","South"]}'):
            run(rt)
        state = read(rt.folder / "state.json")
        self.assertEqual((state["suggestions"], state["answers"]), (["Central", "South"], []))
        self.assertFalse(rt.finished)


class InstalledDesign(unittest.TestCase):
    def test_live_questions_use_each_projects_context_and_submit_the_exact_choice(self):
        for iteration in range(2):
            with tempfile.TemporaryDirectory() as tmp:
                project = Path(tmp).resolve()
                profile = setup(project)
                apply(project, profile)
                labels = [uuid.uuid4().hex[:8], uuid.uuid4().hex[:8]]
                home = project / ".harness"
                write_json(home / "candidate-labels.json", labels)
                (home / "question").touch()
                with service(project) as base:
                    token = request(base, "api/state")["csrf_token"]
                    tid = request(base, "api/task", dict(mode="build", action="Choose the label",
                        scope="Use one of " + ", ".join(labels), answers=DECISIONS), token)["created"]["data"]["task_id"]
                    rt = Runtime(project, tid, sys.executable)
                    run(rt)
                    pending = request(base, "api/state")["active_task"]
                    checkpoint = read(rt.folder / "state.json")
                    self.assertEqual(pending["suggestions"], labels)
                    self.assertEqual(checkpoint["suggestions"], labels)
                    prompts = [json.loads(line)["prompt"] for line in (home / "calls.jsonl").read_text().splitlines()]
                    self.assertTrue(all(label in prompts[-1] for label in labels))
                with service(project) as base:
                    restored = request(base, "api/live")["active_task"]
                    self.assertEqual(restored["suggestions"], labels)
                    answers = json.loads(subprocess.check_output(["node", str(ROOT / "test/design_controls.cjs")],
                                                                input=json.dumps(restored), text=True))
                    token = request(base, "api/state")["csrf_token"]
                    for answer in answers:
                        save(rt.folder / "state.json", checkpoint)
                        job = request(base, "api/chat", dict(message=answer, task=tid, question=pending["question"]), token)
                        deadline = time.monotonic() + 60
                        while time.monotonic() < deadline:
                            result = request(base, "api/job?id=" + job["id"])
                            if result["state"] in {"completed", "failed"}:
                                break
                            time.sleep(.1)
                        self.assertEqual(result["state"], "completed", result.get("error"))
                        self.assertEqual(read(rt.folder / "state.json")["answers"], [["Which label?", answer]])
                    if iteration:
                        self.assertTrue(set(previous).isdisjoint(restored["suggestions"]))
                    previous = labels

    def test_build_review_repair_and_explicit_push(self):
        with tempfile.TemporaryDirectory() as tmp, patch.dict(os.environ, {"APEX_MUSE_EXECUTABLE": sys.executable}):
            base = Path(tmp).resolve()
            root = base / "project"
            root.mkdir()
            remote = base / "origin.git"
            git(base, "init", "--bare", str(remote))
            profile = setup(root)
            apply(root, profile)
            agent = root / "exec"
            source = agent.read_text()
            source = source.replace('reply = "Wrote result.txt"', '''
    path = Path("slice-log.txt")
    with path.open("a") as log:
        log.write("Built slice\\\\n")
    reply = "Built slice"
''')
            agent.write_text(source)
            git(root, "init", "-b", "design")
            git(root, "config", "user.email", "test@example.test")
            git(root, "config", "user.name", "Design Test")
            tracked = root / "tracked-notes.txt"
            tracked.write_text("Original", encoding="utf-8")
            git(root, "add", "exec", tracked.name)
            git(root, "commit", "-qm", "Fixture")
            git(root, "remote", "add", "origin", str(remote))
            initial = git(root, "rev-parse", "HEAD")
            git(root, "push", "origin", "HEAD:refs/heads/design")
            (root / "personal-notes.txt").write_text("Keep local", encoding="utf-8")
            tracked.write_text("Keep staged", encoding="utf-8")
            git(root, "add", tracked.name)
            tracked.write_text("Keep unstaged", encoding="utf-8")
            app = Workbench(root, sys.executable)
            try:
                ws = Workspace(app)
                approved_sha = None
                destination = "workbench-tests/notes"

                def review_host(origin, path, body=None, token=None):
                    self.assertEqual(origin, "http://127.0.0.1:54321")
                    if path == "/api/workbench":
                        return {"project": str(root)}
                    if path == "/api/state":
                        return {"token":"fixture-token"}
                    if path == "/api/workbench-push":
                        self.assertEqual(token, "fixture-token")
                        self.assertEqual(body["expectedTarget"], destination)
                        self.assertEqual(body["commit"], approved_sha)
                        ref = "refs/heads/design"
                        git(root, "push", "origin", approved_sha + ":" + ref)
                        return {"result":{"repository":destination, "remote":"origin", "commit":git(remote,"rev-parse",ref), "ref":ref}}
                    self.assertTrue(path.startswith("/api/workbench-review?run="))
                    run_id = path.split("=", 1)[1]
                    sha = read(root / ".harness" / "loops" / run_id / "state.json")["design_sha"]
                    return {"status":"approved" if approved_sha == sha else "reviewing", "reviewId":"fixture-" + run_id,
                            "runId":run_id, "commit":sha, "reviewedCommit":sha, "ref":"refs/heads/design",
                            "slices":[{"id":"a"},{"id":"b"}], "approval":{"reviewer":"Fixture reviewer","at":"test"},
                            "findings":[], "checklist":[{"status":"passed"}],"pushTarget":destination}

                connection = patch("design_host.request", side_effect=review_host)
                connection.start()
                self.addCleanup(connection.stop)
                ws.update("settings", dict(revision=0, preview="", branch="design", reviewHost="http://127.0.0.1:54321"))
                ws.update("draft", dict(revision=0, plan="Implement each slice", roadmap=MAP))
                ws.update("approve", dict(revision=1))
                build = Builds(app)
                args = dict(revision=1, scope="milestone", key="m1", frequency="plan", decisions=DECISIONS)
                with self.assertRaisesRegex(ValueError, "workflow changed"):
                    build.launch(dict(args, stages={}))
                self.assertFalse(ws.read()["builds"])
                (root / ".harness/hold-plan").touch()
                key = build.launch(args)["builds"][-1]["id"]
                deadline = time.monotonic() + 60
                while time.monotonic() < deadline and not any(a["active"] for a in build.history()):
                    time.sleep(.1)
                active = build.history()[-1]
                self.assertTrue(active["active"])
                self.assertEqual(active["step"], "plan")
                reconnected = Workbench(root)
                try:
                    restored = Builds(reconnected).history()[-1]
                    self.assertEqual((restored["active"], restored["step"]), (True, "plan"))
                finally:
                    reconnected.pool.shutdown()
                app.post("/api/chat/cancel", {"id": active["job"]})
                deadline = time.monotonic() + 30
                while time.monotonic() < deadline and ws.read()["builds"][-1]["status"] == "working":
                    time.sleep(.1)
                self.assertEqual(build.history()[-1]["outcome"], "cancelled")
                self.assertFalse(build.history()[-1]["active"])
                (root / ".harness/release-plan").touch()
                build.advance(key)
                def wait_review():
                    pending = ws.read()["builds"][-1]["groups"][0]["pending"]
                    deadline = time.monotonic() + 240 * max(1, len(pending))
                    while time.monotonic() < deadline:
                        run_state = ws.read()["builds"][-1]
                        if run_state["status"] in {"failed", "review"} or run_state.get("error"):
                            break
                        time.sleep(.2)
                    self.assertEqual(run_state["status"], "review", run_state)
                    self.assertEqual(git(remote, "rev-parse", "refs/heads/design"), initial)
                    group = run_state["groups"][0]
                    self.assertEqual(group["slices"], ["a", "b"])
                    return dict(build=key, group=0, slices=group["slices"], sha=group["sha"], destination=str(remote))
                target = wait_review()
                with self.assertRaises(ValueError):
                    build.decision("review", dict(target, checklist=CHECKLIST[:-1]))
                with self.assertRaises(ValueError):
                    build.decision("push", target)
                reopened = build.decision("finding", dict(target, affected=["b"], text="Repair the button"))
                self.assertEqual(reopened["builds"][-1]["groups"][0]["pending"], ["b"])
                with self.assertRaises(ValueError):
                    build.decision("review", dict(target, checklist=CHECKLIST))
                build.advance(key)
                repaired = wait_review()
                self.assertNotEqual(repaired["sha"], target["sha"])
                self.assertEqual([a["slice"] for a in build.history()], ["a", "a", "b", "b"])
                self.assertFalse(any(a["active"] for a in build.history()))
                approved_sha = repaired["sha"]
                build.decision("review", repaired)
                repaired["expectedTarget"] = destination
                with self.assertRaisesRegex(ValueError, "destination changed"):
                    build.decision("push", dict(repaired,expectedTarget="different/project"))
                self.assertEqual(git(remote, "rev-parse", "refs/heads/design"), initial)
                git(root, "commit", "--allow-empty", "--only", "-qm", "Changed head")
                with self.assertRaisesRegex(ValueError, "checkout changed"):
                    build.decision("push", repaired)
                git(root, "switch", "--detach", repaired["sha"])
                git(root, "branch", "-f", "design", repaired["sha"])
                git(root, "switch", "design")
                build.decision("push", repaired)
                self.assertEqual(git(remote, "rev-parse", "refs/heads/design"), repaired["sha"])
                self.assertNotIn("personal-notes.txt", git(remote, "ls-tree", "--name-only", repaired["sha"]).splitlines())
                self.assertEqual((root / "personal-notes.txt").read_text(encoding="utf-8"), "Keep local")
                self.assertEqual(git(remote, "show", repaired["sha"] + ":" + tracked.name), "Original")
                self.assertEqual(git(root, "show", ":" + tracked.name), "Keep staged")
                self.assertEqual(tracked.read_text(encoding="utf-8"), "Keep unstaged")
                git(root, "commit", "--allow-empty", "--only", "-qm", "Remote advanced")
                git(root, "push", "origin", "design")
                advanced = git(remote, "rev-parse", "refs/heads/design")
                git(root, "switch", "--detach", repaired["sha"])
                git(root, "branch", "-f", "design", repaired["sha"])
                git(root, "switch", "design")
                with self.assertRaises(ValueError):
                    build.decision("push", repaired)
                self.assertEqual(git(remote, "rev-parse", "refs/heads/design"), advanced)
                reopened = build.decision("finding", dict(repaired, affected=["a"], text="Correct the approved label"))
                self.assertEqual(reopened["builds"][-1]["groups"][0]["pending"], ["a"])
                with self.assertRaises(ValueError):
                    build.decision("push", repaired)
            finally:
                app.pool.shutdown()

