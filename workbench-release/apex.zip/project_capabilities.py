"""Read tracked project evidence and offer command candidates."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shlex
import subprocess
import sys
from urllib.parse import urlsplit

from quality import relative


ADAPTER = "workbench-capabilities.json"
MAX_PATHS = 20_000
MAX_BYTES = 384 * 1024
MAX_CONTENT = 12 * 1024 * 1024
MAX_FILES = 300
MAX_REFS = 250
EXCLUDED = {".harness", "node_modules", "vendor", ".venv", "venv", "dist", "coverage", ".git"}
PACKAGE_LOCKS = {
    "package-lock.json": "npm", "npm-shrinkwrap.json": "npm", "pnpm-lock.yaml": "pnpm",
    "yarn.lock": "yarn", "bun.lock": "bun", "bun.lockb": "bun",
}
MANIFESTS = {
    "package.json", "pyproject.toml", "setup.cfg", "setup.py", "Pipfile", "Gemfile", "go.mod", "Cargo.toml",
    "pom.xml", "build.gradle", "build.gradle.kts", "Makefile", "Justfile",
}
LOCKFILES = set(PACKAGE_LOCKS) | {"poetry.lock", "uv.lock", "Pipfile.lock", "Gemfile.lock", "go.sum", "Cargo.lock"}
CONFIGS = {
    ADAPTER, ".env.example", ".env.sample", "compose.yaml", "compose.yml", "docker-compose.yml",
    "docker-compose.yaml", "Dockerfile", "Procfile", "Procfile.dev", "playwright.config.js", "playwright.config.ts",
    "pytest.ini", "tox.ini", "jest.config.js", "vitest.config.ts", "vitest.config.js",
}
CI_TOOLS = {"ruby", "python", "python3", "pytest", "tox", "uv", "bundle", "npm", "pnpm", "yarn",
            "bun", "go", "cargo", "mvn", "gradle", "dotnet", "make", "ruff", "ctest"}
CHECK_KINDS = {"test", "lint", "build", "typecheck", "format", "benchmark", "check"}
FILE_KINDS = {"fixture", "test", "manifest", "lockfile", "ci", "config", "script", "instruction"}
SAFE_ID = re.compile(r"[a-z][a-z0-9_-]{0,63}\Z")


def git_read(project, *args):
    try:
        result = subprocess.run(["git", "-C", str(project), *args], capture_output=True,
                                timeout=15, env=dict(os.environ, GIT_OPTIONAL_LOCKS="0"))
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None
    return result.stdout.decode("utf-8", errors="replace") if result.returncode == 0 else None


def git_metadata(project):
    format_ref = "%(refname)%00%(objecttype)%00%(objectname)%00%(*objecttype)%00%(*objectname)%00%(symref)"
    raw = git_read(project, "for-each-ref", "--format=" + format_ref, "refs/heads", "refs/remotes", "refs/tags") or ""
    refs = []
    prefixes = {"heads": "branch", "remotes": "remote", "tags": "tag"}
    for line in raw.splitlines():
        ref, kind, sha, peeled_kind, peeled_sha, symbolic = line.split("\0")
        if symbolic or (kind != "commit" and peeled_kind != "commit"):
            continue
        _, namespace, name = ref.split("/", 2)
        refs.append({"name": name, "ref": ref, "kind": prefixes[namespace],
                     "sha": sha if kind == "commit" else peeled_sha})
    head = (git_read(project, "rev-parse", "--verify", "HEAD") or "").strip() or None
    branch = (git_read(project, "symbolic-ref", "--quiet", "--short", "HEAD") or "").strip() or None
    refs.sort(key=lambda item: (item["kind"] != "branch", item["kind"], item["name"] != branch, item["name"]))
    return {"head": head, "branch": branch, "refs": refs[:MAX_REFS]}


def stable(kind, *values):
    digest = hashlib.sha256(json.dumps(values, ensure_ascii=True, separators=(",", ":")).encode()).hexdigest()[:18]
    return kind + "-" + digest


def at(root, name):
    return (PurePosixPath(root) / name).as_posix()


def where(path):
    return PurePosixPath(path).parent.as_posix()


def evidence(path, detail, line=None):
    row = {"path": path, "detail": detail}
    if line is not None:
        row["line"] = line
    return row


def file_kind(path):
    parts = PurePosixPath(path).parts
    name = parts[-1]
    suffix = PurePosixPath(name).suffix
    if name.lower() in {"agents.md", "claude.md", "instructions.md", "rules.md", "copilot-instructions.md",
                        "grading.md", "rubric.md", "workbench-quality.json"}:
        return "instruction"
    if parts[:2] == (".github", "workflows") or path in {".gitlab-ci.yml", "azure-pipelines.yml", ".circleci/config.yml"}:
        return "ci"
    if name in LOCKFILES:
        return "lockfile"
    if name in MANIFESTS or re.fullmatch(r"requirements(?:[-_.][^/]+)?\.txt", name) or suffix in {".csproj", ".fsproj"}:
        return "manifest"
    if name in CONFIGS or path.endswith(("config/routes.rb", "config/application.rb")):
        return "config"
    if {"fixture", "fixtures", "factories", "testdata", "__fixtures__"}.intersection(parts[:-1]) \
            or name == "seeds.rb" or ".fixture." in name:
        return "fixture"
    if {"test", "tests", "spec", "__tests__"}.intersection(parts[:-1]) or re.search(
            r"(?:^test_|_test\.|_spec\.|\.test\.|\.spec\.)", name):
        return "test"
    if {"bin", "scripts"}.intersection(parts[:-1]) or name in {"manage.py", "app.py", "server.mjs", "server.js", "server.py"}:
        return "script"
    return None


class Inventory:
    def __init__(self, project, paths):
        self.project = project
        self.paths = frozenset(paths)
        self.content = {}
        self.read_bytes = 0
        self.components = {}
        self.checks = {}
        self.previews = {}
        self.files = {}
        self.gaps = []

    def text(self, name):
        if name not in self.content:
            self.content[name] = None
            if name in self.paths:
                try:
                    path = (self.project / name).resolve(strict=True)
                    if path.is_relative_to(self.project) and path.is_file():
                        size = path.stat().st_size
                        if size <= MAX_BYTES and self.read_bytes + size <= MAX_CONTENT:
                            self.read_bytes += size
                            self.content[name] = path.read_text(encoding="utf-8-sig")
                        elif self.read_bytes + size > MAX_CONTENT:
                            self.gaps.append("The source scan reached its content limit.")
                except (OSError, UnicodeError):
                    pass
        return self.content[name]

    def json_object(self, name):
        text = self.text(name)
        if text is None:
            return {}
        try:
            value = json.loads(text)
            if isinstance(value, dict):
                return value
        except ValueError:
            pass
        self.gaps.append(f"{name} does not contain a readable JSON object.")
        return {}

    def component(self, root, stack, title, source, identifier=None):
        identifier = identifier or stable("component", root, stack)
        prior = self.components.get(identifier)
        if prior and (prior["root"], prior["stack"]) != (root, stack):
            raise ValueError("The component ID already identifies a different folder or stack")
        self.components[identifier] = {"id": identifier, "label": title, "root": root, "stack": stack,
                                        "source": list(source) + (prior["source"] if prior else [])}
        return identifier

    def owner(self, path):
        directory = PurePosixPath(path)
        matching = [row for row in self.components.values() if directory.is_relative_to(row["root"])]
        return max(matching, key=lambda row: (len(PurePosixPath(row["root"]).parts), row["id"]))["id"] if matching else None

    def command(self, kind, title, argv, cwd, source, component_id=None, identifier=None, url=None):
        registry = self.previews if kind == "preview" else self.checks
        key = (cwd, tuple(argv))
        prior = registry.get(key, {})
        if identifier and any(other_key != key and item["id"] == identifier for other_key, item in registry.items()):
            raise ValueError("The command ID already identifies a different command")
        row = {"id": identifier or prior.get("id") or stable("command", cwd, argv),
               "label": title, "argv": list(argv), "cwd": cwd, "kind": kind,
               "component_id": component_id or prior.get("component_id"), "source": list(source) + prior.get("source", [])}
        if url:
            row["url"] = url
        registry[key] = row

    def matching_paths(self, root, predicate):
        prefix = "" if root == "." else root + "/"
        return [path for path in sorted(self.paths) if path.startswith(prefix) and predicate(path.removeprefix(prefix))]

    def file(self, path, kind, title=None, identifier=None):
        self.files[path] = {"id": identifier or stable("file", path), "label": title or path,
                            "path": path, "kind": kind, "component_id": self.owner(path)}


def package_manager(inventory, manifest, metadata):
    root = where(manifest)
    declared = metadata.get("packageManager")
    if isinstance(declared, str) and (manager := re.match(r"^(npm|pnpm|yarn|bun)@", declared)):
        return manager[1], [evidence(manifest, "packageManager")]
    folders = [PurePosixPath(root), *PurePosixPath(root).parents]
    for folder in folders:
        base = folder.as_posix()
        locks = [(at(base, name), manager) for name, manager in PACKAGE_LOCKS.items()
                 if at(base, name) in inventory.paths]
        distinct = {manager for _, manager in locks}
        if len(distinct) == 1:
            return locks[0][1], [evidence(path, "Package manager lockfile") for path, _ in locks]
        if len(distinct) > 1:
            inventory.gaps.append(f"{base} has lockfiles for several package managers. Select the intended command.")
            break
        ancestor = at(base, "package.json")
        if ancestor != manifest and ancestor in inventory.paths:
            declared = inventory.json_object(ancestor).get("packageManager")
            if isinstance(declared, str) and (manager := re.match(r"^(npm|pnpm|yarn|bun)@", declared)):
                return manager[1], [evidence(ancestor, "Workspace packageManager")]
    return "npm", []


def check_kind(name):
    tokens = set(re.split(r"[:_.\-\s]+", name.lower()))
    if tokens.intersection({"test", "tests", "e2e", "spec", "unittest", "pytest", "rspec", "ctest", "tox"}):
        return "test"
    if tokens.intersection({"bench", "benchmark", "benchmarks"}):
        return "benchmark"
    if tokens.intersection({"typecheck", "types", "tsc"}) or {"type", "check"}.issubset(tokens):
        return "typecheck"
    for kind in ("lint", "format", "build", "check"):
        if kind in tokens:
            return kind
    return None


def preview_url(script):
    match = re.search(r"(?:^|\s)(?:--port[=\s]+|PORT=)([1-9][0-9]{0,4})(?=\s|$)", script)
    if match and int(match[1]) <= 65535:
        return f"http://127.0.0.1:{match[1]}"
    return None


def detect_node(inventory, manifest):
    metadata = inventory.json_object(manifest)
    if not metadata:
        return
    root = where(manifest)
    manager, locks = package_manager(inventory, manifest, metadata)
    name = metadata.get("name")
    name = name if isinstance(name, str) and name.strip() else "Node.js"
    component = inventory.component(root, "Node.js", name, [evidence(manifest, "Node.js package manifest"), *locks])
    dependencies = {
        dependency for key in ("dependencies", "devDependencies", "optionalDependencies", "peerDependencies")
        for dependency in (metadata[key] if isinstance(metadata.get(key), dict) else {})
    }
    frameworks = {"react": "React", "next": "Next.js", "vite": "Vite", "express": "Express", "fastify": "Fastify"}
    supported = [title for key, title in frameworks.items() if key in dependencies]
    if supported:
        inventory.components[component]["frameworks"] = supported
        inventory.components[component]["source"].append(evidence(manifest, "Frameworks declared in dependencies"))
    scripts = metadata.get("scripts")
    scripts = scripts if isinstance(scripts, dict) else {}
    if "electron" in dependencies:
        desktop_scripts = [key for key, script in scripts.items() if isinstance(script, str) and re.search(
            r"(?:^|[ \t])electron(?:-forge|-vite|\.cmd)?(?=[ \t]|$)", script)]
        entry = metadata.get("main")
        try:
            entry = at(root, relative(entry, "Electron main entry")) if isinstance(entry, str) else None
        except ValueError:
            entry = None
        if entry and entry in inventory.paths and inventory.text(entry) is not None and (
                desktop_scripts or "electron" in inventory.text(entry)):
            desktop = inventory.component(root, "Electron", f"{name} desktop",
                                          [evidence(manifest, "Electron dependency"),
                                           *[evidence(manifest, f"scripts.{key}") for key in sorted(desktop_scripts)[:5]],
                                           evidence(entry, "Tracked Electron main entry")])
            inventory.components[desktop]["entry_point"] = entry
        elif desktop_scripts:
            desktop = inventory.component(root, "Electron", f"{name} desktop",
                                          [evidence(manifest, "Electron dependency"),
                                           *[evidence(manifest, f"scripts.{key}") for key in sorted(desktop_scripts)[:5]]])
        else:
            desktop = None
    else:
        desktop = None
    for key, script in sorted(scripts.items()):
        if not isinstance(script, str) or not script.strip() or "no test specified" in script.lower():
            continue
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9:_.-]{0,79}", key):
            continue
        is_desktop = desktop and key in desktop_scripts
        kind = "preview" if key in {"dev", "start", "serve", "preview"} or (is_desktop and key == "desktop") else check_kind(key)
        if kind:
            argv = [manager, "test"] if manager == "npm" and key == "test" else [manager, "run", key]
            reason = [evidence(manifest, f"scripts.{key}"), *locks]
            owner = desktop if is_desktop else component
            inventory.command(kind, f"{key} · {name}", argv, root, reason, owner,
                              url=preview_url(script) if kind == "preview" else None)


def detect_rails(inventory, root):
    launcher = at(root, "bin/rails")
    application = at(root, "config/application.rb")
    gemfile = at(root, "Gemfile")
    if inventory.text(launcher) is None or inventory.text(application) is None:
        return
    source = [evidence(launcher, "Rails entry point"), evidence(application, "Rails application")]
    for name in (gemfile, at(root, "Gemfile.lock")):
        if name in inventory.paths:
            source.append(evidence(name, "Ruby dependency evidence"))
    component = inventory.component(root, "Rails", "Rails", source)
    tests = inventory.matching_paths(root, lambda path: path.startswith("test/") and path.endswith("_test.rb"))
    if tests:
        inventory.command("test", "Rails tests", ["ruby", "bin/rails", "test"], root,
                          [evidence(launcher, "Rails test runner"), evidence(tests[0], "Tracked Rails test")], component)
    specs = inventory.matching_paths(root, lambda path: path.startswith("spec/") and path.endswith("_spec.rb"))
    if specs and "rspec-rails" in (inventory.text(gemfile) or ""):
        inventory.command("test", "RSpec", ["bundle", "exec", "rspec"], root,
                          [evidence(gemfile, "RSpec dependency"), evidence(specs[0], "Tracked RSpec example")], component)
    inventory.command("preview", "Rails server", ["ruby", "bin/rails", "server"], root,
                      [evidence(launcher, "Rails application launcher")], component)


def detect_python(inventory, root, markers, test_files):
    component = inventory.component(root, "Python", "Python", [evidence(path, "Tracked Python project evidence")
                                                               for path in (markers or test_files[:1])[:5]])
    pytest_config = next((name for name in markers if PurePosixPath(name).name == "pytest.ini"
                          or re.search(r"\[tool\.pytest(?:\.ini_options)?\]", inventory.text(name) or "")
                          or re.search(r"(?mi)^\s*pytest(?:\W|$)", inventory.text(name) or "")), None)
    if pytest_config and test_files:
        inventory.command("test", "Pytest", ["python", "-m", "pytest"], root,
                          [evidence(pytest_config, "Pytest configuration or dependency"),
                           evidence(test_files[0], "Tracked Python test")], component)
    for directory in ("tests", "test", "."):
        folder = at(root, directory)
        sample = next((path for path in test_files if where(path) == folder and PurePosixPath(path).name.startswith("test")
                       and re.search(r"(?m)^\s*(?:import\s+unittest\b|from\s+unittest\b)", inventory.text(path) or "")), None)
        if sample:
            inventory.command("test", "Python unittest", ["python", "-m", "unittest", "discover", "-s", directory], root,
                              [evidence(sample, "Tracked unittest module")], component)
    launcher = at(root, "manage.py")
    if "django.core.management" in (inventory.text(launcher) or ""):
        inventory.command("preview", "Django server", ["python", "manage.py", "runserver"], root,
                          [evidence(launcher, "Django application launcher")], component)


def detect_other(inventory, manifest):
    root = where(manifest)
    name = PurePosixPath(manifest).name
    content = inventory.text(manifest)
    if content is None:
        return
    if name == "go.mod":
        stack = "Go"
        tests = inventory.matching_paths(root, lambda path: path.endswith("_test.go"))
        argv = ["go", "test", "./..."]
    elif name == "Cargo.toml":
        stack = "Rust"
        files = inventory.matching_paths(root, lambda path: path.endswith(".rs"))
        tests = next(([path] for path in files if "/tests/" in "/" + path or "#[test]" in (inventory.text(path) or "")), [])
        argv = ["cargo", "test"]
    elif name == "pom.xml":
        stack = "Maven"
        tests = inventory.matching_paths(root, lambda path: path.startswith("src/test/") and path.endswith(".java"))
        argv = ["mvn", "test"]
    else:
        stack = ".NET"
        tests = [manifest] if re.search(r"Microsoft\.NET\.Test\.Sdk|<IsTestProject>true</IsTestProject>", content) else []
        argv = ["dotnet", "test", name]
    reasons = [evidence(manifest, f"{stack} project manifest")]
    lock = {"Go": "go.sum", "Rust": "Cargo.lock"}.get(stack)
    if lock and at(root, lock) in inventory.paths:
        reasons.append(evidence(at(root, lock), "Dependency lockfile"))
    component = inventory.component(root, stack, stack, reasons, stable("component", manifest, stack))
    if tests:
        inventory.command("test", f"{stack} tests", argv, root,
                          [*reasons, evidence(tests[0], "Tracked test evidence")], component)
    if stack == ".NET" and "Microsoft.NET.Sdk.Web" in content:
        inventory.command("preview", ".NET web app", ["dotnet", "run", "--project", name], root, reasons, component)
    elif stack == "Maven" and "spring-boot-maven-plugin" in content:
        inventory.command("preview", "Spring Boot server", ["mvn", "spring-boot:run"], root, reasons, component)
    elif stack == "Go":
        main = at(root, "main.go")
        if re.search(r"\b(?:http\.ListenAndServe(?:TLS)?|gin\.Default)\s*\(", inventory.text(main) or ""):
            inventory.command("preview", "Go web app", ["go", "run", "."], root,
                              [evidence(main, "Go HTTP application entry point")], component)


def github_steps(inventory, path):
    text = inventory.text(path)
    if text is None or re.search(r"(?m)^\s*defaults\s*:", text):
        return
    lines = text.splitlines()
    step_start = re.compile(r"^\s*-\s+")
    for index, line in enumerate(lines):
        match = re.match(r"^(\s*)(?:-\s+)?run:\s+(.+?)\s*$", line)
        if not match or re.search(r"[|;&<>\r\n]|\$\{|\$[A-Z_]|\x60", match[2]):
            continue
        try:
            argv = shlex.split(match[2], comments=True)
            if len(argv) == 1 and " " in argv[0]:
                argv = shlex.split(argv[0], comments=True)
        except ValueError:
            continue
        if not argv or argv[0] not in CI_TOOLS:
            continue
        kind = check_kind(" ".join(argv[1:])) or check_kind(argv[0])
        if kind not in CHECK_KINDS:
            continue
        start = index
        while start > 0 and not step_start.match(lines[start]) and lines[start - 1].strip():
            start -= 1
        end = index + 1
        while end < len(lines) and not step_start.match(lines[end]) and lines[end].strip():
            end += 1
        working = [candidate.group(1) for candidate in
                   (re.match(r"^\s*working-directory:\s+(.+)$", entry) for entry in lines[start:end]) if candidate]
        cwd = "."
        if working:
            try:
                cwd = relative(working[-1].strip().strip("'\""), "CI working directory")
            except ValueError:
                continue
            if not any(file.startswith(cwd + "/") for file in inventory.paths) and cwd != ".":
                continue
        known = inventory.checks.get((cwd, tuple(argv)))
        component = known["component_id"] if known else inventory.owner(at(cwd, "_"))
        inventory.command(known["kind"] if known else kind, known["label"] if known else f"CI {' '.join(argv)[:90]}",
                          argv, cwd, [evidence(path, "Literal GitHub Actions run step", index + 1)], component)



def text_value(value, name, limit=150):
    if not isinstance(value, str) or not value.strip() or len(value) > limit or "\0" in value:
        raise ValueError(f"{name} must be nonempty text of up to {limit} characters")
    return value


def explicit_id(value):
    if value is not None and not (isinstance(value, str) and SAFE_ID.fullmatch(value)):
        raise ValueError("Use a stable lowercase capability ID")
    return value


def configured_directory(inventory, value):
    name = relative(value, "Project working directory")
    path = (inventory.project / name).resolve()
    if not path.is_relative_to(inventory.project) or not path.is_dir():
        raise ValueError("The project working directory must exist inside the project")
    if name != "." and not any(item.startswith(name + "/") for item in inventory.paths):
        raise ValueError("The project working directory needs a Git-tracked file")
    return name


def configured_component(inventory, item):
    cwd = configured_directory(inventory, item.get("root", "."))
    title = text_value(item["label"], "Component label")
    stack = text_value(item["stack"], "Component stack", 80)
    inventory.component(cwd, stack, title, [evidence(ADAPTER, "Explicit component")], explicit_id(item.get("id")))


def configured_command(inventory, section, item):
    argv = item["argv"]
    if not isinstance(argv, list) or not 1 <= len(argv) <= 60:
        raise ValueError("Use a literal argv array")
    argv = [text_value(argument, "Command argument", 4096) for argument in argv]
    cwd = configured_directory(inventory, item.get("cwd", "."))
    title = text_value(item["label"], "Command label")
    kind = "preview" if section == "previews" else item.get("kind", "check")
    if section == "checks" and kind not in CHECK_KINDS:
        raise ValueError("Unknown check kind")
    component = item.get("component_id", inventory.owner(at(cwd, "_")))
    if component is not None and component not in inventory.components:
        raise ValueError("The component ID is not in the project inventory")
    url = item.get("url") if section == "previews" else None
    if url is not None:
        parsed = urlsplit(text_value(url, "Preview URL", 500))
        if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username or parsed.password:
            raise ValueError("Use a credential-free HTTP or HTTPS preview URL")
    inventory.command(kind, title, argv, cwd, [evidence(ADAPTER, f"Explicit {section} command")],
                      component, explicit_id(item.get("id")), url)


def configured_file(inventory, item):
    path = relative(item["path"], "Evidence file")
    if path not in inventory.paths:
        raise ValueError("The evidence file must be tracked by Git")
    kind = item.get("kind", "config")
    if kind not in FILE_KINDS:
        raise ValueError("Unknown evidence file kind")
    inventory.file(path, kind, text_value(item.get("label", path), "File label", 500), explicit_id(item.get("id")))


def apply_adapter(inventory, *, only_components=False):
    if ADAPTER not in inventory.paths:
        return
    config = inventory.json_object(ADAPTER)
    if type(config.get("schema_version")) is not int or config["schema_version"] != 1:
        inventory.gaps.append(f"{ADAPTER} must use schema_version 1.")
        return
    sections = ("components",) if only_components else ("checks", "previews", "files")
    actions = {
        "components": lambda item: configured_component(inventory, item),
        "checks": lambda item: configured_command(inventory, "checks", item),
        "previews": lambda item: configured_command(inventory, "previews", item),
        "files": lambda item: configured_file(inventory, item),
    }
    for section in sections:
        rows = config.get(section, [])
        if not isinstance(rows, list) or len(rows) > 100:
            inventory.gaps.append(f"{ADAPTER} {section} must contain up to 100 entries.")
            continue
        for index, item in enumerate(rows, 1):
            try:
                if not isinstance(item, dict):
                    raise ValueError("Use an object")
                actions[section](item)
            except (ValueError, KeyError, TypeError) as error:
                inventory.gaps.append(f"{ADAPTER} {section} item {index}: {error}")


def python_projects(inventory, paths):
    markers = {}
    tests = {}
    for path in paths:
        name = PurePosixPath(path).name
        if name in {"pyproject.toml", "pytest.ini", "Pipfile", "setup.py", "setup.cfg", "manage.py"} \
                or re.fullmatch(r"requirements(?:[-_.][^/]+)?\.txt", name):
            markers.setdefault(where(path), []).append(path)
    nearest = sorted(markers, key=lambda root: len(PurePosixPath(root).parts), reverse=True)
    for path in paths:
        name = PurePosixPath(path).name
        if not name.endswith(".py") or not re.match(r"^test", name) and not name.endswith("_test.py"):
            continue
        owner = next((root for root in nearest if PurePosixPath(path).is_relative_to(root)), None)
        if owner is None:
            parent = PurePosixPath(path).parent
            owner = parent.parent.as_posix() if parent.name in {"tests", "test"} else parent.as_posix()
        tests.setdefault(owner, []).append(path)
    for root in sorted(set(markers) | set(tests)):
        detect_python(inventory, root, markers.get(root, []), tests.get(root, []))


def tracked_paths(project):
    raw = git_read(project, "ls-files", "-z", "--cached")
    if raw is None:
        return None, []
    files = sorted({path for path in raw.split("\0") if path and not EXCLUDED.intersection(PurePosixPath(path).parts)})
    gaps = []
    if len(files) > MAX_PATHS:
        gaps.append("The tracked file scan reached its limit. Select an omitted subproject directly.")
    return files[:MAX_PATHS], gaps


def read_instruction(project, name):
    project = Path(project).resolve(strict=True)
    path = relative(name, "Instruction path")
    paths, _ = tracked_paths(project)
    if not paths or path not in paths:
        raise ValueError("Choose a tracked project instruction file.")
    inventory = Inventory(project, paths)
    if file_kind(path) != "instruction":
        apply_adapter(inventory, only_components=True)
        apply_adapter(inventory)
        if not any(row["path"] == path and row["kind"] == "instruction" for row in inventory.files.values()):
            raise ValueError("Choose a tracked project instruction file.")
    content = inventory.text(path)
    if not isinstance(content, str) or len(content) > 350000:
        raise ValueError("The project instruction file is unreadable or too large.")
    return {"path": path, "content": content}


def discover(project):
    project = Path(project).resolve(strict=True)
    if not project.is_dir():
        raise ValueError("Select a project directory")
    paths, gaps = tracked_paths(project)
    if paths is None:
        return {"schema_version": 1, "git": {"head": None, "branch": None, "refs": []},
                "components": [], "checks": [], "previews": [], "files": [],
                "gaps": ["Capability discovery needs a readable Git checkout. Manual settings remain available."]}
    inventory = Inventory(project, paths)
    inventory.gaps.extend(gaps)
    for path in paths:
        name = PurePosixPath(path).name
        if name == "package.json":
            detect_node(inventory, path)
        elif path == "config/application.rb" or path.endswith("/config/application.rb"):
            detect_rails(inventory, PurePosixPath(path).parent.parent.as_posix())
        elif name in {"go.mod", "Cargo.toml", "pom.xml"} or name.endswith((".csproj", ".fsproj")):
            detect_other(inventory, path)
    python_projects(inventory, paths)
    apply_adapter(inventory, only_components=True)
    for path in paths:
        kind = file_kind(path)
        if kind:
            inventory.file(path, kind)
        if path.startswith(".github/workflows/") and path.endswith((".yml", ".yaml")):
            github_steps(inventory, path)
    apply_adapter(inventory)
    priorities = {kind: index for index, kind in enumerate(
        ("instruction", "fixture", "test", "script", "manifest", "lockfile", "ci", "config"))}
    files = sorted(inventory.files.values(), key=lambda row: (priorities[row["kind"]], row["path"]))
    if len(files) > MAX_FILES:
        inventory.gaps.append("The evidence file list reached its limit. Other tracked paths can be entered manually.")
    if not inventory.checks:
        inventory.gaps.append("No runnable check candidates were identified in the scanned evidence.")
    return {"schema_version": 1, "git": git_metadata(project),
            "components": sorted(inventory.components.values(), key=lambda row: (row["root"], row["label"])),
            "checks": sorted(inventory.checks.values(), key=lambda row: (row["cwd"], row["label"])),
            "previews": sorted(inventory.previews.values(), key=lambda row: (row["cwd"], row["label"])),
            "files": files[:MAX_FILES], "gaps": sorted(set(inventory.gaps))}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", type=Path, required=True)
    args = parser.parse_args()
    try:
        print(json.dumps(discover(args.project), ensure_ascii=True))
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        print(str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
