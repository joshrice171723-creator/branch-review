"""Check executable resolution without launching a project command."""
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from project_command import resolve_argv, windows_npm_argv


class ProjectCommandTests(unittest.TestCase):
    def test_routes_native_npm_entry_with_literal_argument_array(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp).resolve()
            install = root / "Node installation"
            install.mkdir()
            node = install / "node.exe"
            wrapper = install / "npm.cmd"
            node.touch()
            wrapper.touch()
            entry = install / "node_modules/npm/bin/npm-cli.js"
            entry.parent.mkdir(parents=True)
            entry.touch()
            bundled = root / "node.exe"
            bundled.touch()
            options = {"PATH": str(install), "HARNESS_NODE": str(bundled)}

            def which(name, *, path):
                self.assertEqual(path, str(install))
                return {"npm.cmd": str(wrapper), "node.exe": str(node)}.get(name)

            argv = ["npm", "test", "--", "space and & are literal"]
            with patch("project_command.shutil.which", side_effect=which):
                self.assertEqual(windows_npm_argv(argv, options),
                                 [str(node), str(entry), "test", "--", "space and & are literal"])
            self.assertEqual(argv, ["npm", "test", "--", "space and & are literal"])

    def test_leaves_non_npm_commands_as_given(self):
        argv = ["pnpm", "test"]
        self.assertIs(resolve_argv(argv), argv)
        if os.name != "nt":
            argv = ["npm", "test"]
            self.assertIs(resolve_argv(argv), argv)

    def test_does_not_run_a_wrapper_as_a_fallback(self):
        with patch("project_command.shutil.which", return_value=None):
            with self.assertRaisesRegex(ValueError, "Install npm"):
                windows_npm_argv(["npm", "test"], {"PATH": ""})


if __name__ == "__main__":
    unittest.main()
