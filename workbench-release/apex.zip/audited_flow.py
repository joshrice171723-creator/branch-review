"""Run the opt-in Codex/Muse workflow against one installed Workbench task."""
import argparse
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import time
import uuid

from activity import publish
from planning import QUESTION_CONTRACT, choices, resolve_question
from agent_adapter import build_command, subprocess_environment
from quality import criterion_issues


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    draft = path.with_suffix(".tmp")
    draft.write_text(json.dumps(value, indent=2), encoding="utf-8")
    draft.replace(path)


@contextmanager
def owned(folder, wait=False):
    folder.mkdir(parents=True, exist_ok=True)
    with (folder / "run.lock").open("a+b") as stream:
        if os.name == "nt":
            import msvcrt
            stream.seek(0)
            msvcrt.locking(stream.fileno(), msvcrt.LK_LOCK if wait else msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(stream, fcntl.LOCK_EX if wait else fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def notes(project, roots, request):
    words = set(re.findall(r"[a-z0-9]{3,}", request.lower()))
    matches = []
    for name in roots:
        root = (project / name).expanduser().resolve(strict=True)
        if not root.is_dir():
            raise ValueError(f"Vault is not a directory: {root}")
        for base, dirs, files in os.walk(root):
            dirs[:] = [d for d in dirs if not d.startswith(".")]
            for filename in files:
                path = Path(base) / filename
                if path.suffix.lower() != ".md" or path.is_symlink() or path.stat().st_size > 512000:
                    continue
                content = path.read_text(encoding="utf-8", errors="replace")
                for block in content.split("\n\n"):
                    score = len(words.intersection(re.findall(r"[a-z0-9]{3,}", (filename+" "+block).lower())))
                    if score:
                        matches.append((score, str(path), block[:1800]))
    return [{"path": p, "passage": b} for _, p, b in sorted(matches, reverse=True)[:8]]


class Runtime:
    def __init__(self, project, task_id, codex=None):
        self.project = project
        self.home = project / ".harness"
        self.folder = self.home / "loops" / task_id
        self.record = self.home / "tasks" / task_id
        self.task = read(self.record / "task.json")
        self.id = task_id
        self.codex = codex
        self.config = read(self.home / "project.json")
        self.profile = self.task.get("profile")
        if self.profile:
            self.config.update(checks=self.profile["checks"], benchmark=self.profile["benchmark"])
        self.quality = self.task.get("quality")
        if self.quality:
            definition = self.quality["definition"]
            measured = {benchmark["check_id"] for benchmark in definition["benchmarks"]}
            self.config["checks"] = [dict(item, name=item["id"], benchmark=item["id"] in measured)
                                     for item in definition["checks"]]

    def cli(self, args, *, required=True):
        proc = subprocess.run(["ruby", str(self.home / "bin/harness"), *args,
                               "--project", str(self.project), "--id", self.id],
                              cwd=self.project, capture_output=True, text=True, encoding="utf-8",
                              env=dict(os.environ, HARNESS_PYTHON=sys.executable))
        if required and proc.returncode:
            raise ValueError(proc.stderr.strip() or proc.stdout.strip())
        return proc

    def status(self):
        return json.loads(self.cli(["task", "status"]).stdout)

    def check(self, phase):
        rows = []
        commands = [["internal", "run", c["name"]] for c in self.config["checks"]
                    if not c["benchmark"] and phase in c.get("phases", ["baseline", "after"])]
        if any(c["benchmark"] for c in self.config["checks"]):
            commands.append(["internal", "benchmark"])
        for cmd in commands:
            stage = "baseline" if phase == "baseline" else "checks"
            name = " ".join(cmd[1:])
            publish(self.folder, stage, "Workbench", "Started " + name)
            proc = self.cli([*cmd, "--phase", phase], required=False)
            publish(self.folder, stage, "Workbench", ("Passed " if proc.returncode == 0 else "Failed ") + name)
            row = {"command": cmd, "ok": proc.returncode == 0,
                   "receipt": proc.stdout.strip(), "error": proc.stderr.strip()}
            if self.quality:
                row["gating"] = name == "benchmark" or any(
                    check["name"] == name and check["required"] for check in self.config["checks"])
            rows.append(row)
        return rows

    def agent(self, stage, prompt, write=False):
        options = assignment(self, stage)
        actor = options["provider"]
        if self.profile:
            selected = self.profile["profiles"][self.profile["active"]]
            docs = {doc["id"]: doc for doc in self.profile["documents"]}
            attached = [docs[key] for key in dict.fromkeys(selected["sharedDocs"] + options["docs"])]
            prompt += "\n" + "\n\n".join([selected["rules"], options["instructions"],
                *(doc["filename"] + "\n" + doc["content"] for doc in attached)])
        with tempfile.TemporaryDirectory(dir=self.folder) as tmp:
            root = Path(tmp)
            schema = root / "reply.schema.json"
            if stage.endswith("review"):
                rubric = audit_rubric(self, stage)
                fields = {"verdict": {"type": "string", "enum": ["pass", "replan"] +
                          ([] if stage == "plan_review" else ["repair"])}, "reason": {"type": "string"}}
                if owns_criteria(self, stage) or rubric:
                    criterion = {"id": {"type": "string"}, "verdict": {"type": "string"},
                                 "evidence": {"type": "array", "items": {"type": "string"}}, "reason": {"type": "string"}}
                    fields["criteria"] = {"type": "array", "items": {"type": "object", "properties": criterion,
                                          "required": list(criterion), "additionalProperties": False}}
                save(schema, {"type": "object", "properties": fields, "required": list(fields), "additionalProperties": False})
            prompt_file = root / "prompt.txt"
            prompt_file.write_bytes(prompt.encode())
            if actor == "Codex":
                cmd = build_command(self.codex, self.project, model=options["model"] or self.task["agent"]["model"],
                                    effort=options["effort"], sandbox="workspace-write" if write else "read-only")
                if schema.exists():
                    cmd[-1:-1] = ["--output-schema", str(schema)]
            elif actor == "Muse" and not write:
                executable = shutil.which(os.environ.get("APEX_MUSE_EXECUTABLE") or "muse")
                if not executable:
                    raise ValueError("Muse executable not found. Check PATH or APEX_MUSE_EXECUTABLE.")
                cmd = [executable, "exec", "--json", "--prompt-file", str(prompt_file)]
                if self.profile:
                    cmd += ["--preset", "native-basic", "--approval-mode", "never", "--disable-shell",
                            "--disable-write", "--disable-web-tools", "--workspace", str(self.project),
                            "--reasoning-effort", options["effort"]]
                else:
                    cmd += ["--permission-profile", ":read-only"]
                if options["model"]:
                    cmd += ["--model", options["model"]]
                if schema.exists():
                    cmd += ["--output-schema", str(schema)]
            else:
                raise ValueError("Unsupported provider or write permission for " + stage)
            requested = options.get("model") or (self.task["agent"]["model"] if actor == "Codex" else "provider default")
            effort = options.get("effort") or "provider default"
            publish(self.folder, stage, actor, f"Requested model {requested} · thinking effort {effort}")
            return stream_agent(self, stage, actor, cmd, prompt_file)


STAGE_KEYS = {"plan_review": "planReview", "build_review": "buildReview", "final_review": "finalReview",
              "building": "build", "baseline": "checks", "finish": "verify"}


def assignment(rt, stage):
    profile = rt.task.get("profile")
    if profile:
        return profile["profiles"][profile["active"]]["stages"].get(STAGE_KEYS.get(stage, stage), {})
    if stage in ("plan", "build", "building"):
        return dict(rt.task.get("agent", {}), provider="Codex")
    return {"provider": "Muse" if stage.endswith("review") else "Workbench", "model": ""}


def owns_criteria(rt, stage):
    return stage == "final_review" or (stage == "build_review" and
        assignment(rt, "final_review").get("enabled") is False)


def audit_rubric(rt, stage):
    return next((item for item in rt.task.get("quality", {}).get("definition", {}).get("rubrics", [])
                 if item["actor"] == "agent" and item["stage"] == stage), None)


def stream_agent(rt, stage, actor, command, prompt_file):
    answer = None
    complete = False
    failed = False
    labels = {"thread.started": "Session started", "turn.started": "Turn started",
              "turn.completed": "Turn completed", "task.lifecycle.started": "Task started",
              "task.lifecycle.completed": "Task completed", "run.terminal.completed": "Turn completed"}
    with prompt_file.open("rb") as input_file, tempfile.TemporaryFile() as errors:
        with subprocess.Popen(command, stdin=input_file if actor == "Codex" else subprocess.DEVNULL,
                cwd=rt.project, stdout=subprocess.PIPE, stderr=errors, text=True, encoding="utf-8",
                env=subprocess_environment()) as process:
            try:
                for line in process.stdout:
                    if not line.strip():
                        continue
                    event = json.loads(line)
                    kind = event.get("payload_type") if actor == "Muse" else event.get("type")
                    item = event.get("item") or {}
                    payload = event.get("payload") or {}
                    label = labels.get(kind)
                    if kind == "run.model.configured":
                        model = payload.get("model_id", "")
                        label = "Model selected" + (" · " + model if re.fullmatch(r"muse-[a-z0-9.\\-]{1,40}", model) else "")
                    if kind in ("item.started", "item.completed") and item.get("type") in (
                            "command_execution", "file_change", "mcp_tool_call", "agent_message"):
                        label = item["type"].replace("_", " ").capitalize() + " " + kind.split(".")[1]
                    if label:
                        publish(rt.folder, stage, actor, label)
                    if kind == "item.completed" and item.get("type") == "agent_message":
                        answer = item.get("text")
                    if kind == "run.terminal.completed":
                        answer = payload.get("text")
                    if kind in ("turn.completed", "run.terminal.completed"):
                        complete = True
                    if kind in ("turn.failed", "error", "run.terminal.failed", "run.terminal.cancelled"):
                        failed = True
                    # Older Muse CLIs returned a single schema-shaped object.
                    if actor == "Muse" and not kind and "verdict" in event:
                        answer, complete = line, True
            except BaseException:
                process.kill()
                raise
            code = process.wait()
            if code:
                errors.seek(0)
                diagnostic = errors.read(8192).lower()
                reason = next((message for marker, message in (
                    (b"mutually exclusive", "Incompatible command options."),
                    (b"unknown option", "Unsupported command option."),
                    (b"unauthorized", "Authentication failed."),
                    (b"permission denied", "Permission denied."),
                    (b"rate limit", "Provider rate limit reached."),
                ) if marker in diagnostic), "No recognized diagnostic.")
                raise ValueError(f"{actor} exited with code {code} during {stage}. {reason}")
            if failed or not complete or not isinstance(answer, str) or not answer.strip():
                raise ValueError(actor + " returned an incomplete " + stage + " response")
    return answer


def object_reply(text):
    value = json.loads(text.strip().removeprefix("```json").removesuffix("```").strip())
    if not isinstance(value, dict):
        raise ValueError("Agent response must be a JSON object")
    return value


def checkpoint(rt, state, stage, detail=None):
    state["stage"] = stage
    actor = assignment(rt, stage).get("provider", "Workbench")
    publish(rt.folder, stage, actor, "Entered " + stage.replace("_", " "))
    state["history"].append({"stage": stage, "assignedTo": actor, "time": time.time(), "detail": detail})
    save(rt.folder / "state.json", state)


def completion_report(state):
    build = state.get("build_summary") or "No builder summary was recorded."
    checks = [f"- {'Passed' if row['ok'] else 'Failed'}: {' '.join(row['command'][1:])}"
              for row in state.get("checks", []) if "command" in row]
    return "\n".join(["Completed.", build, "", "Final checks", *checks, "",
                      "Final audit", state["summary"], "", "Verified source: " + state["final_snapshot"]])


def stop_at_limit(rt, state, reason):
    if rt.status()["lifecycle"]["status"] == "active":
        rt.cli(["task", "audit-limit", "--reason", reason])
    state["finding"] = reason
    checkpoint(rt, state, "stopped", reason)


def return_to(rt, state, stage, action, reason):
    bucket = {"plan_review": "planning", "build_review": "build", "final_review": "audit"}[stage]
    count = state["returns"].get(bucket, 0)
    limit = rt.task["execution"]["max_repair_rounds"] if bucket == "build" else 3
    options = assignment(rt, stage)
    limit = options.get("limit", limit)
    route = "plan" if action == "replan" else "build"
    if "route" in options:
        route = options["requirementsRoute"] if action == "replan" and stage != "plan_review" else options["route"]
    state["finding"] = reason
    if route == "stop":
        rt.cli(["task", "stop", "--reason", reason])
        state["stop_message"] = "Stopped by the configured return route. "
        checkpoint(rt, state, "stopped", reason)
        return
    if count >= limit:
        stop_at_limit(rt, state, reason)
        return
    if route == "build":
        result = rt.cli(["task", "repair-round", "--reason", reason], required=False)
        if result.returncode:
            if rt.status()["lifecycle"].get("cause") == "repair_limit":
                stop_at_limit(rt, state, reason)
                return
            raise ValueError(result.stderr or "Could not record repair")
    state["returns"][bucket] = count + 1
    publish(rt.folder, stage, options["provider"], "Finding returned to " + route)
    checkpoint(rt, state, route, reason)


def run(rt, answer=None):
    with owned(rt.folder):
        try:
            return run_owned(rt, answer)
        except (OSError, ValueError, RuntimeError):
            path = rt.folder / "state.json"
            stage = read(path)["stage"] if path.exists() else "plan"
            publish(rt.folder, stage, "Workbench", "Stage failed. Inspect the coordinator result.")
            raise


def run_owned(rt, answer):
    path = rt.folder / "state.json"
    state = read(path) if path.exists() else {"stage": "plan", "history": [], "answers": [],
                                              "returns": {}, "finding": "", "baseline": False}
    if not path.exists():
        checkpoint(rt, state, "plan")
    if state["stage"] == "completed":
        return completion_report(state)
    if state["stage"] == "finish" and rt.status()["lifecycle"]["status"] == "completed":
        checkpoint(rt, state, "completed")
        return completion_report(state)
    if state["stage"] == "stopped":
        return state.get("stop_message", "Stopped at the repair limit. ") + state["finding"]
    agreement = rt.cli(["task", "prompt", "--coordinated"]).stdout
    def accept_question(reply):
        context = dict(request=rt.task["action"], scope=rt.task["scope"], agreement=agreement,
                       plan=state.get("plan"), answers=state["answers"], notes=state.get("notes", []),
                       finding=state.get("finding"))
        try:
            decision = resolve_question(reply, context, lambda prompt: rt.agent("plan", prompt),
                                        assignment(rt, "plan_review").get("limit", 3))
        except (ValueError, OSError, RuntimeError) as error:
            state.update(question=reply["question"], suggestions=[], question_error=str(error))
            checkpoint(rt, state, "question_retry", str(error))
            raise
        state.update(decision, question_id=uuid.uuid4().hex, question_error=None)
        checkpoint(rt, state, "question", decision)

    if state["stage"] == "question_retry" or (state["stage"] == "question" and not choices(state.get("suggestions"))):
        accept_question({"question": state["question"]})
        return state["question"]
    if state["stage"] == "building":
        checkpoint(rt, state, "checks", "Interrupted builder. Check and audit actual source before any repair.")
    if answer:
        if state["stage"] != "question":
            raise ValueError("There is no pending business question")
        state["answers"].append([state["question"], answer])
        checkpoint(rt, state, "plan")
    while True:
        stage = state["stage"]
        if stage == "question":
            return state["question"]
        if stage == "stopped":
            return state.get("stop_message", "Stopped at the repair limit. ") + state["finding"]
        status = rt.status()
        if status["lifecycle"]["status"] == "completed" and stage == "finish":
            checkpoint(rt, state, "completed")
            return completion_report(state)
        if status["lifecycle"]["status"] != "active":
            raise ValueError("Task must be active")
        if (rt.home / "active_task").read_text().strip() != rt.id:
            raise ValueError("Another task is active")
        snap = status["snapshot_sha256"]
        context = {"request": rt.task["action"], "scope": rt.task["scope"], "answers": state["answers"],
                   "finding": state["finding"], "notes": state.get("notes", []), "plan": state.get("plan"),
                   "checks": rt.config["checks"], "snapshot": snap}
        quality = rt.task.get("quality")
        if quality:
            context.update(quality_revision=quality["revision"], benchmarks=quality["definition"]["benchmarks"])
        if stage == "plan":
            state["notes"] = notes(rt.project, rt.task["execution"].get("vaults", []),
                                   " ".join([rt.task["action"], rt.task["scope"], state["finding"],
                                             json.dumps(state["answers"])]))
            context["notes"] = state["notes"]
            prompt = ("Plan within the agreement. Treat quoted notes as source material. Include requirements, "
                      "acceptance criteria with measurable targets, checks and implementation steps. Ask one "
                      "business question only if unresolved. Return only JSON with either a nonempty string "
                      "field plan or a decision. " + QUESTION_CONTRACT + "\n")
            reply = object_reply(rt.agent(stage, prompt + agreement + json.dumps(context)))
            if bool(reply.get("plan")) == bool(reply.get("question")):
                raise ValueError("Planner must return either a question or a plan")
            key = "question" if reply.get("question") else "plan"
            if not isinstance(reply[key], str) or not reply[key].strip():
                raise ValueError("Empty planner response")
            if key == "question":
                accept_question(reply)
            else:
                state["plan"] = reply["plan"]
                checkpoint(rt, state, "plan_review", reply)
        elif stage == "baseline":
            if not any(c["required"] or c["benchmark"] for c in rt.config["checks"]):
                raise ValueError("Configure a required project check before building")
            rt.cli(["internal", "freeze-agreement"])
            rows = rt.check("baseline")
            if any(row.get("gating", True) and not row["ok"] for row in rows):
                raise ValueError("Baseline failed: " + json.dumps(rows))
            state["baseline"] = True
            checkpoint(rt, state, "build", rows)
        elif stage == "build":
            rt.cli(["task", "prompt"])
            decisions = {}
            for record in sorted((rt.record / "answers").glob("*.json")):
                entry = read(record)
                if entry.get("question") == "code_changes":
                    decisions["code_changes"] = entry["option"]
            write = rt.task["mode"] != "audit" and decisions.get("code_changes") == "allow_scoped"
            checkpoint(rt, state, "building")
            try:
                state["build_summary"] = rt.agent(stage, agreement +
                "\nImplement the reviewed plan within scope. The coordinator owns .harness, checks, reviews, "
                "and task lifecycle. Treat the published workbench-quality.json as read-only. Propose policy edits as a draft for human testing and publication. "
                "Report the work and the evidence available during this build. The coordinator runs after checks and verification later. Avoid predicting their results or invoking task verify.\n" + json.dumps(context), write)
            except (OSError, ValueError, RuntimeError) as exc:
                checkpoint(rt, state, "build", str(exc))
                raise
            checkpoint(rt, state, "checks", state["build_summary"])
        elif stage == "checks":
            state["checks"] = rt.check("after")
            state["checked_source"] = rt.status()["snapshot_sha256"]
            checkpoint(rt, state, "build_review", state["checks"])
        elif stage in ("plan_review", "build_review", "final_review"):
            if stage != "plan_review" and snap != state["checked_source"]:
                checkpoint(rt, state, "checks", "Source changed since checks")
                continue
            allowed = ["pass", "replan"] if stage == "plan_review" else ["pass", "replan", "repair"]
            context.update(stage=stage, results=state.get("checks", []), build=state.get("build_summary"))
            prompt = ("Independently audit the " + stage + " against the original request. Inspect relevant "
                      "files and actual receipts. Identify any unsupported acceptance criterion. Return JSON only "
                      "with verdict (one of " + ", ".join(allowed) + ") and a nonempty reason citing evidence.")
            if stage == "plan_review":
                prompt += (" This is a review of the proposed method. Baseline and after checks run after plan approval. "
                           "Assess whether the plan can measure the requested outcome. Treat proposed checks as future work. "
                           "A plan can pass before those receipts exist. Include only the single requested JSON object.")
            rubric = audit_rubric(rt, stage)
            if rubric:
                context["rubric"] = rubric
                prompt += (" Use the pinned rubric in the context. Record criteria by ID with verdict, reason and a list of evidence strings. "
                           "Supply evidence for every required criterion on a pass. Record only rubric criterion IDs. "
                           "Use an empty criteria array if returning the work without evaluating criteria.")
            elif owns_criteria(rt, stage):
                prompt += (" You own the structured review at this stage. The coordinator saves your returned criteria, then runs task verify. Inspect the current check receipts. For pass return criteria using all IDs and evidence fields in "
                           ".harness/templates/REVIEW.json. Read the pinned review instructions.")
            reply = object_reply(rt.agent(stage, prompt + "\n" + agreement + json.dumps(context)))
            action, reason = reply.get("verdict"), reply.get("reason")
            if action not in allowed or not isinstance(reason, str) or not reason.strip():
                raise ValueError("Invalid audit verdict or missing finding")
            if rt.status()["snapshot_sha256"] != snap:
                raise ValueError("Source changed during review. Retry this stage.")
            if action == "pass" and rubric:
                issues = criterion_issues(reply.get("criteria"), rubric)
                if issues:
                    action = "replan" if stage == "plan_review" else "repair"
                    reason = "Quality rubric: " + ". ".join(issues)
            if stage == "build_review" and action == "pass" and any(r.get("gating", True) and not r["ok"] for r in state["checks"]):
                action, reason = "repair", "Project check failed: " + json.dumps(state["checks"])
            receipt = dict(reply, actor=assignment(rt, stage)["provider"], stage=stage, verdict=action, reason=reason, snapshot_sha256=snap,
                           plan_sha256=hashlib.sha256(state["plan"].encode()).hexdigest())
            if rt.task.get("profile_sha256"):
                receipt["profile_sha256"] = rt.task["profile_sha256"]
            if quality:
                receipt["quality_revision"] = quality["revision"]
                if rubric:
                    receipt["rubric_id"] = rubric["id"]
            publish(rt.folder, stage, assignment(rt, stage)["provider"], "Audit verdict: " + action)
            public_reason = " ".join(reason.split())
            publish(rt.folder, stage, assignment(rt, stage)["provider"], public_reason[:480])
            save(rt.folder / "audit.json", receipt)
            rt.cli(["internal", "audit-step", "--file", str(rt.folder / "audit.json")])
            if action != "pass":
                return_to(rt, state, stage, action, reason)
            elif stage == "plan_review":
                checkpoint(rt, state, "build" if state["baseline"] else "baseline", reply)
            elif stage == "build_review" and not owns_criteria(rt, stage):
                checkpoint(rt, state, "final_review", reply)
            else:
                report = dict(author="agent", verdict="pass", snapshot_sha256=snap, criteria=reply.get("criteria"))
                if quality:
                    report.update(stage=stage, quality_revision=quality["revision"])
                save(rt.folder / "review.json", report)
                rt.cli(["internal", "review", "--file", str(rt.folder / "review.json")])
                state.update(final_snapshot=snap, summary=reason)
                if stage == "build_review":
                    skip = dict(stage="final_review", actor="Workbench", verdict="skipped", reason="Disabled in the pinned Fast profile",
                                profile_sha256=rt.task["profile_sha256"], snapshot_sha256=snap,
                                plan_sha256=receipt["plan_sha256"])
                    if quality:
                        skip["quality_revision"] = quality["revision"]
                    save(rt.folder / "skip.json", skip)
                    checkpoint(rt, state, "final_skip", reply)
                else:
                    checkpoint(rt, state, "finish", reply)
        elif stage == "final_skip":
            if snap != state["final_snapshot"]:
                checkpoint(rt, state, "checks", "Source changed before recording the final audit skip")
                continue
            skip_path = rt.folder / "skip.json"
            rt.cli(["internal", "audit-step", "--file", str(skip_path)])
            skip = read(skip_path)
            publish(rt.folder, "final_review", "Workbench", skip["reason"])
            checkpoint(rt, state, "finish", skip)
        elif stage == "finish":
            if snap != state["final_snapshot"]:
                checkpoint(rt, state, "checks", "Source changed after final audit")
                continue
            verify = rt.cli(["task", "verify"], required=False)
            if verify.returncode:
                # The CLI can identify issues the reviewer missed, including a forbidden dependency change.
                evidence = json.loads(verify.stdout) if verify.stdout.strip() else {}
                issues = evidence.get("issues")
                if not issues:
                    raise ValueError(verify.stderr or "Verification failed")
                return_to(rt, state, "final_review", "repair", "; ".join(issues))
                continue
            design = rt.folder / "design.json"
            if design.exists():
                from design_build import commit_checked_slice
                state["design_sha"] = commit_checked_slice(rt, snap, read(design))
                if rt.status()["snapshot_sha256"] != snap:
                    checkpoint(rt, state, "checks", "Source changed before Branch Review")
                    continue
                save(path, state)
            rt.cli(["task", "finish"])
            checkpoint(rt, state, "completed")
            return completion_report(state)
        else:
            raise ValueError(f"Unknown stage: {stage}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", required=True, type=Path)
    parser.add_argument("--id")
    parser.add_argument("--answer")
    parser.add_argument("--codex")
    parser.add_argument("--status", action="store_true")
    parser.add_argument("--owned-start", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    # Wait until the panel owns the Windows process tree before starting any child.
    if args.owned_start and sys.stdin.readline().strip() != "run":
        raise ValueError("The panel did not release this coordinator.")
    root = args.project.resolve(strict=True)
    active = (root / ".harness/active_task").read_text().strip()
    if not re.fullmatch(r"[\w-]+", active) or (args.id and active != args.id):
        raise ValueError("Task identity mismatch")
    rt = Runtime(root, active, args.codex)
    if rt.task["execution"].get("workflow") != "audited":
        raise ValueError("Set execution.workflow to audited before creating this task")
    if args.status:
        path = rt.folder / "state.json"
        print(json.dumps(read(path) if path.exists() else {"stage": "plan"}))
    else:
        print(run(rt, args.answer))
        if read(rt.folder / "state.json")["stage"] == "stopped":
            return 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, KeyError, ValueError, RuntimeError) as exc:
        sys.exit(f"Audited workflow: {exc}")
