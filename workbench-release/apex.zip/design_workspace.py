"""Project-owned Design records. Serialize mutations across mounted panel processes."""
from contextlib import contextmanager
from datetime import datetime, timezone
import json
import re
import uuid

from audited_flow import Runtime, assignment, object_reply, owned
from chat_workflow import load, write_json
import design_images
from planning import QUESTION_CONTRACT, resolve_question


def identifier():
    return uuid.uuid4().hex


def now():
    return datetime.now(timezone.utc).isoformat()


def required(value, name):
    if not isinstance(value, str) or not value.strip():
        raise ValueError("Enter " + name + ".")
    return value


def roadmap(value):
    if not isinstance(value, list):
        raise ValueError("Supply an ordered list of milestones.")
    ids = set()
    def item(row):
        key = row["id"]
        if not isinstance(key, str) or not re.fullmatch(r"[\w-]{1,80}", key) or key in ids:
            raise ValueError("Each milestone and slice needs a unique ID.")
        ids.add(key)
        return dict(id=key, title=required(row.get("title"), "a title"))
    return [dict(item(m), slices=[item(s) for s in m["slices"]]) for m in value]


class DesignPlanner(Runtime):
    def __init__(self, app, folder):
        self.project = app.require_project()
        home = self.project / ".harness"
        self.profile = load(home / "profile.json") if not (home / "profile.disabled").exists() else None
        self.task = dict(agent=load(home / "project.json")["agent"], profile=self.profile)
        self.codex = app.executable
        self.folder = folder
        if folder.resolve() != folder:
            raise ValueError("The planning turn must belong to this project.")
        folder.mkdir(parents=True, exist_ok=True)


class Workspace:
    def __init__(self, app):
        self.app = app
        self.root = app.require_project()
        self.folder = self.root / ".harness/design"
        if self.folder.resolve() != self.folder:
            raise ValueError("The Design folder must belong to this project.")
        self.path = self.folder / "workspace.json"

    def layout(self, change=None):
        path = self.folder / "layout.json"
        if path.resolve() != path:
            raise ValueError("The layout record must belong to this project.")
        if change is None:
            return load(path, {})
        allowed = dict(view={"workflow", "stages", "history", "live", "documents", "rules"},
                       tab={"Plan", "Mockups", "Preview", "Build"}, panes={"beside", "stack"})
        name, value = change["name"], change["value"]
        if name not in allowed or value not in allowed[name]:
            raise ValueError("Unknown project layout choice.")
        with owned(self.folder, wait=True):
            layout = load(path, {})
            layout[name] = value
            write_json(path, layout)
        return layout

    def read(self):
        if self.path.resolve() != self.path:
            raise ValueError("The Design record must belong to this project.")
        if self.path.is_file():
            return load(self.path)
        from design_build import git
        try:
            branch=git(self.root,"symbolic-ref","--quiet","--short","HEAD")
        except (OSError,ValueError):
            branch=""
        return dict(revision=0,plan="",roadmap=[],approved=None,revisions=[],messages=[],question=None,
                    assets=[],attachments={},builds=[],branch=branch,preview="")

    @contextmanager
    def edit(self):
        with owned(self.folder, wait=True):
            state = self.read()
            yield state
            write_json(self.path, state)

    @staticmethod
    def check_revision(state, payload):
        if state["revision"] != payload.get("revision"):
            raise ValueError("The draft changed. Reload the saved revision and compare your proposed text.")

    def save_draft(self, state, plan, milestones, author):
        if not isinstance(plan, str):
            raise ValueError("Supply draft text.")
        milestones = roadmap(milestones)
        members = {s["id"] for m in milestones for s in m["slices"]}
        state["attachments"] = {key: asset for key, asset in state["attachments"].items() if key in members}
        state.update(plan=plan, roadmap=milestones, approved=None, revision=state["revision"] + 1)
        state["revisions"].append(dict(revision=state["revision"], author=author, plan=plan,
                                       roadmap=milestones, attachments=dict(state["attachments"]), time=now()))

    def asset_path(self, state, key):
        if not any(item["id"] == key for item in state["assets"]):
            raise ValueError("Unknown mockup version.")
        path = self.folder / "assets" / (key + ".png")
        if path.resolve() != path:
            raise ValueError("Invalid mockup path.")
        return path

    def converse(self, operation, payload):
        retry = operation == "retry"
        with self.edit() as state:
            self.check_revision(state, payload)
            pending = state["question"]
            if operation == "answer" and (not pending or pending["id"] != payload.get("id") or not pending.get("suggestions")):
                raise ValueError("This planning question has changed.")
            if retry and (not pending or not pending.get("error")):
                raise ValueError("There is no pending planning retry.")
            if pending and operation == "chat":
                raise ValueError("Resolve the pending decision first.")
            if not retry:
                message = required(payload.get("message"), "a message")
                state["messages"].append(dict(id=identifier(), author="user", text=message, time=now(),
                                              answers=pending["id"] if operation == "answer" else None))
            context = dict(conversation=state["messages"], plan=state["plan"], roadmap=state["roadmap"])
            revision = state["revision"]
            turn = identifier()
            state["turn"] = turn
            if operation == "answer":
                state["question"] = None
            parent = payload.get("asset")
            previous = self.asset_path(state, parent).read_bytes() if operation == "image" and parent else None

        if operation == "image":
            prompt = "Create the requested project UI mockup.\n" + json.dumps(context, ensure_ascii=False)
            data = design_images.generate(prompt, previous)
            design_images.validate_png(data)
            with self.edit() as state:
                key = identifier()
                assets = self.folder / "assets"
                assets.mkdir(exist_ok=True)
                if assets.resolve() != assets:
                    raise ValueError("Invalid asset directory.")
                (assets / (key + ".png")).write_bytes(data)
                state["assets"].append(dict(id=key, parent=parent, prompt=message, time=now()))
                state["messages"].append(dict(author="agent", text="Mockup generated.", asset=key, time=now()))
            return state

        planner = DesignPlanner(self.app, self.folder / "turns" / turn)
        ask = lambda prompt: planner.agent("plan", prompt)
        instruction = ("Edit the shared draft to address the user's message. Return JSON only. "
                       "For a decision use the question field exclusively. " + QUESTION_CONTRACT +
                       " Otherwise return plan (complete draft text), roadmap (ordered milestones with id, title, "
                       "slices of id and title; retain existing IDs), and message (a short statement). "
                       "Put all questions in the question field.\n")
        reply = {"question": pending["question"]} if retry else object_reply(ask(instruction + json.dumps(context)))
        question = None
        if "question" in reply:
            try:
                question = resolve_question(reply, context, ask, assignment(planner, "plan_review").get("limit", 3))
            except (ValueError, OSError) as exc:
                question = dict(question=reply["question"], suggestions=[], error=str(exc))
        with self.edit() as state:
            if question:
                if state.get("turn") != turn or state["revision"] != revision:
                    raise ValueError("The conversation or draft changed. Retry planning with the current draft.")
                state["question"] = dict(question, id=turn)
                message = question.get("error") or question["question"]
            else:
                plan = required(reply.get("plan"), "agent draft text")
                milestones = roadmap(reply.get("roadmap", context["roadmap"]))
                if state["revision"] == revision and state.get("turn") == turn:
                    self.save_draft(state, plan, milestones, "agent")
                    message = reply.get("message") or "Updated the draft."
                else:
                    message = "The draft changed. Compare the agent proposal before saving."
                    state["messages"].append(dict(author="agent", text=plan, proposedRoadmap=milestones, time=now()))
            entry = dict(author="agent", text=message, time=now())
            if question and question["suggestions"]:
                entry.update(decision=turn, suggestions=question["suggestions"])
            state["messages"].append(entry)
        return state

    def update(self, operation, payload):
        if operation in {"chat", "answer", "retry", "image"}:
            return self.converse(operation, payload)
        with self.edit() as state:
            self.check_revision(state, payload)
            if operation == "draft":
                self.save_draft(state, payload["plan"], payload["roadmap"], "user")
            elif operation == "attach":
                key = payload["asset"]
                self.asset_path(state, key)
                if payload["slice"] not in [s["id"] for m in state["roadmap"] for s in m["slices"]]:
                    raise ValueError("Select a roadmap slice.")
                state["attachments"][payload["slice"]] = key
                self.save_draft(state, state["plan"], state["roadmap"], "user")
            elif operation == "approve":
                if (not state["plan"].strip() or not state["roadmap"] or state["question"]
                        or any(not m["slices"] for m in state["roadmap"])):
                    raise ValueError("Resolve the plan and add slices to each milestone before approval.")
                state["approved"] = state["revision"]
            elif operation == "settings":
                from design_host import check_project, loopback_origin, preview_url
                preview = preview_url(payload["preview"])
                if "reviewHost" in payload:
                    host = loopback_origin(payload["reviewHost"].strip()) if payload["reviewHost"].strip() else ""
                    if host:
                        check_project(self.root, host)
                    state["reviewHost"] = host
                branch = payload["branch"]
                if branch:
                    from design_build import validate_branch
                    validate_branch(self.root, branch)
                state.update(branch=branch, preview=preview)
            else:
                raise ValueError("Unknown Design operation.")
        return state

