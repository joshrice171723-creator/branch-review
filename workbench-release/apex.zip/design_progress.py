"""Read the running coordinator's checkpoint and public activity for the Design page."""
from datetime import datetime
import json
import os
from pathlib import Path
import re


def load_json(path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        return default


def running(folder):
    # The coordinator holds this OS lock for the entire run, including CLI-initiated runs.
    try:
        with (folder / "run.lock").open("r+b") as lock:
            if os.name == "nt":
                import msvcrt
                try:
                    msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
                except OSError:
                    return True
                lock.seek(0)
                msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                try:
                    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except BlockingIOError:
                    return True
                fcntl.flock(lock, fcntl.LOCK_UN)
    except FileNotFoundError:
        return False
    except PermissionError:
        return True
    return False


def recent_activity(path, since, stages):
    try:
        with path.open("rb") as stream:
            stream.seek(0, 2)
            start = max(0, stream.tell() - 65536)
            stream.seek(start)
            if start:
                stream.readline()
            lines = stream.readlines()
    except OSError:
        return []
    items = []
    for line in lines:
        try:
            item = json.loads(line)
            if item["stage"] in stages and datetime.fromisoformat(item["timestamp"]).timestamp() >= since:
                items.append(dict(time=item["timestamp"], text=item["activity"][:500], actor=item["actor"]))
        except (KeyError, ValueError, TypeError):
            continue
    return items


ROLES = {"plan": "plan", "plan_review": "planReview", "baseline": "baseline", "build": "build",
         "building": "build", "checks": "checks", "build_review": "buildReview", "final_review": "finalReview",
         "final_skip": "finalReview", "finish": "verify"}


def build_stamp(state):
    build = state["builds"][-1] if state["builds"] else {}
    return dict(revision=state["revision"], approved=state["approved"], build=build.get("id"),
                status=build.get("status"), index=build.get("index"), error=build.get("error"),
                attempt=build["attempts"][-1] if build.get("attempts") else None,
                groups=[dict(sha=group["sha"], approval=group["reviews"][-1] if group["reviews"] else None,
                             pushed=group.get("pushed")) for group in build.get("groups", [])])


def progress(project, task_id=None):
    home = Path(project) / ".harness"
    if task_id is None:
        try:
            task_id = (home / "active_task").read_text(encoding="utf-8").strip()
        except OSError:
            return None
    if not re.fullmatch(r"\d{8}T\d{12}-[0-9a-f]{8}", task_id):
        return None
    folder = home / "loops" / task_id
    record = home / "tasks" / task_id
    state = load_json(folder / "state.json", {})
    task = load_json(record / "task.json", {})
    life_files = sorted((record / "lifecycle").glob("*.json"))
    lifecycle = load_json(life_files[-1], {}).get("status", "active") if life_files else "active"
    attempts = []
    raw_stage = state.get("stage", "")
    for move in state.get("history", []):
        stage, detail = move["stage"], move.get("detail")
        role = ROLES.get(stage)
        if role == "build" and stage == "building" and attempts and attempts[-1]["stage"] == "build":
            attempts[-1]["stage"] = stage
            continue
        if stage == "build" and isinstance(detail, str) and detail and attempts and attempts[-1]["role"] in ("buildReview","finalReview","verify"):
            role = "repair"
        if not role:
            continue
        reason = detail if isinstance(detail, str) else detail.get("reason","") if isinstance(detail,dict) else ""
        attempts.append(dict(role=role, stage=stage, time=move["time"], reason=reason[:1200]))
    latest = attempts[-1] if attempts else None
    active = bool(latest and raw_stage in ROLES and lifecycle == "active" and running(folder))
    events = recent_activity(folder / "activity.jsonl",latest["time"],{latest["stage"],
        "build" if latest["role"] in ("build","repair") else latest["stage"]}) if latest else []
    profile = task.get("profile") or {}
    profile = profile.get("profiles",{}).get(profile.get("active"),{})
    settings = load_json(record / "execution_config.json",{})
    checks = [{"name": c["name"], "phases": c.get("phases",["baseline","after"])} for c in settings.get("checks",[]) if c.get("name")]
    return dict(id=task_id,title=task.get("action",""),stage=raw_stage,lifecycle=lifecycle,running=active,
                attempts=attempts,events=events,stages=profile.get("stages",{}),checks=checks,
                question=state.get("question","") if raw_stage in ("question","question_retry") else "")
