"""Validate a planner decision before accepting a pending question."""
import json


QUESTION_CONTRACT = (
    "Return one unresolved question in question and a suggestions array with at least two "
    "distinct actionable answers. Use the specific alternatives, names and constraints from "
    "the conversation or draft. Each suggestion must answer this particular question."
)


def choices(value):
    if not isinstance(value, list) or len(value) < 2:
        return []
    if any(not isinstance(item, str) or not item.strip() for item in value):
        return []
    cleaned = [item.strip() for item in value]
    return cleaned if len({" ".join(item.casefold().split()) for item in cleaned}) == len(cleaned) else []


def resolve_question(reply, context, ask, limit):
    question = reply["question"]
    if not isinstance(question, str) or not question.strip():
        raise ValueError("The planner returned an empty question.")
    suggestions = choices(reply.get("suggestions"))
    for _ in range(limit):
        if suggestions:
            break
        prompt = ("Supply answers for the existing question. Keep the question unchanged. " +
                  QUESTION_CONTRACT + " Return JSON only.\n" +
                  json.dumps({"question": question, "context": context}, ensure_ascii=False))
        try:
            repaired = json.loads(ask(prompt))
            if isinstance(repaired, dict) and repaired.get("question", question) == question:
                suggestions = choices(repaired.get("suggestions"))
        except json.JSONDecodeError:
            continue
    if not suggestions:
        raise ValueError("The planner could not supply distinct answers. Retry planning.")
    return {"question": question, "suggestions": suggestions}
