"use strict";
// Exercise the shared decision control with the server's actual pending question.
const assert = require("node:assert/strict");
const fs = require("node:fs");
const vm = require("node:vm");
const path = require("node:path");
const task = JSON.parse(fs.readFileSync(0, "utf8"));
const element = (tag, cls, ...children) => ({
  tag, children, value: "",
  append(...nodes) { children.push(...nodes); },
  focus() {}
});
const button = (text, click) => ({text, click});
const context = vm.createContext({element, button, field: (label, input) => ({label, input})});
vm.runInContext(fs.readFileSync(path.join(__dirname, "../web/panel/live.js"), "utf8"), context);
(async () => {
  const outputs = [];
  for (const mode of ["select", "edit", "replace", "direct"]) {
    const sent = [];
    const form = context.planningAnswer(task.question, task.suggestions, value => sent.push(value));
    const [{input, label}, options, submit] = form.children;
    assert.equal(label, task.question);
    assert.deepEqual(options.children.map(b => b.text), task.suggestions);
    if (mode !== "direct") options.children[1].click();
    assert.equal(input.value, mode === "direct" ? "" : task.suggestions[1]);
    if (mode === "edit") input.value += " with an accessible label";
    if (mode === "replace") input.value = "/continue";
    if (mode === "direct") input.value = "An independent choice";
    assert.equal(sent.length, 0);
    await submit.click();
    assert.deepEqual(sent, [input.value]);
    outputs.push(sent[0]);
  }
  process.stdout.write(JSON.stringify(outputs));
})().catch(error => { console.error(error); process.exitCode = 1; });

