"""Request and retain PNG mockups through the Images API."""
import base64
import json
import os
import struct
import zlib
from urllib.request import Request, urlopen


def generate(prompt, previous=None):
    key = os.environ.get("OPENAI_API_KEY")
    if not key:
        from codex_mockups import generate_mockup
        return generate_mockup(prompt, previous)
    path = "generations"
    body = dict(model=os.environ.get("WORKBENCH_IMAGE_MODEL", "gpt-image-2"),
                prompt=prompt, output_format="png")
    if previous is not None:
        path = "edits"
        body["images"] = [{"image_url": "data:image/png;base64," + base64.b64encode(previous).decode()}]
    request = Request("https://api.openai.com/v1/images/" + path, json.dumps(body).encode(),
                      headers={"Authorization": "Bearer " + key, "Content-Type": "application/json"})
    with urlopen(request, timeout=300) as reply:
        data = json.load(reply)
    return base64.b64decode(data["data"][0]["b64_json"], validate=True)


def validate_png(data):
    if not data.startswith(b"\x89PNG\r\n\x1a\n") or data[12:16] != b"IHDR":
        raise ValueError("The image provider returned an invalid PNG.")
    offset = 8
    pixels = bytearray()
    while offset + 12 <= len(data):
        size, = struct.unpack_from(">I", data, offset)
        end = offset + 8 + size
        chunk = data[offset + 4:end]
        if end + 4 > len(data) or zlib.crc32(chunk) != int.from_bytes(data[end:end + 4], "big"):
            break
        if chunk[:4] == b"IDAT":
            pixels.extend(chunk[4:])
        if chunk == b"IEND" and end + 4 == len(data):
            try:
                if zlib.decompress(pixels):
                    return
            except zlib.error:
                pass
            break
        offset = end + 4
    raise ValueError("The image provider returned incomplete PNG data.")

