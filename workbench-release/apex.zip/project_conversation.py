"""Record project guidance and validate proposals without changing project editors."""
import json

from audited_flow import object_reply, owned
from design_host import preview_url
from design_workspace import TASK_MODE, DesignPlanner, Workspace, identifier, now, required, roadmap
from planning import choices


CONTEXT_FIELDS = ("view", "tab", "section", "id", "label", "kind", "reviewId",
                  "commit", "ref", "scenarioId", "scenarioTitle", "route")


def guidance_context(value):
    if not isinstance(value, dict):
        raise ValueError("Supply the current Workbench context.")
    return {key: value[key][:400] for key in CONTEXT_FIELDS if isinstance(value.get(key), str)}


def project_evidence(project):
    from project_capabilities import discover

    values = discover(project)

    def commands(group):
        return [{key: item[key] for key in ("id", "label", "argv", "cwd", "url") if key in item} |
                {"source": item["source"][:2]} for item in values[group][:8]
                if len(json.dumps(item["argv"])) <= 2000]

    git = values["git"]
    return {"git": {"branch": git["branch"], "refs": git["refs"][:24]},
            "checks": commands("checks"), "previews": commands("previews"),
            "gaps": values["gaps"][:4]}


def project_proposal(value, state, quality, screen, task_mode=False):
    if not isinstance(value, dict):
        raise ValueError("Expected a structured project proposal.")
    kind = value.get("kind")
    title = required(value.get("title"), "a proposal title")[:150]
    proposal = {"kind": kind, "title": title, "revision": state["revision"]}
    if (kind == "plan" and screen.get("view") == "workflow" and screen.get("kind") != "branch-review"
            and screen.get("tab") in (None, "Plan", "Mockups")):
        plan = required(value.get("plan"), "proposal plan")
        if len(plan) > 64000:
            raise ValueError("The proposed plan is too large.")
        before = {"plan": state["plan"]}
        if task_mode:
            if state.get("mode") == TASK_MODE:
                before.update(mode=TASK_MODE, title=state["title"])
            else:
                before.update(mode="roadmap", roadmap=state["roadmap"])
            proposal.update(mode=TASK_MODE, plan=plan, before=before)
        else:
            proposal.update(plan=plan, roadmap=roadmap(value["roadmap"]),
                            before=dict(before, roadmap=state["roadmap"]))
    elif kind == "settings":
        fields = {}
        if "preview" in value:
            fields["preview"] = preview_url(required(value["preview"], "an app address"))
        if "branch" in value:
            branch = required(value["branch"], "a project branch")
            if len(branch) > 240:
                raise ValueError("The proposed branch name is too long.")
            fields["branch"] = branch
        if not fields:
            raise ValueError("Choose an app address or a branch.")
        proposal.update(fields=fields, before={name: state[name] for name in fields})
    elif kind == "quality" and quality is not None:
        from quality import validate
        candidate = validate(value["definition"])
        proposal.update(definition=candidate["definition"], before=quality["definition"],
                        revision=quality["revision"], baseRevision=quality["base_revision"])
    else:
        raise ValueError("The proposal does not match this screen.")
    return proposal


def guide(app, payload):
    workspace = Workspace(app)
    state = workspace.read()
    workspace.check_revision(state, payload)
    message = required(payload.get("message"), "a message")
    if len(message) > 64000:
        raise ValueError("Enter a message of at most 64000 characters.")
    screen = guidance_context(payload.get("context"))

    quality = None
    if screen.get("view") == "quality":
        from quality import Quality
        editor = Quality(workspace.root)
        quality = editor.current_draft(editor.publication())
    task_mode = payload.get("mode") == TASK_MODE or state.get("mode") == TASK_MODE
    context = dict(screen=screen, plan=state["plan"], approved=state["approved"] == state["revision"],
                   branch=state["branch"], preview=state["preview"],
                   conversation=[{"author": row["author"], "text": row["text"][-2500:]} for row in state["messages"][-12:]],
                   message=message)
    if task_mode:
        context.update(mode=TASK_MODE, title=state.get("title"))
        plan_fields = ("title and complete task plan. Include a Markdown heading named Acceptance criteria, "
                       "with one observable behavior per bullet")
    else:
        context["roadmap"] = state["roadmap"]
        plan_fields = "title, complete plan and ordered roadmap (milestones and slices with id and title, retain existing IDs)"
    if quality is not None:
        context["quality"] = quality["definition"]
    if quality is not None or screen.get("tab") in {"Preview", "Build"}:
        context["project_evidence"] = project_evidence(workspace.root)

    identity = identifier()
    planner = DesignPlanner(app, workspace.folder / "turns" / identity)
    instructions = (
        "Help with this project and the current Workbench screen. Return JSON with message (a concise answer). "
        "If a decision is necessary, include choices, an array of at least two distinct specific answers. "
        "Only if asked for a change that matches this screen, include one proposal. "
        f"For a Design plan proposal use kind=plan, {plan_fields}. "
        "For a project setting use kind=settings, title and branch or preview. "
        "For a Quality draft use kind=quality, title and the complete definition in the existing schema. Retain all "
        "unrelated entities. Do not invent command authorizations, a preview URL, a branch, or sources. "
        "Reuse literal argv and working directory from the project evidence when recommending an existing command. "
        "The user can apply or edit a proposal in the existing editor. Never say a proposal has been applied. "
        "Keep the approved plan as context for navigation, Quality, review and settings. Do not modify files.\n"
    )
    lock = workspace.folder / "conversation"
    if lock.resolve() != lock:
        raise ValueError("The conversation must belong to this project.")
    with owned(lock):
        reply = object_reply(planner.agent("plan", instructions + json.dumps(context, ensure_ascii=False)))
        answer = required(reply.get("message"), "a project reply")
        proposal = project_proposal(reply["proposal"], state, quality, screen, task_mode) if reply.get("proposal") else None
        with workspace.edit() as current:
            current["messages"].append(dict(id=identifier(), author="user", text=message, context=screen, time=now()))
            response = dict(id=identity, author="agent", text=answer[:64000], context=screen, time=now())
            suggestions = choices(reply.get("choices"))
            if suggestions:
                response["choices"] = suggestions
            if proposal:
                response["proposal"] = proposal
            current["messages"].append(response)
        return current
