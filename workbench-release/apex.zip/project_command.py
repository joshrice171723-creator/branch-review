"""Resolve project executables without interpreting argument arrays."""
import os
from pathlib import Path
import shutil


def windows_npm_argv(argv, env):
    """Run npm's entry file through a native Node executable."""
    path = env.get("PATH", "")
    wrapper = shutil.which("npm.cmd", path=path) or shutil.which("npm", path=path)
    default_node = shutil.which("node.exe", path=path) or shutil.which("node", path=path)
    bundled_node = env.get("HARNESS_NODE")
    roots = []
    for program in (wrapper, default_node, bundled_node):
        if program:
            directory = Path(program).absolute().parent
            if directory not in roots:
                roots.append(directory)
    for directory in roots:
        entry = directory / "node_modules/npm/bin/npm-cli.js"
        if not entry.is_file():
            continue
        for node in (directory / "node.exe", default_node, bundled_node):
            if node and Path(node).suffix.casefold() == ".exe" and Path(node).is_file():
                return [str(Path(node).absolute()), str(entry), *argv[1:]]
    raise ValueError("Install npm with Node.js or choose a literal Node.js npm entry command")


def resolve_argv(argv, *, env=None):
    if os.name == "nt" and argv[0].casefold() in {"npm", "npm.cmd"}:
        return windows_npm_argv(argv, os.environ if env is None else env)
    return argv
