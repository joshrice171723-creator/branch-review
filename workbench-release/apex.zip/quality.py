"""Validate, test, and publish project Quality policies."""
import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import math
import operator
import os
from pathlib import Path, PurePosixPath, PureWindowsPath
import platform
import re
import shutil
import signal
import statistics
import subprocess
import sys
import tarfile
import tempfile
import time
import uuid

from project_command import resolve_argv
from workflow_job import WindowsProcessGroup, process_group


POLICY_FILE = "workbench-quality.json"
ID = re.compile(r"[a-z][a-z0-9_-]{0,63}\Z")
DIGEST = re.compile(r"[a-f0-9]{64}\Z")
TRIAL_ID = re.compile(r"[a-f0-9]{32}\Z")
AGGREGATES = {"mean": statistics.mean, "median": statistics.median, "min": min, "max": max}
OPERATORS = {"lte": operator.le, "gte": operator.ge, "eq": operator.eq}
AGENT_STAGES = ("plan_review", "build_review", "final_review")
MAX_OUTPUT = 256 * 1024


def now():
    return datetime.now(timezone.utc).isoformat()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def encoded(value):
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def file_hash(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def save(path, value, *, exclusive=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    serialized = json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + "\n"
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", newline="\n",
                                     dir=path.parent, delete=False) as stream:
        draft = Path(stream.name)
        stream.write(serialized)
    try:
        if exclusive:
            os.link(draft, path)
        else:
            draft.replace(path)
    finally:
        draft.unlink(missing_ok=True)


@contextmanager
def locked(folder, name="write", *, wait=True):
    folder.mkdir(parents=True, exist_ok=True)
    with (folder / (name + ".lock")).open("a+b") as stream:
        try:
            if os.name == "nt":
                import msvcrt
                stream.seek(0)
                msvcrt.locking(stream.fileno(), msvcrt.LK_LOCK if wait else msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream, fcntl.LOCK_EX if wait else fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as error:
            if not wait:
                raise ValueError("Another Quality measurement is running for this project") from error
            raise
        yield


def row(value, required, optional=()):
    if not isinstance(value, dict):
        raise ValueError("Expected an object")
    missing = set(required) - value.keys()
    unknown = value.keys() - set(required) - set(optional)
    if missing or unknown:
        raise ValueError(f"Missing fields {sorted(missing)}. Unknown fields {sorted(unknown)}.")
    return dict(value)


def items(value, field, maximum=50):
    if not isinstance(value, list) or len(value) > maximum:
        raise ValueError(f"{field} must be an array of up to {maximum} items")
    return value


def label(value, field, limit=1000):
    if not isinstance(value, str) or not value.strip() or len(value) > limit or "\0" in value:
        raise ValueError(f"{field} must be nonempty text of up to {limit} characters")
    return value


def identifier(value, field):
    if not isinstance(value, str) or not ID.fullmatch(value):
        raise ValueError(f"{field} must start with a lowercase letter and use lowercase letters, digits, underscores, or hyphens")
    return value


def integer(value, field, minimum, maximum):
    if type(value) is not int or not minimum <= value <= maximum:
        raise ValueError(f"{field} must be an integer from {minimum} to {maximum}")
    return value


def boolean(value, field):
    if type(value) is not bool:
        raise ValueError(f"{field} must be true or false")
    return value


def number(value, field):
    if type(value) not in (int, float) or abs(value) > 1e100 or not math.isfinite(value):
        raise ValueError(f"{field} must be a finite number")
    return value


def relative(value, field):
    value = label(value, field).replace("\\", "/")
    path = PurePosixPath(value)
    if path.is_absolute() or PureWindowsPath(value).drive or ".." in path.parts or any(
            part in (".git", ".harness") or ":" in part for part in path.parts):
        raise ValueError(f"{field} must be a project-relative path")
    return path.as_posix()


def unique(rows, field):
    values = [entry[field] for entry in rows]
    if len(set(values)) != len(values):
        raise ValueError(f"Duplicate {field}: {values}")
    return rows


def command(value, fields=(), optional=()):
    data = row(value, ("argv", *fields), ("cwd", "timeout_seconds", *optional))
    argv = items(data["argv"], "argv", 100)
    if not argv:
        raise ValueError("argv must contain a command")
    data["argv"] = [label(arg, "argv entry", 4096) for arg in argv]
    data["cwd"] = relative(data.get("cwd", "."), "cwd")
    data["timeout_seconds"] = integer(data.get("timeout_seconds", 120), "timeout_seconds", 1, 900)
    return data


def check(value):
    data = command(value, ("id", "name", "required"), ("phases",))
    identifier(data["id"], "check ID")
    label(data["name"], "check name", 120)
    boolean(data["required"], "check required")
    data["phases"] = data.get("phases", ["baseline", "after"])
    if data["phases"] not in (["baseline", "after"], ["after"]):
        raise ValueError("Check phases must be baseline and after, or after only")
    return data


def benchmark(value, checks):
    data = row(value, ("id", "name", "check_id", "fixtures", "metrics", "repetitions", "thresholds", "reset"),
               ("scripts",))
    identifier(data["id"], "benchmark ID")
    label(data["name"], "benchmark name", 120)
    key = identifier(data["check_id"], "benchmark check ID")
    if key not in checks or checks[key]["phases"] != ["baseline", "after"]:
        raise ValueError(f"Benchmark {data['id']} requires an existing baseline and after check")
    fixtures = [row(item, ("path", "description")) for item in items(data["fixtures"], "fixtures")]
    for fixture in fixtures:
        fixture["path"] = relative(fixture["path"], "fixture path")
        label(fixture["description"], "fixture description")
    data["fixtures"] = unique(fixtures, "path")
    data["scripts"] = [relative(path, "script path") for path in items(data.get("scripts", []), "scripts")]
    if len(set(data["scripts"])) != len(data["scripts"]):
        raise ValueError("Benchmark script paths must be unique")
    metrics = [row(item, ("id", "unit"), ("aggregate",)) for item in items(data["metrics"], "metrics")]
    if not metrics:
        raise ValueError("A benchmark needs at least one metric")
    for metric in metrics:
        identifier(metric["id"], "metric ID")
        label(metric["unit"], "metric unit", 80)
        aggregate = metric.setdefault("aggregate", "median")
        if not isinstance(aggregate, str) or aggregate not in AGGREGATES:
            raise ValueError("Unsupported metric aggregate")
    data["metrics"] = unique(metrics, "id")
    data["repetitions"] = integer(data["repetitions"], "repetitions", 1, 20)
    thresholds = [row(item, ("metric", "op", "value")) for item in items(data["thresholds"], "thresholds")]
    if not thresholds:
        raise ValueError("A benchmark needs at least one threshold")
    for threshold in thresholds:
        key = identifier(threshold["metric"], "threshold metric ID")
        if key not in {metric["id"] for metric in metrics}:
            raise ValueError(f"Threshold refers to an unknown metric: {key}")
        if not isinstance(threshold["op"], str) or threshold["op"] not in OPERATORS:
            raise ValueError("Threshold operator must be lte, gte, or eq")
        number(threshold["value"], "threshold value")
    data["thresholds"] = thresholds
    data["reset"] = command(data["reset"])
    return data


def rubric(value):
    data = row(value, ("id", "name", "actor", "stage", "criteria"))
    identifier(data["id"], "rubric ID")
    label(data["name"], "rubric name", 120)
    actor, stage = data["actor"], data["stage"]
    if not ((actor == "agent" and stage in AGENT_STAGES) or (actor == "human" and stage == "branch_review")):
        raise ValueError("Use an agent audit stage or human Branch Review for a rubric")
    criteria = [row(item, ("id", "description", "required")) for item in items(data["criteria"], "criteria")]
    if not criteria:
        raise ValueError("A rubric needs at least one criterion")
    for criterion in criteria:
        identifier(criterion["id"], "criterion ID")
        label(criterion["description"], "criterion description")
        boolean(criterion["required"], "criterion required")
    data["criteria"] = unique(criteria, "id")
    return data


def validate(definition):
    data = row(definition, ("schema_version", "checks", "benchmarks", "rubrics"))
    integer(data["schema_version"], "schema_version", 1, 1)
    data["checks"] = unique([check(item) for item in items(data["checks"], "checks")], "id")
    checks = {item["id"]: item for item in data["checks"]}
    data["benchmarks"] = unique([benchmark(item, checks) for item in items(data["benchmarks"], "benchmarks")], "id")
    unique(data["benchmarks"], "check_id")
    data["rubrics"] = unique([rubric(item) for item in items(data["rubrics"], "rubrics")], "id")
    unique(data["rubrics"], "stage")
    return {"revision": digest(data), "definition": data}


def criterion_issues(criteria, selected):
    if not isinstance(criteria, list) or not all(isinstance(item, dict) for item in criteria):
        return [f"Record criteria for rubric {selected['id']}"]
    allowed = {item["id"] for item in selected["criteria"]}
    by_id = {}
    for item in criteria:
        key = item.get("id")
        if not isinstance(key, str) or key not in allowed:
            return ["Review contains an unknown criterion"]
        if key in by_id:
            return ["Review criterion IDs must be unique"]
        by_id[key] = item
    issues = []
    for criterion in selected["criteria"]:
        if not criterion["required"]:
            continue
        answer = by_id.get(criterion["id"], {})
        evidence = answer.get("evidence")
        verdict = answer.get("verdict")
        reason = answer.get("reason")
        if (not isinstance(evidence, list) or not any(isinstance(text, str) and text.strip() for text in evidence)
                or not (verdict == "pass" or verdict == "not_applicable" and isinstance(reason, str) and reason.strip())):
            issues.append(f"Required criterion needs passing evidence: {criterion['id']}")
    return issues


def locked_definition(value):
    normalized = validate(value["definition"])
    if (normalized["revision"] != value.get("revision")
            or encoded(normalized["definition"]) != encoded(value["definition"])):
        raise ValueError("Quality policy does not match its revision")
    return normalized


def git(project, *argv):
    result = subprocess.run(["git", "-C", str(project), *argv], capture_output=True, encoding="utf-8",
                            errors="replace", timeout=60)
    if result.returncode:
        raise ValueError(result.stderr.strip() or "Git command failed")
    return result.stdout.strip()


def resolve_refs(project, refs):
    if not isinstance(refs, list) or not 1 <= len(refs) <= 2:
        raise ValueError("Supply one or two committed Git refs")
    resolved = []
    for ref in refs:
        label(ref, "Git ref", 200)
        sha = git(project, "rev-parse", "--verify", "--end-of-options", ref + "^{commit}")
        resolved.append({"ref": ref, "sha": sha})
    return unique(resolved, "sha")


def export_commit(project, sha, dest):
    archive = dest.parent / (dest.name + ".tar")
    git(project, "archive", "--format=tar", "-o", str(archive), sha)
    dest.mkdir()
    with tarfile.open(archive) as tar:
        tar.extractall(dest, filter="data")
    archive.unlink()


def inside(root, path):
    resolved = (root / path).resolve(strict=True)
    if not resolved.is_relative_to(root):
        raise ValueError(f"Path escapes the trial checkout: {path}")
    return resolved


def read_stream(stream):
    stream.seek(0)
    data = stream.read(MAX_OUTPUT + 1)
    return data[:MAX_OUTPUT].decode("utf-8", errors="replace"), len(data) > MAX_OUTPUT


def run_command(root, spec):
    started = time.monotonic()
    result = {"argv": spec["argv"], "cwd": spec["cwd"], "status": "error", "exit_code": None}
    with tempfile.TemporaryFile() as stdout, tempfile.TemporaryFile() as stderr:
        try:
            with subprocess.Popen(resolve_argv(spec["argv"]), cwd=inside(root, spec["cwd"]), stdin=subprocess.DEVNULL,
                                  stdout=stdout, stderr=stderr, **process_group()) as proc:
                group = None
                try:
                    if os.name == "nt":
                        group = WindowsProcessGroup(proc)
                    exit_code = proc.wait(timeout=spec["timeout_seconds"])
                    result.update(exit_code=exit_code, status="passed" if exit_code == 0 else "failed")
                except subprocess.TimeoutExpired:
                    result["error"] = f"Command exceeded {spec['timeout_seconds']} seconds"
                    if group:
                        group.terminate()
                    else:
                        try:
                            os.killpg(proc.pid, signal.SIGKILL)
                        except ProcessLookupError:
                            pass
                    proc.wait()
                except OSError:
                    proc.kill()
                    raise
                finally:
                    if group:
                        group.close()
        except (OSError, ValueError) as error:
            result["error"] = str(error)
        result["stdout"], result["stdout_truncated"] = read_stream(stdout)
        result["stderr"], result["stderr_truncated"] = read_stream(stderr)
    result["duration_seconds"] = round(time.monotonic() - started, 6)
    return result


def path_evidence(root, paths):
    return [{"path": name, "sha256": file_hash(inside(root, name))} for name in paths]


def measure(root, spec, check_spec):
    output = {"id": spec["id"], "check_id": check_spec["id"], "status": "error",
              "fixtures": [], "scripts": [], "samples": [], "metrics": [], "thresholds": []}
    try:
        output["fixtures"] = [dict(item, sha256=file_hash(inside(root, item["path"]))) for item in spec["fixtures"]]
        output["scripts"] = path_evidence(root, spec["scripts"])
        for _ in range(spec["repetitions"]):
            reset = run_command(root, spec["reset"])
            sample = {"reset": reset}
            output["samples"].append(sample)
            if reset["status"] != "passed":
                raise ValueError("Benchmark reset failed")
            result = run_command(root, check_spec)
            sample["command"] = result
            if result["status"] == "error":
                raise ValueError(result.get("error", "Benchmark command failed to run"))
            if result["status"] == "failed":
                output["status"] = "failed"
                output["error"] = "Benchmark command returned a nonzero exit code"
                return output
            if result["stdout_truncated"]:
                raise ValueError("Benchmark stdout exceeded the evidence limit")
            lines = [line for line in result["stdout"].splitlines() if line.strip()]
            payload = json.loads(lines[-1]) if lines else None
            metrics = payload.get("metrics") if isinstance(payload, dict) else None
            expected = {metric["id"] for metric in spec["metrics"]}
            if not isinstance(metrics, dict) or metrics.keys() != expected:
                raise ValueError("Benchmark must return one numeric value per declared metric")
            sample["metrics"] = {key: number(value, key) for key, value in metrics.items()}
        for metric in spec["metrics"]:
            samples = [sample["metrics"][metric["id"]] for sample in output["samples"]]
            value = AGGREGATES[metric["aggregate"]](samples)
            output["metrics"].append(dict(metric, value=value, samples=samples))
        values = {metric["id"]: metric["value"] for metric in output["metrics"]}
        for threshold in spec["thresholds"]:
            actual = values[threshold["metric"]]
            passed = OPERATORS[threshold["op"]](actual, threshold["value"])
            output["thresholds"].append(dict(threshold, actual=actual, passed=passed))
        output["status"] = "passed" if all(row["passed"] for row in output["thresholds"]) else "failed"
    except (OSError, ValueError) as error:
        output["error"] = str(error)
    return output


def run_trial_ref(project, ref, definition, dest):
    output = dict(ref, checks=[], benchmarks=[], status="error")
    try:
        export_commit(project, ref["sha"], dest)
        checks = {item["id"]: item for item in definition["checks"]}
        measured = {item["check_id"] for item in definition["benchmarks"]}
        commands = [item for item in checks.values() if item["id"] not in measured]
        shared = len(commands) + len(measured) > 1
        for check_spec in commands:
            with trial_checkout(dest, shared) as checkout:
                output["checks"].append(dict(run_command(checkout, check_spec), id=check_spec["id"],
                                            required=check_spec["required"]))
        for spec in definition["benchmarks"]:
            with trial_checkout(dest, shared) as checkout:
                output["benchmarks"].append(measure(checkout, spec, checks[spec["check_id"]]))
        all_rows = output["checks"] + output["benchmarks"]
        if all(item["status"] != "error" for item in all_rows):
            gated = [item for item in output["checks"] if item["required"]] + output["benchmarks"]
            output["status"] = "passed" if all(item["status"] == "passed" for item in gated) else "failed"
    except (OSError, ValueError, subprocess.TimeoutExpired, tarfile.TarError) as error:
        output["error"] = str(error)
    return output


@contextmanager
def trial_checkout(source, shared):
    if not shared:
        yield source
        return
    with tempfile.TemporaryDirectory(dir=source.parent, prefix="command-") as folder:
        target = Path(folder) / "project"
        shutil.copytree(source, target, symlinks=True)
        yield target


def compatible(refs):
    if len(refs) != 2:
        return True
    return all(
        before["fixtures"] == after["fixtures"] and before["scripts"] == after["scripts"]
        for before, after in zip(refs[0]["benchmarks"], refs[1]["benchmarks"], strict=True)
    )


def environment(project):
    return {"kind": "local_disposable_export", "image": None, "os": platform.platform(),
            "architecture": platform.machine(), "python": platform.python_version(),
            "git": git(project, "--version")}


def draft_upgrade(project):
    """Offer existing checks as draft inputs and keep legacy runs unchanged."""
    settings = project / ".harness/project.json"
    legacy = read(settings) if settings.is_file() else {}
    profile = project / ".harness/profile.json"
    if profile.is_file() and not profile.with_suffix(".disabled").exists():
        legacy = read(profile)
    checks = [dict({key: value for key, value in item.items()
                    if key in ("name", "argv", "cwd", "phases", "required")},
                   id=item["name"], required=item["required"] or item["benchmark"])
              for item in legacy.get("checks", [])]
    return validate({"schema_version": 1, "checks": checks, "benchmarks": [], "rubrics": []})


class Quality:
    def __init__(self, project):
        self.project = Path(project).resolve(strict=True)
        self.home = self.project / ".harness/quality"
        self.active = self.project / POLICY_FILE

    def publication(self, *, committed=False):
        if not self.active.is_file():
            return None
        value = read(self.active)
        row(value, ("revision", "definition", "trial_id", "published_at", "trial_status", "reviewer"))
        locked_definition(value)
        if value["trial_status"] not in ("passed", "failed") or value["reviewer"] != "human" or not (
                isinstance(value["trial_id"], str) and TRIAL_ID.fullmatch(value["trial_id"])):
            raise ValueError("Invalid Quality publication")
        record_path = self.home / "publications" / (value["trial_id"] + ".json")
        if not committed and record_path.is_file() and read(record_path) == value:
            return value
        try:
            same_commit = json.loads(git(self.project, "show", f"HEAD:{POLICY_FILE}")) == value
        except (OSError, ValueError, subprocess.TimeoutExpired):
            same_commit = False
        if not same_commit:
            raise ValueError("Quality policy requires a recorded human publication or the committed policy")
        return value

    def current_draft(self, published):
        path = self.home / "draft.json"
        if path.is_file():
            value = read(path)
            locked_definition(value)
            return value
        definition = locked_definition(published) if published else draft_upgrade(self.project)
        return dict(definition, base_revision=published["revision"] if published else None, actor="human")

    def status(self):
        published = self.publication()
        trials = [read(path) for path in (self.home / "trials").glob("*/summary.json")
                  if TRIAL_ID.fullmatch(path.parent.name)]
        publications = [read(path) for path in (self.home / "publications").glob("*.json")]
        if published and all(row["trial_id"] != published["trial_id"] for row in publications):
            publications.append(published)
        publications = [{key: value for key, value in item.items() if key != "definition"} for item in publications]
        return {"published": published, "draft": self.current_draft(published),
                "trials": sorted(trials, key=lambda item: item["created_at"], reverse=True),
                "publications": sorted(publications, key=lambda item: item["published_at"], reverse=True)}

    @staticmethod
    def summary(trial):
        summary = {key: trial[key] for key in ("id", "revision", "policy", "created_at", "status", "environment")}
        summary["refs"] = [{key: ref[key] for key in ("ref", "sha", "status")} for ref in trial["refs"]]
        return summary

    def draft(self, definition, base_revision, expected_revision=None, *, actor="human"):
        if actor not in ("agent", "human"):
            raise ValueError("Invalid Quality draft author")
        candidate = validate(definition)
        with locked(self.home):
            published = self.publication()
            prior = self.current_draft(published)
            base = published["revision"] if published else None
            if base_revision != base:
                raise ValueError("Quality publication changed. Reload before saving.")
            if expected_revision != prior["revision"]:
                raise ValueError("Quality draft changed. Reload before saving.")
            value = dict(candidate, base_revision=base, actor=actor)
            save(self.home / "draft.json", value)
        return value

    def trial(self, revision, refs, *, policy="draft", committed=False):
        published = self.publication(committed=committed)
        if committed and policy != "published":
            raise ValueError("Agent trials require the committed Quality publication")
        if policy not in ("published", "draft"):
            raise ValueError("Select the draft or published Quality policy")
        selected = published if policy == "published" else self.current_draft(published)
        if not selected or revision != selected["revision"]:
            raise ValueError("Select the current Quality revision before starting a trial")
        definition = selected["definition"]
        if not any(item["required"] for item in definition["checks"]) and not definition["benchmarks"]:
            raise ValueError("Configure a required check or benchmark before testing")
        resolved = resolve_refs(self.project, refs)
        experiment = {"id": uuid.uuid4().hex, "revision": revision, "policy": policy,
                      "created_at": now(), "environment": environment(self.project), "definition": definition}
        with locked(self.home, "runner", wait=False), tempfile.TemporaryDirectory(prefix="workbench-quality-") as folder:
            experiment["refs"] = [run_trial_ref(self.project, ref, definition, Path(folder) / f"ref-{index}")
                                  for index, ref in enumerate(resolved)]
        statuses = {ref["status"] for ref in experiment["refs"]}
        if "error" in statuses:
            experiment["status"] = "error"
        elif not compatible(experiment["refs"]):
            experiment.update(status="error", error="Benchmark fixtures or declared scripts differ between refs")
        else:
            experiment["status"] = "failed" if "failed" in statuses else "passed"
        history = self.home / "trials"
        history.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=history, prefix="record-") as folder:
            staged = Path(folder)
            save(staged / "evidence.json", experiment)
            save(staged / "summary.json", self.summary(experiment))
            staged.rename(history / experiment["id"])
        return experiment

    def evidence(self, trial_id):
        if not isinstance(trial_id, str) or not TRIAL_ID.fullmatch(trial_id):
            raise ValueError("Invalid trial ID")
        path = self.home / "trials" / trial_id / "evidence.json"
        if not path.is_file():
            raise ValueError("Quality trial does not exist")
        proof = read(path)
        if proof["id"] != trial_id:
            raise ValueError("Quality trial identity does not match")
        locked_definition(proof)
        return proof

    def version(self, trial_id):
        if not isinstance(trial_id, str) or not TRIAL_ID.fullmatch(trial_id):
            raise ValueError("Invalid publication ID")
        path = self.home / "publications" / (trial_id + ".json")
        if path.is_file():
            value = read(path)
            if value["trial_id"] != trial_id:
                raise ValueError("Quality publication identity does not match")
            locked_definition(value)
            return value
        published = self.publication()
        if not published or published["trial_id"] != trial_id:
            raise ValueError("Quality publication does not exist")
        return published

    def export(self, trial_id):
        trial = self.evidence(trial_id)
        proof = {key: trial[key] for key in ("id", "revision", "policy", "status", "environment", "created_at")}
        publication = self.home / "publications" / (trial_id + ".json")
        if publication.is_file():
            signed = read(publication)
            proof["publication"] = {key: signed[key] for key in ("published_at", "reviewer", "trial_status")}
        proof["refs"] = []
        for ref in trial["refs"]:
            summary = {key: ref[key] for key in ("ref", "sha", "status")}
            summary["checks"] = [{key: item[key] for key in ("id", "status", "exit_code", "required", "duration_seconds")}
                                 for item in ref["checks"]]
            summary["benchmarks"] = [{key: item[key] for key in ("id", "check_id", "status", "fixtures",
                                                                  "scripts", "metrics", "thresholds")}
                                     for item in ref["benchmarks"]]
            proof["refs"].append(summary)
        return proof

    def publish(self, revision, trial_id, *, actor="human", allow_failed=False):
        if actor != "human":
            raise ValueError("Quality publication requires a human decision")
        boolean(allow_failed, "allow_failed")
        with locked(self.home):
            previous = self.publication()
            draft = self.current_draft(previous)
            if revision != draft["revision"]:
                raise ValueError("Quality draft changed. Test the current draft before publishing.")
            if draft["base_revision"] != (previous["revision"] if previous else None):
                raise ValueError("Quality publication changed. Save and test a new draft.")
            proof = self.evidence(trial_id)
            allowed = ("passed", "failed") if allow_failed else ("passed",)
            if proof["policy"] != "draft" or proof["revision"] != revision or proof["status"] not in allowed:
                raise ValueError("Publication requires a completed trial of this draft. Confirm any failed results.")
            record_path = self.home / "publications" / (trial_id + ".json")
            value = dict(locked_definition(draft), trial_id=trial_id, published_at=now(),
                         reviewer="human", trial_status=proof["status"])
            if record_path.is_file():
                # Recover an interrupted publication without replacing its receipt.
                value = read(record_path)
                locked_definition(value)
                if value["revision"] != revision:
                    raise ValueError("Publication receipt uses another revision")
            else:
                save(record_path, value, exclusive=True)
            save(self.active, value)
            save(self.home / "draft.json", dict(locked_definition(draft), base_revision=revision, actor="human"))
        return value


def task_check(project, payload):
    """Run one check on a disposable copy of the exact task snapshot."""
    pin = locked_definition(payload["policy"])
    definition = pin["definition"]
    check_spec = next(item for item in definition["checks"] if item["id"] == payload["check"])
    spec = next((item for item in definition["benchmarks"] if item["check_id"] == check_spec["id"]), None)
    with (locked(project / ".harness/quality", "runner", wait=False),
          tempfile.TemporaryDirectory(prefix="workbench-quality-check-") as folder):
        dest = Path(folder)
        for name, expected in payload["files"].items():
            name = relative(name, "snapshot path")
            source = project / name
            resolved = inside(project, name)
            target = dest / name
            target.parent.mkdir(parents=True, exist_ok=True)
            if source.is_symlink():
                link = os.readlink(source)
                if PureWindowsPath(link).drive or PurePosixPath(link).is_absolute():
                    raise ValueError(f"Quality task snapshots require relative symlinks: {name}")
                target.symlink_to(link, target_is_directory=resolved.is_dir())
                actual = hashlib.sha256(("symlink:" + link).encode()).hexdigest()
            else:
                shutil.copy2(resolved, target)
                actual = file_hash(target)
            if actual != expected:
                raise ValueError(f"Source changed before the Quality check: {name}")
        return measure(dest, spec, check_spec) if spec else run_command(dest, check_spec)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("status", "draft", "validate", "trial", "evidence", "export", "version", "pin", "task-check"))
    parser.add_argument("--project", required=True, type=Path)
    args = parser.parse_args()
    try:
        quality = Quality(args.project)
        if args.command in ("status", "pin"):
            value = quality.status() if args.command == "status" else quality.publication()
        else:
            payload = json.load(sys.stdin)
            if args.command == "validate":
                value = validate(payload["definition"])
            elif args.command == "draft":
                value = quality.draft(payload["definition"], payload["base_revision"],
                                      payload["expected_revision"], actor="agent")
            elif args.command == "trial":
                value = quality.trial(payload["revision"], payload["refs"], policy=payload["policy"], committed=True)
            elif args.command == "task-check":
                value = task_check(quality.project, payload)
            else:
                value = getattr(quality, args.command)(payload["id"])
        print(json.dumps(value, ensure_ascii=True, allow_nan=False))
    except (OSError, ValueError, KeyError, TypeError, subprocess.TimeoutExpired) as error:
        print(str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
