"""Exercise Quality against actual commits, a disposable runner, and the task ledger."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from audited_flow import Runtime, read, run, save
from quality import Quality, validate


class QualityTests(unittest.TestCase):
    def setUp(self):
        if not shutil.which("git"):
            self.skipTest("Git is required")
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.project = Path(tmp.name).resolve()
        self.quality = Quality(self.project)
        self.git("init")
        (self.project / ".gitignore").write_text(".harness/\n")
        (self.project / "fixture.txt").write_text("fixed fixture\n")
        (self.project / "value.txt").write_text("10\n")
        (self.project / "measure.py").write_text(
            'from pathlib import Path\n'
            'import json\n'
            'assert not Path("scratch.txt").exists()\n'
            'Path("scratch.txt").write_text("trial output")\n'
            'print(json.dumps({"metrics": {"rows": int(Path("value.txt").read_text())}}))\n'
        )
        self.good = self.commit("Good control")
        rubric = lambda stage: dict(id=stage, name=stage, stage=stage, actor="agent",
                                    criteria=[dict(id="trace", description="Trace the normal caller", required=True)])
        self.definition = {
            "schema_version": 1,
            "checks": [dict(id="measure", name="Measure rows", argv=[sys.executable, "measure.py"], required=True)],
            "benchmarks": [dict(id="rows", name="Rows", check_id="measure", repetitions=2,
                                fixtures=[dict(path="fixture.txt", description="Fixed input")], scripts=["measure.py"],
                                metrics=[dict(id="rows", unit="rows", aggregate="median")],
                                thresholds=[dict(metric="rows", op="lte", value=15)],
                                reset=dict(argv=[sys.executable, "-c",
                                                 "from pathlib import Path; Path('scratch.txt').unlink(missing_ok=True)"]))],
            "rubrics": [rubric("plan_review"), rubric("final_review"),
                        dict(id="review", name="Branch Review", actor="human", stage="branch_review",
                             criteria=[dict(id="preview", description="Inspect the preview", required=True)])],
        }

    def git(self, *args):
        return self.command(["git", *args]).stdout.strip()

    def command(self, argv, *, check=True):
        result = subprocess.run(argv, cwd=self.project, capture_output=True, text=True, encoding="utf-8",
                                env=dict(os.environ, HARNESS_PYTHON=sys.executable))
        if check and result.returncode:
            self.fail(result.stderr or result.stdout)
        return result

    def commit(self, message):
        self.git("add", "-A")
        self.git("-c", "user.name=Quality test", "-c", "user.email=quality@example.invalid", "-c",
                 "commit.gpgsign=false", "commit", "-m", message)
        return self.git("rev-parse", "HEAD")

    def draft(self):
        status = self.quality.status()
        base = status["published"]["revision"] if status["published"] else None
        return self.quality.draft(self.definition, base, status["draft"]["revision"])

    def test_two_exact_refs_require_human_publication_and_keep_evidence(self):
        (self.project / "value.txt").write_text("25\n")
        bad = self.commit("Bad control")
        (self.project / "value.txt").write_text("999\n")
        initial = self.quality.status()["draft"]["revision"]
        draft = self.draft()
        with self.assertRaisesRegex(ValueError, "draft changed"):
            self.quality.draft(self.definition, None, initial)
        trial = self.quality.trial(draft["revision"], [self.good, bad])
        self.assertEqual([ref["sha"] for ref in trial["refs"]], [self.good, bad])
        self.assertEqual([ref["status"] for ref in trial["refs"]], ["passed", "failed"], trial)
        self.assertEqual(trial["refs"][0]["benchmarks"][0]["metrics"][0]["samples"], [10, 10])
        self.assertEqual(trial["status"], "failed")
        self.assertEqual((self.project / "value.txt").read_text(), "999\n")
        self.assertFalse((self.project / "scratch.txt").exists())
        self.assertIsNone(self.quality.publication())
        with self.assertRaisesRegex(ValueError, "human decision"):
            self.quality.publish(draft["revision"], trial["id"], actor="agent", allow_failed=True)
        with self.assertRaisesRegex(ValueError, "Confirm any failed"):
            self.quality.publish(draft["revision"], trial["id"])
        published = self.quality.publish(draft["revision"], trial["id"], allow_failed=True)
        self.assertEqual(published, self.quality.version(trial["id"]))
        self.assertEqual(trial, self.quality.evidence(trial["id"]))
        summary = self.quality.status()["trials"][0]
        self.assertNotIn("benchmarks", summary["refs"][0])
        export = self.quality.export(trial["id"])
        self.assertEqual(export["publication"]["reviewer"], "human")
        self.assertNotIn("stdout", json.dumps(export))
        with self.assertRaisesRegex(ValueError, "committed policy"):
            self.quality.trial(draft["revision"], [self.good], policy="published", committed=True)
        self.commit("Publish Quality policy")
        self.assertEqual(self.quality.publication(committed=True)["revision"], draft["revision"])

    def test_incomplete_metrics_cannot_publish(self):
        self.definition["benchmarks"][0]["metrics"].append(dict(id="duration", unit="seconds"))
        draft = self.draft()
        trial = self.quality.trial(draft["revision"], [self.good])
        self.assertEqual(trial["status"], "error", trial)
        self.assertIn("declared metric", trial["refs"][0]["benchmarks"][0]["error"])
        with self.assertRaisesRegex(ValueError, "completed trial"):
            self.quality.publish(draft["revision"], trial["id"], allow_failed=True)
        self.definition["checks"].append(self.definition["checks"][0])
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            validate(self.definition)

    def test_installed_coordinator_uses_pinned_quality_after_new_publication(self):
        if not shutil.which("ruby"):
            self.skipTest("Ruby is required")
        harness = Path(__file__).resolve().parent / "bin/harness"

        def cli(*args):
            return json.loads(self.command(["ruby", str(harness), *args, "--project", str(self.project)]).stdout)

        cli("setup", "init")
        home = self.project / ".harness"
        settings = read(home / "project.json")
        settings["execution"]["workflow"] = "audited"
        save(home / "settings.json", settings)
        cli("setup", "configure", "--file", str(home / "settings.json"))
        save(home / "answers.json", dict(scope_confirmed="confirmed", code_changes="allow_scoped",
                                        migrations="deny", dependencies="deny", engine_integration="confirmed"))
        first = self.draft()
        before = self.quality.trial(first["revision"], [self.good])
        self.quality.publish(first["revision"], before["id"])
        start = cli("feature", "--action", "Raise the value", "--scope", "value.txt", "--file", str(home / "answers.json"))
        self.assertEqual(start["quality_revision"], first["revision"])
        rt = Runtime(self.project, start["task_id"])
        self.definition["benchmarks"][0]["thresholds"][0]["value"] = 1
        second = self.draft()
        after = self.quality.trial(second["revision"], [self.good])
        self.quality.publish(second["revision"], after["id"], allow_failed=True)

        def reply(stage, prompt, write=False):
            self.assertIn(first["revision"], prompt)
            if stage == "plan":
                return json.dumps({"plan": "Raise the value and measure rows"})
            if stage == "build":
                self.assertTrue(write)
                (self.project / "value.txt").write_text("12\n")
                return "Updated value.txt"
            criteria = []
            if stage in {"plan_review", "final_review"}:
                self.assertIn("Trace the normal caller", prompt)
                criteria.append(dict(id="trace", verdict="pass", evidence=["Checked value.txt and the benchmark receipt"]))
            return json.dumps(dict(verdict="pass", reason="Checked evidence", criteria=criteria))

        with patch.object(rt, "agent", side_effect=reply):
            self.assertIn("Completed.", run(rt))
        history = cli("runs", "show", start["task_id"])
        self.assertEqual(history["ledger"]["verdict"], "pass")
        self.assertTrue(all(row["quality_revision"] == first["revision"] for row in history["audits"]))
        self.assertEqual([row.get("rubric_id") for row in history["audits"]], ["plan_review", None, "final_review"])
        self.assertEqual({row["measurement"]["metrics"][0]["value"] for row in history["checks"]}, {10.0, 12.0})
        self.assertEqual(rt.status()["quality_revision"], first["revision"])
        self.assertFalse((self.project / "scratch.txt").exists())


if __name__ == "__main__":
    unittest.main()
