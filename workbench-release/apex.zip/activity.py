"""Public coordinator events. A cursor is a byte offset after a complete JSON line."""
from datetime import datetime, timezone
import json
import re


def publish(folder, stage, actor, message):
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / "activity.jsonl"
    event = dict(run=folder.name, stage=stage, actor=actor,
                 timestamp=datetime.now(timezone.utc).isoformat(), activity=message)
    # The coordinator owns the write lock. Cancellation publishes after the process exits.
    with path.open("a+b") as stream:
        end = stream.tell()
        if end:
            stream.seek(end - 1)
            if stream.read(1) != b"\n":
                while end:
                    stream.seek(end - 1)
                    if stream.read(1) == b"\n":
                        break
                    end -= 1
                stream.truncate(end)
        stream.write(json.dumps(event, ensure_ascii=True).encode() + b"\n")


def page(project, run, after):
    if not re.fullmatch(r"[\w-]+", run) or after < 0:
        raise ValueError("Invalid run or activity cursor")
    home = project / ".harness"
    record = home / "tasks" / run / "task.json"
    path = home / "loops" / run / "activity.jsonl"
    if record.resolve() != record or not record.is_file() or path.resolve() != path:
        raise ValueError("Unknown project run")
    events = []
    if not path.exists():
        if after:
            raise ValueError("Unknown activity cursor")
        return {"events": [], "cursor": 0}
    with path.open("rb") as stream:
        if after:
            stream.seek(after - 1)
            if stream.read(1) != b"\n":
                raise ValueError("Unknown activity cursor")
        for line in stream:
            if not line.endswith(b"\n"):
                break
            after += len(line)
            events.append(dict(json.loads(line), cursor=after))
            if len(events) == 200:
                break
    return {"events": events, "cursor": after}
