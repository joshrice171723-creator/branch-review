"""Summarize recorded Design build outcomes for a project."""
from datetime import datetime


def seconds(start, finish):
    try:
        return max(0, (datetime.fromisoformat(finish) - datetime.fromisoformat(start)).total_seconds())
    except (TypeError, ValueError):
        return 0


def delivery_summary(state):
    rows = []
    for build in reversed(state["builds"]):
        approved = set()
        finding_count = 0
        repaired_findings = 0
        pushed = 0
        for group in build["groups"]:
            sha = group.get("sha")
            review = (group.get("reviews") or [None])[-1]
            if sha and review and review["sha"] == sha:
                approved.update(group["slices"])
                if (group.get("pushed") or {}).get("sha") == sha:
                    pushed += 1
            finding_count += len(group.get("findings", []))
            repaired_findings += sum(bool(f.get("repaired")) for f in group.get("findings", []))
        attempts = build["attempts"]
        elapsed = sum(seconds(attempt.get("started"), attempt.get("finished")) for attempt in attempts)
        rows.append({
            "build": build["id"], "branch": build["branch"], "planRevision": build["revision"],
            "status": build["status"], "plannedSlices": sum(len(group["slices"]) for group in build["groups"]),
            "approvedSlices": len(approved), "pushedGroups": pushed, "attempts": len(attempts),
            "finishedAttempts": sum(bool(attempt.get("finished")) for attempt in attempts),
            "findings": finding_count, "repairedFindings": repaired_findings, "runSeconds": round(elapsed, 3),
            "providerCost": None, "activeReviewerMinutes": None,
        })
    return {"builds": rows}
