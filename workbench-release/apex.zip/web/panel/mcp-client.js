"use strict";

function workbenchClient(endpoint = "/mcp") {
  let sequence = 0;
  let ready;
  const version = "2025-11-25";
  async function send(method, params, notification = false) {
    const id = ++sequence;
    const response = await fetch(endpoint, {
      method: "POST", signal: AbortSignal.timeout(4500),
      headers: {"Content-Type": "application/json", Accept: "application/json, text/event-stream", "MCP-Protocol-Version": version},
      body: JSON.stringify({jsonrpc: "2.0", ...(notification ? {} : {id}), method, params})
    });
    if (!response.ok) throw new Error("Local MCP returned HTTP " + response.status + ".");
    if (notification) return;
    const message = await response.json();
    if (message.jsonrpc !== "2.0" || message.id !== id || message.error) throw new Error(message.error?.message || "Unexpected MCP response.");
    return message.result;
  }
  async function connect() {
    const info = await send("initialize", {protocolVersion: version, clientInfo: {name: "workbench-editor", version: "1"}, capabilities: {}});
    if (!info.capabilities?.tools || info.protocolVersion !== version) throw new Error("Incompatible MCP service.");
    await send("notifications/initialized", {}, true);
    return (await send("tools/list", {})).tools;
  }
  return async (name, args) => {
    const connection = ready ||= connect();
    let result;
    try {
      const tools = await connection;
      if (!tools.some(tool => tool.name === name)) throw new Error("Tool unavailable: " + name);
      result = await send("tools/call", {name, arguments: args});
    } catch (error) {
      if (ready === connection) ready = null;
      throw error;
    }
    if (result.isError) throw new Error(result.content[0].text);
    return result.structuredContent;
  };
}
