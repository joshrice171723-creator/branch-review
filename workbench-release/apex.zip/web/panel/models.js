"use strict";
const modelCatalog = {
  "captured": "2026-11-21",
  "Muse": {
    "source": "muse exec --list-models",
    "models": [
      "muse-wonder-1.0",
      "muse-ember-1.0",
      "muse-spark-1.3",
      "muse-spark-1.2"
    ]
  },
  "Codex": {
    "source": "Installed Codex model catalog, visible entries",
    "models": [
      "gpt-6.2-sol",
      "gpt-6.2-astra",
      "gpt-6.1-terra",
      "gpt-6.1-sol",
      "gpt-6-astra",
      "gpt-6-sol",
      "gpt-6-luna",
      "gpt-5.6-sol",
      "gpt-5.6-terra",
      "gpt-5.6-luna"
    ]
  }
};
if (typeof module !== "undefined") module.exports = modelCatalog;
