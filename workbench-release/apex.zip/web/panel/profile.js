"use strict";

const WorkbenchProfile = (() => {
  const roles = [
    {id: "plan", name: "Plan", icon: "≡", kind: "Agent", description: "Define scope, acceptance criteria, and unresolved questions."},
    {id: "planReview", name: "Plan audit", icon: "◇", kind: "Audit", description: "Review the plan against the request before implementation."},
    {id: "build", name: "Build & repair", icon: "⌘", kind: "Agent", description: "Implement the reviewed plan or fix a recorded finding."},
    {id: "checks", name: "Project checks", icon: "✓", kind: "Gate", description: "Run behavior checks and benchmarks on the current source."},
    {id: "buildReview", name: "Build audit", icon: "◇", kind: "Audit", description: "Review the implementation and its check receipts."},
    {id: "finalReview", name: "Final audit", icon: "◇", kind: "Audit", description: "Start a fresh review and record evidence for each criterion."},
    {id: "verify", name: "Verify & report", icon: "▤", kind: "Gate", description: "Verify the evidence against the current source and report."}
  ];
  const audits = roles.filter(role => role.kind === "Audit");
  const efforts = ["low", "medium", "high", "xhigh"];
  const providers = ["Codex", "Muse", "RubyMine Air", "Human", "Custom"];
  const decisions = {
    planReview: ["plan", "stop"],
    buildReview: ["build", "plan", "stop"],
    finalReview: ["build", "plan", "stop"]
  };
  const preset = {
    plan: ["Define acceptance criteria and ask one unresolved business question at a time.", ["TASK_EXECUTION_STANDARD.md"]],
    planReview: ["Check the plan against the original request. Return a verdict with evidence.", ["REVIEW.md"]],
    build: ["Implement the approved plan within scope. Record repairs and leave task receipts to Workbench.", ["TASK_EXECUTION_STANDARD.md", "STANDARDS.md", "PERFORMANCE.md"]],
    checks: ["Run applicable checks and benchmarks. A failed check blocks a passing build audit.", []],
    buildReview: ["Inspect the current source and check receipts. Send confirmed code findings to the builder.", ["REVIEW.md"]],
    finalReview: ["Use a fresh review session. Verify all rubric criteria against the checked source.", ["REVIEW.md"]],
    verify: ["Confirm the checked and reviewed source fingerprints match. Record the result.", []]
  };

  function profile(mode, docs) {
    const fast = mode === "fast";
    return {
      name: fast ? "Fast build" : "Audited build",
      rules: "Keep changes within the agreed scope. Require current evidence before completion. Keep independent evaluation inputs outside the builder context.",
      sharedDocs: [],
      stages: Object.fromEntries(roles.map(({id, kind}) => [id, {
        enabled: !(fast && id === "finalReview"),
        provider: kind === "Gate" ? "Workbench" : kind === "Audit" ? "Muse" : "Codex",
        model: kind === "Agent" ? "gpt-6.2-astra" : "",
        effort: fast ? "medium" : "high",
        instructions: preset[id][0],
        docs: preset[id][1].filter(docId => docs.some(doc => doc.id === docId)),
        limit: fast ? 1 : 3,
        route: id === "planReview" ? "plan" : "build",
        requirementsRoute: "plan"
      }]))
    };
  }

  function initial(documents) {
    return {version: 1, active: "audited", documents, profiles: {
      audited: profile("audited", documents), fast: profile("fast", documents)
    }};
  }

  function validate(data) {
    const assert = (condition, message) => { if (!condition) throw new Error(message); };
    const string = (value, max) => typeof value === "string" && value.length <= max;
    assert(data?.version === 1 && ["audited", "fast"].includes(data.active), "Use a version 1 profile export.");
    assert(Array.isArray(data.documents) && data.documents.length <= 60, "The document library supports up to 60 files.");
    const ids = new Set();
    for (const doc of data.documents) {
      assert(doc && string(doc.id, 150) && doc.id && !ids.has(doc.id) && string(doc.name, 120)
        && string(doc.filename, 150) && string(doc.source, 80) && string(doc.content, 350000), "A document has invalid fields.");
      ids.add(doc.id);
    }
    function validDocs(list) {
      return Array.isArray(list) && new Set(list).size === list.length && list.every(id => ids.has(id));
    }
    for (const mode of ["audited", "fast"]) {
      const item = data.profiles?.[mode];
      assert(item && string(item.name, 80) && item.name.trim() && string(item.rules, 20000) && validDocs(item.sharedDocs), "A profile has invalid shared rules or documents.");
      for (const {id, kind} of roles) {
        const stage = item.stages?.[id];
        assert(stage && typeof stage.enabled === "boolean" && string(stage.instructions, 20000) && validDocs(stage.docs)
          && string(stage.model, 120) && efforts.includes(stage.effort), "A stage has invalid instructions or settings.");
        assert(kind === "Gate" ? stage.provider === "Workbench" : providers.includes(stage.provider), "A stage has an invalid provider.");
        assert(kind === "Audit" || stage.enabled, "Planning, building, and verification stages are required.");
        if (kind === "Audit") {
          assert(decisions[id].includes(stage.route) && Number.isInteger(stage.limit) && stage.limit >= 1 && stage.limit <= 20, "An audit has an invalid return route or limit.");
          assert(["plan", "stop"].includes(stage.requirementsRoute), "A requirements finding has an invalid return route.");
        }
      }
    }
    assert(JSON.stringify(data).length <= 1850000, "The profile exceeds local storage capacity. Remove a document and retry.");
    return data;
  }

  function simulate(item, scenario) {
    const counts = {};
    const findingCounts = {};
    let repairs = 0;
    let index = 0;
    let baseline = false;
    const rows = [];
    while (index < roles.length) {
      const {id, name} = roles[index];
      const stage = item.stages[id];
      if (!stage.enabled) {
        index++;
        continue;
      }
      if (id === "build" && !baseline) {
        rows.push("Run applicable baseline checks");
        baseline = true;
      }
      const budget = id === "verify" ? "finalReview" : id === "checks" ? "buildReview" : id;
      const count = counts[budget] ?? 0;
      if ((findingCounts[id] ?? 0) >= (scenario[id] ?? 0)) {
        rows.push(name + " · pass");
        index++;
        continue;
      }
      const route = id === "checks" || id === "verify" ? "build" : scenario.requirements ? stage.requirementsRoute : stage.route;
      if (route === "stop" || count >= item.stages[budget].limit || (route === "build" && repairs >= item.stages.buildReview.limit)) {
        rows.push(name + " · stop and report the unresolved finding");
        return rows;
      }
      counts[budget] = count + 1;
      findingCounts[id] = (findingCounts[id] ?? 0) + 1;
      if (route === "build") repairs++;
      rows.push(name + " · return to " + roles.find(role => role.id === route).name);
      index = roles.findIndex(role => role.id === route);
    }
    return rows;
  }

  function stagePrompt(item, id, docs) {
    const role = roles.find(role => role.id === id);
    const stage = item.stages[id];
    const text = ["# " + role.name, item.rules, stage.instructions];
    for (const docId of new Set([...item.sharedDocs, ...stage.docs])) {
      const doc = docs.find(entry => entry.id === docId);
      text.push("## " + doc.filename + "\n\n" + doc.content);
    }
    return text.filter(Boolean).join("\n\n");
  }

  function nativeSettings(item) {
    const builder = item.stages.build;
    const settings = {execution: {max_repair_rounds: item.stages.buildReview.limit}};
    if (builder.provider === "Codex" && builder.model.trim()) {
      settings.agent = {model: builder.model.trim(), effort: builder.effort};
    }
    return settings;
  }

  return {roles, audits, efforts, providers, decisions, initial, validate, simulate, stagePrompt, nativeSettings};
})();

if (typeof module !== "undefined") module.exports = WorkbenchProfile;
