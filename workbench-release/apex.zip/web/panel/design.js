"use strict";

let layoutWrite = Promise.resolve();
function layoutSetting(name, value) {
  if (!projectState?.project) return null;
  if (value !== undefined) {
    projectState.design_layout[name] = value;
    layoutWrite = layoutWrite.then(() => api("design/layout", {name, value})).catch(error => notify(error.message));
  }
  return projectState.design_layout[name];
}

function assetImage(id, label) {
  const img = element("img", "mockup");
  img.src = "api/design/asset?id=" + encodeURIComponent(id);
  img.alt = label;
  img.loading = "lazy";
  return img;
}

function roadmapStatus(slice,builds) {
  for(const build of [...builds].reverse()){
    const group=build.groups.find(g=>g.slices.includes(slice));
    if(!group || build.retired)continue;
    if(group.reviews.at(-1)?.sha===group.sha && group.sha)return "Approved";
    if(group.findings.some(f=>f.slices.includes(slice) && !f.repaired))return "Needs repair";
    if(build.status==="review" && group.sha)return "Ready for review";
    const attempt=build.attempts.filter(a=>a.slice===slice).at(-1);
    if(attempt)return attempt.outcome==="completed"?"Checks finished":attempt.outcome;
    return "Queued";
  }
  return "Planned";
}

function watchGroupReview(area,evidence,target,actions) {
  let signature;
  async function refresh() {
    if(!area.isConnected)return;
    try{
      const details=await api("design/group?build="+encodeURIComponent(target.build)+"&group="+target.group);
      if(!area.isConnected)return;
      const fingerprint=JSON.stringify(details);
      if(fingerprint!==signature){
        signature=fingerprint;evidence.replaceChildren();
        const labels={waiting:"Ready for review",reviewing:"Review in progress",approved:"Approved",
          "changes-requested":"Changes requested","branch-changed":"Branch changed","different-preview":"Review the exact commit"};
        evidence.append(element("strong","",details.message || labels[details.status] || "Connect Branch Review"));
        if(details.url){
          const link=element("a","button","Open Branch Review");
          link.href=details.url;link.target="_blank";link.rel="noopener";
          if(window.parent!==window && document.referrer && new URL(document.referrer).origin===new URL(link.href).origin){
            link.onclick=event=>{event.preventDefault();window.parent.postMessage({type:"workbench-review-run",runId:details.runId},new URL(link.href).origin);};
          }
          evidence.append(link);
        }
        for(const item of details.checklist || [])evidence.append(element("p","",item.title+" · "+item.status.replaceAll("-"," ")));
        for(const issue of details.findings || [])evidence.append(button(issue.actual,()=>actions.selectFinding(issue)));
        if(details.status==="approved"){
          evidence.append(button("Record approval",actions.approve));
          if(actions.canApply())await actions.approve();
        }
      }
    }catch(error){evidence.textContent=error.message;signature=null;}
    if(area.isConnected)setTimeout(refresh,4000);
  }
  queueMicrotask(refresh);
}

function designHistory() {
  const rows = element("div", "panel-body");
  const panel = element("section", "panel", heading("Slice attempts"), rows);
  let previous;
  async function refresh() {
    if (!panel.isConnected) return;
    if (document.hidden) { setTimeout(refresh, 2000); return; }
    try {
      const attempts = await api("design/history");
      const signature = JSON.stringify(attempts);
      if (previous !== signature) {
        const open = new Set([...rows.querySelectorAll("details[open]")].map(d => d.dataset.key));
        rows.replaceChildren();
        if (!attempts.length) rows.append(element("p", "copy", "No recorded slice attempts."));
        const counts = new Map();
        for (const a of attempts) {
          const key = a.build + a.slice;
          const count = (counts.get(key) || 0) + 1;
          counts.set(key, count);
          const title = element("summary", "", a.title + " · Attempt " + count + " · " +
            (a.step ? stageName(a.step) + " · " : "") + a.outcome);
          if (a.active) title.prepend(element("span", "runtime-spinner"));
          const row = element("details", "attempt", title, element("small", "", new Date(a.started).toLocaleString()));
          row.dataset.key = a.id;
          row.open = open.has(a.id);
          if (a.reason || a.error) row.append(element("p", "", [a.reason, a.error].filter(Boolean).join(" · ")));
          const list = element("ol", "timeline");
          for (const step of a.transitions) list.append(element("li", "", stageName(step.stage) + " · " + step.number + " · " + step.outcome,
            element("small", "", new Date(step.time * 1000).toLocaleTimeString()), step.reason));
          row.append(list);
          rows.prepend(row);
        }
        previous = signature;
      }
    } catch (error) { rows.textContent = error.message; previous = null; }
    if (panel.isConnected) setTimeout(refresh, 2000);
  }
  queueMicrotask(refresh);
  return panel;
}

function designPanel(initialState) {
  const panel = element("section", "design-stack");
  const tabs = element("div", "design-tabs");
  const body = element("div", "design-stack");
  const status = element("p", "design-status");
  const liveDecision = element("div");
  let decisionKey;
  status.setAttribute("role", "status");
  panel.append(tabs, status, liveDecision, body);
  const names = ["Plan", "Mockups", "Preview", "Build"];
  let tab = names.includes(layoutSetting("tab")) ? layoutSetting("tab") : "Plan";
  let state = initialState, editing, baseRevision, selectedAsset, busy = false;
  let messageText = "", revisionText = "";
  const box = (title, ...items) => element("section", "panel", heading(title), element("div", "panel-body design-stack", ...items));
  const input = (value, label, change) => {
    const node = element("input");
    node.value = value;
    node.setAttribute("aria-label", label);
    node.addEventListener("input", () => change(node.value));
    return node;
  };
  const redraw = () => { if (panel.isConnected) draw(); };
  async function change(action, payload, options = {}) {
    if (busy) return;
    const submittedDraft = JSON.stringify(editing);
    const submittedMessage = messageText;
    busy = true;
    panel.setAttribute("aria-busy", "true");
    status.textContent = options.wait || "Saving…";
    try {
      const next = await api("design/" + action, {revision: state.revision, ...payload});
      state = {...next, checklist: state.checklist};
      if (options.reset && JSON.stringify(editing) === submittedDraft) editing = null;
      if (options.clear && messageText === submittedMessage) messageText = "";
      if (action === "image" && payload.asset && revisionText === payload.message) revisionText = "";
      status.textContent = options.done || "Saved.";
      redraw();
    } catch (error) {
      status.textContent = error.message;
      // Keep local edits and the submitted base revision until the user resolves the conflict.
      try { state = await api("design"); redraw(); } catch {}
    } finally { busy = false; panel.removeAttribute("aria-busy"); }
  }
  function editor() {
    if (!editing) {
      editing = {plan: state.plan, roadmap: structuredClone(state.roadmap)};
      baseRevision = state.revision;
    }
    const draft = element("textarea", "plan-text");
    draft.value = editing.plan;
    draft.addEventListener("input", () => { editing.plan = draft.value; });
    const map = element("div", "roadmap");
    for (const milestone of editing.roadmap) {
      const headingInput = input(milestone.title, "Milestone title", v => { milestone.title = v; });
      const section = element("div", "milestone", field("Milestone", headingInput));
      for (const slice of milestone.slices) {
        section.append(field("Slice", input(slice.title, "Slice title", v => { slice.title = v; })),
          element("small","stage-meta",roadmapStatus(slice.id,state.builds)));
        const asset = state.attachments[slice.id];
        if (asset) section.append(assetImage(asset, slice.title + " selected mockup"));
      }
      section.append(button("Add slice", () => { milestone.slices.push({id: crypto.randomUUID(), title: ""}); draw(); }));
      map.append(section);
    }
    map.append(button("Add milestone", () => {
      editing.roadmap.push({id: crypto.randomUUID(), title: "", slices: []}); draw();
    }));
    const actions = element("div", "actions", button("Save draft", () =>
      change("draft", {...editing, revision: baseRevision}, {reset: true}), "button primary"));
    const clean = editing.plan === state.plan && JSON.stringify(editing.roadmap) === JSON.stringify(state.roadmap);
    const approve = button("Approve revision " + state.revision, () => change("approve", {}));
    approve.disabled = !clean || !state.plan || state.approved === state.revision || Boolean(state.question);
    actions.append(approve);
    const current=state.builds.at(-1);
    const start=button(current && current.status!=="closed"?"View build":"Start build",()=>{
      tab="Build";layoutSetting("tab",tab);draw();
    });
    start.disabled=(!current || current.status==="closed") && (!clean || state.approved!==state.revision);
    actions.append(start);
    const result = box("Draft plan", element("small", "", state.approved === state.revision
      ? "Approved revision " + state.revision : "Draft revision " + state.revision), field("Plan text", draft), map, actions);
    if (baseRevision !== state.revision) {
      const conflict = element("details", "", element("summary", "", "Compare saved revision " + state.revision),
        element("pre", "", state.plan), element("pre", "", JSON.stringify(state.roadmap, null, 2)));
      result.append(conflict, button("Keep my proposal for this revision", () => { baseRevision = state.revision; draw(); }),
        button("Load saved draft", () => { editing = null; draw(); }));
    }
    return result;
  }
  function chat() {
    const log = element("ol", "conversation");
    for (const m of state.messages) {
      if (m.decision && m.decision === state.question?.id) continue;
      const row = element("li", m.author, element("small", "", m.author === "user" ? "You" : "Project agent"), element("p", "", m.text));
      if (m.suggestions) row.append(element("details", "", element("summary", "", "Suggested answers"),
        element("ul", "", ...m.suggestions.map(s => element("li", "", s)))));
      if (m.asset) row.append(assetImage(m.asset, "Generated mockup"));
      log.append(row);
    }
    const text = element("textarea");
    text.value = messageText;
    text.addEventListener("input", () => { messageText = text.value; });
    const actions = element("div", "actions");
    const send = button("Send to planner", () => {
      const clean = !editing || (editing.plan === state.plan && JSON.stringify(editing.roadmap) === JSON.stringify(state.roadmap));
      change("chat", {message: text.value}, {wait: "Planner working…", reset: clean, clear: true});
    }, "button primary");
    send.disabled = Boolean(state.question);
    actions.append(send, button("Generate mockup", () => change("image", {message: text.value},
      {wait: "Generating mockup…", clear: true})));
    const items = [log];
    if (state.question) {
      const q = state.question;
      items.push(q.error ? element("div", "", element("p", "evidence-warning", q.error),
        button("Retry suggestions", () => change("retry", {}))) : planningAnswer(q.question, q.suggestions,
        message => change("answer", {id: q.id, message}, {reset: !editing || (editing.plan === state.plan &&
          JSON.stringify(editing.roadmap) === JSON.stringify(state.roadmap))})));
    }
    return box("Project conversation", ...items, field("Message", text), actions);
  }
  function mockups() {
    const assets = state.assets;
    if (!assets.length) return box("Mockup versions", element("p", "copy", "Use Generate mockup in the project conversation."));
    if (!assets.some(a => a.id === selectedAsset)) selectedAsset = assets.at(-1).id;
    const choices = select(selectedAsset, assets.map((a, i) => [a.id, "Version " + (i + 1) + " · " + a.prompt]),
      id => { selectedAsset = id; draw(); return true; });
    const revise = element("textarea");
    revise.value = revisionText;
    revise.addEventListener("input", () => { revisionText = revise.value; });
    const slices = state.roadmap.flatMap(m => m.slices.map(s => [s.id, m.title + " / " + s.title]));
    const target = select(slices[0]?.[0] || "", slices, () => true);
    return box("Mockup versions", field("Version", choices), assetImage(selectedAsset, choices.selectedOptions[0].textContent),
      field("Revision request", revise), button("Generate revision", () => change("image",
        {asset: selectedAsset, message: revise.value}, {wait: "Revising mockup…"})), field("Roadmap slice", target),
      button("Attach this version", () => change("attach", {asset: selectedAsset, slice: target.value})));
  }
  function preview() {
    const mount = element("div", "preview-frame");
    const address=input(state.preview || "", "App address",()=>{});
    address.placeholder="http://localhost:3000";
    const save=button("Save app address",()=>change("settings",{preview:address.value.trim(),branch:state.branch}));
    api("design/preview").then(result => {
      if (!mount.isConnected) return;
      if (!result.url) { mount.textContent = result.status; return; }
      const frame = element("iframe");
      frame.title = "Project app preview";
      const separate=new URL(result.url).origin!==location.origin;
      frame.setAttribute("sandbox", "allow-forms allow-scripts"+(separate?" allow-same-origin":""));
      frame.src = result.url;
      const open=element("a","button","Open app in a tab");
      open.href=result.url;open.target="_blank";open.rel="noopener";
      mount.append(open,frame);
    }).catch(error => { mount.textContent = error.message; });
    return box("Project app preview", field("App address",address),save,mount);
  }
  function review(build, group, index) {
    const target = {build: build.id, group: index, sha: group.sha, slices: group.slices};
    const members = group.slices.map(id => [id, build.roadmap.flatMap(m => m.slices).find(s => s.id === id).title]);
    const area = box("Branch Review", element("code", "run-id", group.sha), element("p", "", members.map(s => s[1]).join(" · ")));
    const diff = element("pre", "commit-diff");
    const inspect = element("details", "", element("summary", "", "Inspect commit diff"), diff);
    inspect.addEventListener("toggle", async () => {
      if (!inspect.open || diff.textContent) return;
      try {
        const evidence = await api("design/evidence?build=" + build.id + "&group=" + index);
        diff.textContent = evidence.sha === group.sha ? evidence.diff || "No file changes." : "The review target changed.";
      } catch (error) { diff.textContent = error.message; }
    });
    area.append(inspect);
    const approved = group.reviews.at(-1)?.sha === group.sha;
    for(const [id,title] of members){
      const asset=build.attachments[id];
      if(asset)area.append(element("details","",element("summary","","Selected mockup · "+title),assetImage(asset,title)));
    }
    if (approved) {
      const decision = group.reviews.at(-1);
      area.append(element("p", "", "Approved by " + decision.author + " · " + decision.branch));
      const destination = element("small", "", "Checking GitHub destination…");
      const publish = button("Push to GitHub", () => change("push", {...target, expectedTarget:publish.dataset.target},
        {wait:"Pushing approved commit…", done:"Push completed."}));
      publish.disabled = true;
      area.append(destination, publish);
      api("design/group?"+new URLSearchParams({build:build.id,group:index})).then(review=>{
        publish.dataset.target=review.pushTarget || "";
        publish.disabled=build.retired || !review.pushTarget || review.status!=="approved";
        destination.textContent=review.pushTarget ? review.pushTarget+" / "+decision.branch : "Configure a GitHub remote to push.";
      }).catch(error=>{destination.textContent=error.message;});
      if (group.pushed) area.append(element("small", "", "Pushed " + group.pushed.sha));
      if (build.status !== "closed") return area;
    }
    const evidence=element("div","design-stack");
    area.append(evidence);
    const affected = new Set();
    const finding = element("textarea");
    const findings = element("details", "", element("summary", "", "Record a finding"), field("Finding", finding));
    for (const [id, title] of members) findings.append(checkbox(title, false, on => {
      if (on) affected.add(id); else affected.delete(id); return true;
    }));
    findings.append(button("Reopen affected slices", () => change("finding", {...target, affected: [...affected], text: finding.value})));
    area.append(findings);
    if (!approved) watchGroupReview(area,evidence,target,{
      approve:()=>change("review",target,{done:"Branch Review approval recorded."}),
      canApply:()=>!busy && !document.hidden,
      selectFinding:issue=>{finding.value=issue.actual+"\nExpected: "+issue.expected;findings.open=true;finding.focus();}
    });
    return area;
  }
  function buildPanel() {
    const branch = input(state.branch, "Project branch", () => {});
    const host=input(state.reviewHost || (projectState.host_links || []).find(h=>h.name.toLowerCase()==="branch review")?.url || "",
      "Branch Review address",()=>{});
    const result = element("div", "design-stack", box("Project branch", field("Git branch", branch),
      field("Branch Review address",host),button("Save build settings", () => change("settings",
        {branch:branch.value,preview:state.preview,reviewHost:host.value.trim()}))));
    const build = state.builds.at(-1);
    if (build) {
      const info = box("Build progress", element("p", "", "Revision " + build.revision + " · " + build.status));
      for (const [i, group] of build.groups.entries()) {
        if (group.sha && (group.reviews.at(-1)?.sha === group.sha || (build.status === "review" && i === build.index))) {
          info.append(review(build, group, i));
        }
        for (const finding of group.findings) info.append(element("p", "", "Finding · " + finding.text));
      }
      if (["ready", "failed"].includes(build.status)) info.append(button("Continue build", () => change("continue", {build: build.id})));
      if (build.status === "working") info.append(button("Reconnect run", () => change("reconnect", {build: build.id})));
      if (build.error) info.append(element("p", "evidence-warning", build.error));
      if (!["working", "closed", "retired"].includes(build.status)) info.append(button("Retire build", () => change("retire", {build: build.id})));
      result.append(info);
    }
    if (!build || ["closed", "retired"].includes(build.status)) {
      const targets = [["plan", "Whole approved plan"]];
      for (const m of state.roadmap) targets.push(["milestone/" + m.id, "Milestone · " + m.title],
        ...m.slices.map(s => ["slice/" + s.id, "Slice · " + s.title]));
      const scope = select("plan", targets, () => true);
      const frequency = select("slice", [["slice", "Each slice"], ["milestone", "Each milestone"], ["plan", "End of selection"]], () => true);
      const steps = element("details", "steps", element("summary", "", "Build steps and repair routes"));
      for (const role of WorkbenchProfile.roles) {
        const stage = active().stages[role.id];
        if (!stage.enabled) continue;
        const row = element("details", "", element("summary", "", role.name + " · " + stage.provider),
          element("p", "", stage.instructions));
        if (role.kind === "Audit") row.append(element("p", "", "Finding → " + routeLabels[stage.route] +
          ". Requirements finding → " + routeLabels[role.id === "planReview" ? stage.route : stage.requirementsRoute] +
          ". Return limit " + stage.limit + "."));
        steps.append(row);
      }
      steps.append(element("p", "", "Each slice runs baseline checks before implementation. Workbench commits verified changes locally. Human Branch Review closes each group."));
      const agreement = element("details", "", element("summary", "", "Build agreement"));
      const decisions = {};
      for (const q of projectState.questions.filter(q => q.required)) {
        const choice = select("", [["", "Select an answer"], ...q.options.map(v => [v, v])],
          v => { decisions[q.id] = v; return true; });
        agreement.append(field(q.text, choice));
      }
      const launch = button("Start build", () => {
        const [kind, key] = scope.value.split("/");
        if (projectState.questions.some(q => q.required && !decisions[q.id])) {
          agreement.open = true; status.textContent = "Complete the build agreement."; return;
        }
        if (byId("apply-profile").textContent === "Apply changes") { status.textContent = "Apply your profile changes first."; return; }
        change("build", {scope: kind, key, frequency: frequency.value, stages: active().stages, decisions}, {wait: "Starting build…"});
      }, "button primary");
      launch.disabled = state.approved !== state.revision;
      result.append(box("Start a build", field("Build scope", scope), field("Review frequency", frequency), steps, agreement, launch));
    }
    result.append(progressPanel(),designHistory());
    return result;
  }
  function draw() {
    tabs.replaceChildren(...names.map(name => {
      const node = button(name, () => { tab = name; layoutSetting("tab", tab); draw(); });
      node.setAttribute("aria-pressed", String(name === tab));
      return node;
    }));
    const layout = layoutSetting("panes") || "beside";
    const openBuild=()=>{tab="Build";layoutSetting("tab",tab);draw();};
    body.replaceChildren(tab === "Plan" ? element("div","design-stack",
      element("div", layout === "beside" ? "design-columns" : "design-stack", chat(), editor()),progressPanel(openBuild)) :
      tab === "Mockups" ? mockups() : tab === "Preview" ? preview() : buildPanel());
    if (tab === "Plan") tabs.append(button(layout === "beside" ? "Stack panes" : "Show panes side by side", () => {
      layoutSetting("panes", layout === "beside" ? "stack" : "beside"); draw();
    }));
    liveDecision.hidden = tab !== "Plan" || !liveDecision.childElementCount;
  }
  function showLiveDecision(task) {
    const key = JSON.stringify([task?.id, task?.question_id, task?.suggestions, task?.question_error]);
    if (key !== decisionKey) {
      liveDecision.replaceChildren();
      const answer = async message => {
        try {
          await api("chat", task.question ? {message, task: task.id, question: task.question, question_id: task.question_id} : {message});
          liveDecision.replaceChildren();
        } catch (error) { status.textContent = error.message; }
      };
      if (task?.question) liveDecision.append(box("Build decision", planningAnswer(task.question, task.suggestions, answer)));
      if (task?.question_error) liveDecision.append(box("Build decision", element("p", "", task.question_error),
        button("Retry suggestions", () => answer("/run"))));
      decisionKey = key;
    }
    liveDecision.hidden = tab !== "Plan" || !liveDecision.childElementCount;
  }
  async function refresh() {
    if (!panel.isConnected) return;
    if (document.hidden && state) { setTimeout(refresh, 1800); return; }
    try {
      if (!state || (tab === "Build" && !busy && state.builds.at(-1)?.status !== "closed" && state.builds.length)) {
        const next = await api("design");
        if (!busy && JSON.stringify(next) !== JSON.stringify(state)) { state = next; redraw(); }
      }
      if (tab === "Plan" && projectState.active_task?.status === "active") {
        const live = await api("live");
        showLiveDecision(live.active_task?.status === "active" ? live.active_task : null);
      }
    } catch (error) { status.textContent = error.message; }
    if (panel.isConnected) setTimeout(refresh, 1800);
  }
  if (state) {
    draw();
    const task = projectState.active_task;
    showLiveDecision(task?.status === "active" ? task : null);
    setTimeout(refresh, 1800);
  } else queueMicrotask(refresh);
  return panel;
}

