async function mount(root, hostOptions = {}) {
  const embedded = root !== document;
  const base = new URL(hostOptions.base || new URL("./", document.baseURI), document.baseURI);
  if (base.origin !== location.origin) throw Error("Use a Workbench panel on this origin.");
  if (!base.pathname.endsWith("/")) base.pathname += "/";
  base.search = base.hash = "";
  const panelUrl = path => new URL(path, base).href;
  const controller = new AbortController();
  const signal = hostOptions.signal ? AbortSignal.any([controller.signal, hostOptions.signal]) : controller.signal;
  const timers = new Set();
  let container;
  let panelRoot = document;
  let styles = [];

  function setTimeout(callback, delay) {
    if (signal.aborted) return;
    const timer = window.setTimeout(() => {
      timers.delete(timer);
      callback();
    }, delay);
    timers.add(timer);
    return timer;
  }

  function clearTimeout(timer) {
    timers.delete(timer);
    window.clearTimeout(timer);
  }

  signal.addEventListener("abort", () => {
    for (const timer of timers) window.clearTimeout(timer);
    timers.clear();
    container?.remove();
  }, {once: true});
  const dispose = () => controller.abort();

  try {
    signal.throwIfAborted();
    if (embedded) {
      const response = await fetch(panelUrl("index.html"), {signal});
      if (!response.ok) throw Error("Cannot load the Workbench panel.");
      const markup = new DOMParser().parseFromString(await response.text(), "text/html");
      if (!markup.getElementById("content")) throw Error("The Workbench panel markup is missing.");
      signal.throwIfAborted();
      container = document.createElement("div");
      container.hidden = true;
      panelRoot = container.attachShadow({mode: "open"});
      const surface = document.createElement("div");
      surface.className = "workbench-surface";
      surface.append(...markup.body.children);
      styles = [...markup.head.querySelectorAll('link[rel="stylesheet"]')].map(source => {
        const link = document.createElement("link");
        link.rel = "stylesheet";
        link.href = panelUrl(source.getAttribute("href"));
        const ready = new Promise((resolve, reject) => {
          link.onload = resolve;
          link.onerror = () => reject(Error("Cannot load the Workbench panel styles."));
          signal.addEventListener("abort", () => reject(signal.reason), {once: true});
        });
        panelRoot.append(link);
        return ready;
      });
      panelRoot.append(surface);
      root.append(container);
    }
    signal.throwIfAborted();
    const [panel] = await Promise.all([createWorkbench(panelRoot, {
      dispose, embedded, hostOptions, panelUrl, signal, setTimeout, clearTimeout
    }), ...styles]);
    signal.throwIfAborted();
    if (container) container.hidden = false;
    return panel;
  } catch (error) {
    dispose();
    throw error;
  }
}
