"use strict";
const byId=id=>document.getElementById(id);
const picker=byId("project"), frame=byId("frame"), dialog=byId("new-project");
let token="", projects=[], current, details, receipt, sequence=0, view="workbench";
function message(text) {byId("status").textContent=text;byId("status").hidden=!text;}
async function call(name,args={}) {
  const response=await fetch("projects/api",{method:"POST",headers:{"Content-Type":"application/json","X-CSRF-Token":token},
    body:JSON.stringify({name,arguments:args})});
  const value=await response.json();
  if(!response.ok) throw Error(value.error || "The workspace request failed.");
  return value;
}
function fillList(node,values) {
  node.replaceChildren(...values.map(item=>{const row=document.createElement("li");row.textContent=item;return row;}));
}
function definitions(node,values) {
  node.replaceChildren();
  for(const [label,value] of values) {
    const dt=document.createElement("dt"),dd=document.createElement("dd");
    dt.textContent=label;dd.textContent=value;node.append(dt,dd);
  }
}
function render() {
  byId("empty").hidden=Boolean(current);
  const showEnvironment=current && (view==="environment" || !details?.installed);
  byId("settings").hidden=!showEnvironment;frame.hidden=!current || showEnvironment;
  byId("panel").setAttribute("aria-pressed",String(Boolean(current && !showEnvironment)));
  byId("environment").setAttribute("aria-pressed",String(Boolean(showEnvironment)));
  for(const id of ["panel","environment"]) byId(id).disabled=!current;
  if(!current || !details) return;
  byId("folder").textContent=current.path;
  definitions(byId("details"),[["Runtime",details.installed?"Installed":"Needs setup"],["Engine",details.engine || "Choose during setup"],
    ["Profile",details.profileApplied?"Applied":"Draft"],["Work files",details.prepared?"Prepared":"Not prepared"]]);
  const checks=details.checks.length?details.checks:details.suggestedChecks.map(row=>row.name+" (suggested)");
  fillList(byId("checks"),checks.length?checks:["No checks configured"]);
  definitions(byId("programs"),Object.entries(details.programs).map(([name,available])=>[name,available?"Available":"Missing"]));
  const destination=new URL("p/"+current.id+"/",location.href);
  if(!frame.hidden && frame.src!==destination.href) frame.src=destination.href;
}
async function choose(id,preferred,selection) {
  const step=++sequence;
  current=projects.find(row=>row.id===id);details=null;receipt=null;
  byId("inventory").hidden=true;frame.hidden=true;byId("settings").hidden=true;message("");
  if(!current) {render();return;}
  picker.value=id;
  try {
    if(selection?.error) throw Error(selection.error);
    const name=preferred==="environment"?"inspect_environment":"open_project";
    const info=selection?.environment || await call(name,{projectId:id});
    if(step!==sequence) return;
    details=info;view=preferred || (details.installed?"workbench":"environment");
    const hash=new URLSearchParams({project:id,view});
    history.replaceState(null,"","#"+hash);
    render();
  }catch(error){if(step===sequence)message(error.message);}
}
function displayProjects() {
  picker.replaceChildren(...projects.map(row=>{
    const duplicate=projects.some(other=>other.id!==row.id && other.name===row.name);
    const option=new Option(duplicate?row.path:row.name,row.id);option.title=row.path;return option;
  }));
  picker.disabled=!projects.length;
}
async function run(button,operation) {
  button.disabled=true;
  try {await operation();}catch(error){message(error.message);}finally{button.disabled=false;}
}
function add() {byId("add-error").textContent="";byId("path").value="";dialog.showModal();byId("path").focus();}
byId("add").onclick=add;byId("empty-add").onclick=add;byId("cancel").onclick=()=>dialog.close();
byId("form").onsubmit=async event=>{
  event.preventDefault();const submit=event.submitter;submit.disabled=true;
  try {
    const item=await call("add_project",{path:byId("path").value.trim()});
    projects=(await call("list_projects")).projects;displayProjects();dialog.close();await choose(item.id);
  }catch(error){byId("add-error").textContent=error.message;}finally{submit.disabled=false;}
};
picker.onchange=()=>choose(picker.value);
for(const [id,target] of [["panel","workbench"],["environment","environment"]]) byId(id).onclick=()=>choose(picker.value,target);
byId("prepare").onclick=()=>run(byId("prepare"),async()=>{
  const selected=current.id;
  await call("prepare_environment",{projectId:selected});
  if(current.id!==selected)return;
  frame.removeAttribute("src");
  await choose(selected,"environment");message("Environment prepared. Open Workbench to design or run a task.");
});
byId("preview").onclick=()=>run(byId("preview"),async()=>{
  const id=current.id,result=await call("preview_cleanup",{projectId:id});if(current.id!==id)return;
  receipt=result;byId("inventory").hidden=false;byId("total").textContent=result.entries.length+" entries · "+result.bytes+" bytes";
  fillList(byId("files"),result.entries.map(entry=>entry.path));byId("clean").disabled=!result.entries.length;
});
byId("clean").onclick=()=>run(byId("clean"),async()=>{
  if(!receipt || receipt.projectId!==current.id) throw Error("Preview cleanup for the selected project.");
  const id=current.id, result=await call("clean_environment",{projectId:id,previewId:receipt.previewId});if(current.id!==id)return;
  receipt=null;byId("inventory").hidden=true;message("Removed "+result.removed+" managed entries.");
});
byId("endpoint").value=new URL("projects/mcp",location.href).href;
byId("copy").onclick=()=>run(byId("copy"),async()=>{await navigator.clipboard.writeText(byId("endpoint").value);message("Workspace MCP endpoint copied.");});
(async()=>{
  const params=new URLSearchParams(location.hash.slice(1));
  const response=await fetch("projects/bootstrap?"+params,{cache:"no-store"});const state=await response.json();
  if(!response.ok) throw Error(state.error || "Could not load projects.");
  token=state.token;projects=state.projects;displayProjects();
  await choose(state.selection?.id,params.get("view"),state.selection);
})().catch(error=>message(error.message));
