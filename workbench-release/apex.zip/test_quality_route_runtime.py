import os
from pathlib import Path
import shutil
import subprocess
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from quality_route_runtime import discover_rails_runtime


RUBY = shutil.which("ruby")


@unittest.skipUnless(RUBY, "Ruby is required for the Rails runner fixture")
class RailsRuntimeRoutes(unittest.TestCase):
    def setUp(self):
        temporary = TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.project = Path(temporary.name).resolve()

    def app(self, directory, runner):
        root = self.project / directory
        (root / "bin").mkdir(parents=True)
        (root / "config").mkdir()
        (root / "bin/rails").write_text(runner, encoding="utf-8")
        (root / "config/application.rb").touch()
        return root

    def test_real_rails_resources_namespaces_and_verbs(self):
        available = subprocess.run([RUBY, "-e", "exit Gem::Specification.find_all_by_name('actionpack').empty? ? 1 : 0"],
                                   capture_output=True, timeout=20)
        if available.returncode:
            self.skipTest("Action Pack is required for the realized route fixture")
        self.app("services/api", '''require "active_support"
require "active_support/core_ext/string/inflections"
require "action_dispatch"
abort "Unexpected environment" unless ENV["RAILS_ENV"] == "development" && !ENV.key?("BUNDLE_GEMFILE")
routes = ActionDispatch::Routing::RouteSet.new
routes.draw do
  namespace :api do
    resources :notes, only: [:index, :show, :create, :update]
    match "ready", to: "notes#health", via: [:get, :post]
  end
  post "/never-dispatch", to: ->(_) { raise "Route dispatch was unexpected" }
end
application = Struct.new(:routes).new(routes)
module Rails; end
Rails.define_singleton_method(:application) { application }
eval(ARGV.fetch(-1))
''')
        prior = dict(RAILS_ENV="production", BUNDLE_GEMFILE=str(self.project / "outside-gemfile"))
        with patch.dict(os.environ, prior):
            result = discover_rails_runtime(self.project)
        self.assertTrue(result["verified"], result["warnings"])
        routes = result["routes"]
        self.assertTrue(all(row["app_root"] == "services/api" for row in routes))
        self.assertIn(dict(method="GET", path="/api/notes/:id(.:format)", controller="api/notes",
                           action="show", name="api_note", app_root="services/api"), routes)
        self.assertEqual({row["method"] for row in routes if row["action"] == "update"}, {"PATCH", "PUT"})
        self.assertEqual({row["method"] for row in routes if row["action"] == "health"}, {"GET", "POST"})
        self.assertTrue(any(row["path"].startswith("/never-dispatch") and row["method"] == "POST" for row in routes))

    def test_missing_local_runtime_and_boot_dependencies_return_actionable_fallback(self):
        root = self.app(".", 'abort "Bundler::GemNotFound DO-NOT-EXPOSE"\n')
        result = discover_rails_runtime(self.project)
        self.assertFalse(result["verified"])
        self.assertEqual(result["routes"], [])
        self.assertIn("local dependencies", result["warnings"][0])
        self.assertNotIn("DO-NOT-EXPOSE", result["warnings"][0])
        (root / "bin/rails").write_text('abort "ActiveRecord::ConnectionNotEstablished PRIVATE"\n', encoding="utf-8")
        self.assertIn("development database", discover_rails_runtime(self.project)["warnings"][0])
        with patch("quality_route_runtime.shutil.which", return_value=None):
            self.assertIn("Ruby was not found", discover_rails_runtime(self.project)["warnings"][0])

    def test_ambiguous_apps_and_paths_outside_the_project_do_not_run(self):
        self.app("api", 'File.write("ran", "yes")\n')
        self.app("other", 'File.write("ran", "yes")\n')
        self.assertIn("multiple Rails apps", discover_rails_runtime(self.project)["warnings"][0])
        self.assertIn("in this project", discover_rails_runtime(self.project, app="..")["warnings"][0])
        self.assertFalse(list(self.project.glob("*/ran")))

    def test_refresh_limits_time_and_output(self):
        root = self.app(".", 'sleep 10\n')
        with patch("quality_route_runtime.TIMEOUT_SECONDS", 0.3):
            self.assertIn("timed out", discover_rails_runtime(self.project)["warnings"][0])
        (root / "bin/rails").write_text('STDOUT.write("x" * 65536); STDOUT.flush\n', encoding="utf-8")
        with patch("quality_route_runtime.MAX_OUTPUT", 2048):
            self.assertIn("output limit", discover_rails_runtime(self.project)["warnings"][0])
