"use strict";

const WorkbenchProfile = require("../web/panel/profile");
const documents = require("../web/panel/guidelines");
const catalog = require("../web/panel/models");

function executable(data) {
  WorkbenchProfile.validate(data);
  const keys = ["version", "active", "profiles", "documents", "permittedTools", "checks", "benchmark"];
  if (Object.keys(data).some(key => !keys.includes(key)) || Object.keys(data.profiles).length !== 2) {
    throw Error("Unknown profile fields.");
  }
  for (const [mode, profile] of Object.entries(data.profiles)) {
    for (const {id, kind} of WorkbenchProfile.roles) {
      const stage = profile.stages[id];
      if (!stage.enabled && !(mode === "fast" && id === "finalReview")) {
        throw Error(mode + " requires " + id + ".");
      }
      if (kind === "Gate" || !stage.enabled) continue;
      if (!Object.hasOwn(catalog, stage.provider) || !["Muse", "Codex"].includes(stage.provider) ||
          (stage.provider === "Muse" && id === "build")) {
        throw Error("Unsupported provider for " + id + ": " + stage.provider);
      }
      if (stage.model && !catalog[stage.provider].models.includes(stage.model)) {
        throw Error("Unsupported model for " + stage.provider + ": " + stage.model);
      }
    }
  }
  const names = data.permittedTools ?? [];
  if (!Array.isArray(names) || names.length > 32 || new Set(names).size !== names.length ||
      names.some(name => typeof name !== "string" || !/^app_[a-z][a-z0-9_]{0,63}$/.test(name))) {
    throw Error("Use unique app_ tool names.");
  }
  return {...data, permittedTools: names};
}

if (require.main === module) {
  try {
    const data = process.argv[2] === "default" ? WorkbenchProfile.initial(documents) :
      JSON.parse(require("node:fs").readFileSync(0, "utf8"));
    process.stdout.write(JSON.stringify(executable(data)));
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}
