"use strict";

const WorkbenchProfile = require("../web/panel/profile");
const documents = require("../web/panel/guidelines");
const catalog = require("../web/panel/models");

if (require.main === module) {
  try {
    const mode = process.argv[2];
    const data = mode === "default" ? WorkbenchProfile.initial(documents) :
      JSON.parse(require("node:fs").readFileSync(0, "utf8"));
    const profile = mode === "resolve" ? WorkbenchProfile.resolve(data.profile, data.settings, documents, catalog) :
      WorkbenchProfile.executable(data, catalog);
    process.stdout.write(JSON.stringify(profile));
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}
