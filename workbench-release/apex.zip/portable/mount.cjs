"use strict";

const http = require("node:http");
const {spawn} = require("node:child_process");
const {createInterface} = require("node:readline");
const path = require("node:path");

const prefix = "/__workbench/";

// Mount on a loopback host. The child owns exactly one project for its lifetime.
async function mountWorkbench(project, {python = process.env.HARNESS_PYTHON || "python", appTools, workDirectories} = {}) {
  const root = path.resolve(project);
  const args = [path.join(root, ".harness/server.py"), "--project", root, "--port", "0", "--bound"];
  if (appTools) args.push("--app-tools", path.resolve(root, appTools));
  const env = {...process.env};
  if (workDirectories) {
    const fs = require("node:fs/promises");
    for (const name of ["scratch", "tmp"]) {
      const expected = path.join(root, ".harness", "workspace-env", name);
      if (workDirectories[name] !== expected || await fs.realpath(expected) !== expected) {
        throw Error("The work directory does not belong to this project.");
      }
    }
    Object.assign(env, {TMPDIR: workDirectories.tmp, TMP: workDirectories.tmp, TEMP: workDirectories.tmp,
      APEX_WORKSPACE_SCRATCH: workDirectories.scratch});
  }
  const child = spawn(python, args, {cwd: root, env, windowsHide: true, stdio: ["ignore", "pipe", "inherit"]});
  const lines = createInterface({input: child.stdout});
  const port = await new Promise((resolve, reject) => {
    child.once("error", reject);
    child.once("exit", code => reject(Error("Workbench exited: " + code)));
    lines.on("line", line => {
      const match = /^Apex Workbench: http:\/\/127\.0\.0\.1:(\d+)$/.exec(line);
      if (match) resolve(Number(match[1]));
    });
  });
  const authority = "127.0.0.1:" + port;
  function handle(req, res) {
    if (!req.url.startsWith(prefix)) return false;
    const hosts = ["localhost:", "127.0.0.1:"].map(host => host + req.socket.localPort);
    if (!hosts.includes(req.headers.host) || (req.headers.origin && req.headers.origin !== "http://" + req.headers.host)) {
      res.writeHead(403).end(); return true;
    }
    const headers = {host: authority};
    for (const key of ["content-type", "content-length", "accept", "mcp-protocol-version", "x-csrf-token"]) {
      if (req.headers[key]) headers[key] = req.headers[key];
    }
    if (req.headers.origin) headers.origin = "http://" + authority;
    const upstream = http.request({hostname: "127.0.0.1", port, path: req.url, method: req.method, headers}, reply => {
      res.writeHead(reply.statusCode, reply.headers);
      reply.pipe(res);
    });
    upstream.on("error", () => { if (!res.headersSent) res.writeHead(502); res.end(); });
    res.on("close", () => upstream.destroy());
    req.pipe(upstream);
    return true;
  }
  return {handle, close: () => child.kill()};
}

module.exports = {mountWorkbench};
if (require.main === module) {
  const [project = ".", port = "8794", appTools] = process.argv.slice(2);
  mountWorkbench(project, {appTools}).then(panel => {
    const server = http.createServer((req, res) => {
      if (!panel.handle(req, res)) res.writeHead(404).end();
    });
    server.on("close", panel.close);
    process.once("exit", panel.close);
    process.on("SIGINT", () => server.close());
    process.on("SIGTERM", () => server.close());
    server.listen(Number(port), "127.0.0.1", () =>
      console.log("Workbench panel: http://127.0.0.1:" + server.address().port + prefix));
  }).catch(error => {console.error(error.message); process.exitCode = 1;});
}
