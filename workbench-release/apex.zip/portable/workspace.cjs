"use strict";

const {spawn} = require("node:child_process");
const {randomBytes,timingSafeEqual} = require("node:crypto");
const fs = require("node:fs/promises");
const http = require("node:http");
const os = require("node:os");
const path = require("node:path");
const {createInterface} = require("node:readline");
const {mountWorkbench} = require("./mount.cjs");
const base = "/__workbench/";
const versions = ["2025-11-25","2025-06-18","2025-03-26"];
const registryReads = new Set(["catalog","picker_state","list_projects","select_project","inspect_environment"]);

function environmentProcess(registry,command,stderr="pipe") {
  return spawn(process.env.HARNESS_PYTHON || "python",
    [path.join(__dirname,"environment.py"),registry,command],{windowsHide:true,stdio:["pipe","pipe",stderr]});
}

function runEnvironment(registry,command,args) {
  return new Promise((resolve,reject) => {
    const child = environmentProcess(registry,command);
    let output="", error="";
    child.stdout.setEncoding("utf8");child.stderr.setEncoding("utf8");
    child.stdout.on("data",chunk=>output+=chunk);
    child.stderr.on("data",chunk=>error+=chunk);
    child.on("error",reject);
    child.once("close",code=>{
      if(code!==0) return reject(Error(error.trim() || "Workspace command failed."));
      try {resolve(JSON.parse(output));} catch {reject(Error("Workbench returned an unreadable response."));}
    });
    child.stdin.on("error",()=>{});
    child.stdin.end(JSON.stringify(args));
  });
}

function startRegistryReader(registry) {
  const child=environmentProcess(registry,"read_worker","ignore");
  const lines=createInterface({input:child.stdout,crlfDelay:Infinity});
  const pending=new Map();
  let active=true, sequence=0;

  function stop(error) {
    if(!active) return;
    active=false;
    child.stdin.destroy();
    child.stdout.destroy();
    lines.close();
    child.kill();
    for(const request of pending.values()) request.reject(error);
    pending.clear();
  }

  child.once("error",stop);
  child.stdin.on("error",stop);
  child.stdout.on("error",stop);
  child.once("exit",()=>stop(Error("The registry reader stopped.")));
  lines.on("line",line=>{
    try {
      const reply=JSON.parse(line);
      const request=pending.get(reply.id);
      if(!request || (!Object.hasOwn(reply,"result") && typeof reply.error!=="string")) {
        throw Error("Invalid reply.");
      }
      pending.delete(reply.id);
      if(typeof reply.error==="string") request.reject(Error(reply.error));
      else request.resolve(reply.result);
    } catch {
      stop(Error("The registry reader returned an unreadable response."));
    }
  });

  return {
    get active() {return active;},
    call(name,args) {
      return new Promise((resolve,reject)=>{
        const id=++sequence;
        const request=JSON.stringify({id,name,args});
        pending.set(id,{resolve,reject});
        child.stdin.write(request+"\n");
      });
    },
    close() {stop(Error("The workspace closed."));}
  };
}

async function readBody(req) {
  if (!/^application\/json(?:\s*;|$)/i.test(req.headers["content-type"] || "")) throw Error("Use application/json.");
  const pieces=[]; let bytes=0;
  for await(const piece of req) {
    bytes+=piece.length;
    if(bytes>6000000) throw Error("Request exceeds 6 MB.");
    pieces.push(piece);
  }
  return JSON.parse(Buffer.concat(pieces).toString("utf8"));
}

async function mountWorkspace(initial,{registry,appTools}={}) {
  registry=path.resolve(registry || process.env.APEX_WORKSPACE_HOME ||
    path.join(process.env.LOCALAPPDATA || process.env.XDG_STATE_HOME || path.join(os.homedir(),".local","state"),"ApexWorkbench"));
  const children=new Map();
  let reader, closed=false;
  async function invoke(name,args={}) {
    if(closed) throw Error("The workspace closed.");
    if(registryReads.has(name)) {
      if(!reader?.active) reader=startRegistryReader(registry);
      const selected=reader;
      try {
        return await selected.call(name,args);
      } catch(error) {
        if(selected.active || closed) throw error;
        if(reader===selected) reader=undefined;
      }
    }
    const result=await runEnvironment(registry,name,args);
    if(name==="prepare_environment" && children.has(args.projectId)) {
      const previous=children.get(args.projectId);children.delete(args.projectId);
      await previous.then(panel=>panel.close()).catch(()=>{});
    }
    return result;
  }
  let catalog,first;
  try {
    catalog=await invoke("catalog");
    first=initial?await invoke("add_project",{path:path.resolve(initial)}):null;
  } catch(error) {
    reader?.close();
    throw error;
  }
  const names=new Set(catalog.map(x=>x.name));
  const nonce=randomBytes(24).toString("hex");
  function panel(id,inspected) {
    if(!children.has(id)) {
      const inspection=inspected?Promise.resolve(inspected):invoke("inspect_environment",{projectId:id});
      const promise=inspection
        .then(env=>mountWorkbench(env.path,{appTools:id===first?.id?appTools:undefined,
          workDirectories:env.prepared?env.directories:undefined}))
        .catch(error=>{if(children.get(id)===promise)children.delete(id);throw error;});
      children.set(id,promise);
    }
    return children.get(id);
  }
  function startPanel(env) {
    if(env?.installed) panel(env.projectId,env).catch(()=>{});
  }
  const json=(res,code,value)=>res.writeHead(code,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"}).end(JSON.stringify(value));
  async function rpc(message) {
    const {id,method,params={}}=message || {};
    const fail=(code,message)=>({jsonrpc:"2.0",id:id??null,error:{code,message}});
    const ok=result=>({jsonrpc:"2.0",id,result});
    if(message?.jsonrpc!=="2.0" || typeof method!=="string") return fail(-32600,"Invalid MCP request.");
    if(id===undefined) return null;
    if(method==="initialize") return ok({protocolVersion:versions.includes(params.protocolVersion)?params.protocolVersion:versions[0],
      capabilities:{tools:{}},serverInfo:{name:"apex-workbench-projects",version:"1.0.0"}});
    if(method==="ping") return ok({});
    if(method==="tools/list") return ok({tools:catalog});
    if(method!=="tools/call") return fail(-32601,"Unknown MCP method.");
    if(!names.has(params.name)) return fail(-32602,"Unknown workspace tool.");
    try {
      const result=await invoke(params.name,params.arguments || {});
      return ok({structuredContent:result,content:[{type:"text",text:JSON.stringify(result)}]});
    } catch(error) {return ok({isError:true,content:[{type:"text",text:error.message}]});}
  }
  async function serve(req,res) {
    const port=req.socket.localPort;
    if(!["127.0.0.1:"+port,"localhost:"+port].includes(req.headers.host) ||
      (req.headers.origin && req.headers.origin!=="http://"+req.headers.host)) return json(res,403,{error:"Use the local workspace origin."});
    const url=new URL(req.url,"http://"+req.headers.host);
    const relative=url.pathname.slice(base.length);
    if(relative==="projects/bootstrap") {
      if(req.method!=="GET") return json(res,405,{error:"Use GET."});
      const state=await invoke("picker_state",{projectId:url.searchParams.get("project"),initial:first?.id ?? null});
      if(url.searchParams.get("view")!=="environment") startPanel(state.selection?.environment);
      return json(res,200,{token:nonce,...state});
    }
    const isRpc=relative==="projects/mcp";
    if(relative==="projects/api" || isRpc) {
      if(req.method==="GET" && !isRpc) return json(res,200,{token:nonce,initial:first?.id || null,...await invoke("list_projects")});
      if(req.method!=="POST") return json(res,405,{error:"Use POST."});
      if(!isRpc) {
        const candidate=Buffer.from(req.headers["x-csrf-token"] || "");
        if(candidate.length!==nonce.length || !timingSafeEqual(candidate,Buffer.from(nonce))) return json(res,403,{error:"Reload the project picker."});
      }
      const body=await readBody(req);
      if(isRpc) {
        if(req.headers["mcp-protocol-version"] && !versions.includes(req.headers["mcp-protocol-version"])) return json(res,400,{error:"Unsupported MCP protocol version."});
        const reply=await rpc(body);
        return reply?json(res,200,reply):res.writeHead(202).end();
      }
      const name=body.name==="open_project"?"inspect_environment":body.name;
      if(!names.has(name)) return json(res,400,{error:"Unknown workspace action."});
      const result=await invoke(name,body.arguments || {});
      if(body.name==="open_project") startPanel(result);
      return json(res,200,result);
    }
    const assets={"":"index.html","projects/app.js":"app.js","projects/styles.css":"styles.css"};
    if(Object.hasOwn(assets,relative)) {
      if(!["GET","HEAD"].includes(req.method)) return json(res,405,{error:"Use GET."});
      const asset=assets[relative], type={".html":"text/html",".js":"text/javascript",".css":"text/css"}[path.extname(asset)];
      const bytes=await fs.readFile(path.join(__dirname,"../web/projects",asset));
      res.writeHead(200,{"Content-Type":type+"; charset=utf-8","Cache-Control":"no-store","X-Content-Type-Options":"nosniff",
        "Content-Security-Policy":"default-src 'self'; frame-src 'self'; frame-ancestors 'self'; object-src 'none'; base-uri 'none'"});
      return res.end(req.method==="HEAD"?undefined:bytes);
    }
    const match=/^p\/([0-9a-f]{20})\/(.*)$/.exec(relative);
    const projected=match?match[1]:first?.id;
    if(!projected) return json(res,404,{error:"Choose a registered project."});
    if(!match && relative!=="mcp" && !relative.startsWith("api/")) return json(res,404,{error:"Unknown workspace route."});
    const child=await panel(projected);
    if(match) req.url=base+match[2]+url.search;
    child.handle(req,res);
  }
  return {
    handle(req,res) {
      if(!req.url.startsWith(base)) return false;
      serve(req,res).catch(error=>{if(!res.headersSent) json(res,400,{error:error.message});else res.end();});
      return true;
    },
    close() {
      closed=true;
      reader?.close();
      for(const promise of children.values()) promise.then(child=>child.close()).catch(()=>{});
    }
  };
}

module.exports={mountWorkspace};
if(require.main===module) {
  const [initial,port="8794",registry]=process.argv.slice(2);
  mountWorkspace(initial,{registry}).then(workspace=>{
    const server=http.createServer((req,res)=>{
      if(req.url==="/") return res.writeHead(302,{Location:base}).end();
      if(!workspace.handle(req,res)) res.writeHead(404).end();
    });
    server.on("close",workspace.close);process.once("exit",workspace.close);
    for(const signal of ["SIGINT","SIGTERM"]) process.once(signal,()=>server.close());
    server.listen(Number(port),"127.0.0.1",()=>console.log("Workbench workspace: http://127.0.0.1:"+server.address().port+base));
  }).catch(error=>{console.error(error.message);process.exitCode=1;});
}
