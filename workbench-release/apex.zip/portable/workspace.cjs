"use strict";

const {spawn} = require("node:child_process");
const {randomBytes,timingSafeEqual} = require("node:crypto");
const fs = require("node:fs/promises");
const http = require("node:http");
const os = require("node:os");
const path = require("node:path");
const {mountWorkbench} = require("./mount.cjs");
const base = "/__workbench/";
const versions = ["2025-11-25","2025-06-18","2025-03-26"];

function runEnvironment(registry,command,args) {
  return new Promise((resolve,reject) => {
    const child = spawn(process.env.HARNESS_PYTHON || "python",
      [path.join(__dirname,"environment.py"),registry,command],{windowsHide:true,stdio:["pipe","pipe","pipe"]});
    let output="", error="";
    child.stdout.setEncoding("utf8");child.stderr.setEncoding("utf8");
    child.stdout.on("data",chunk=>output+=chunk);
    child.stderr.on("data",chunk=>error+=chunk);
    child.on("error",reject);
    child.once("close",code=>{
      if(code!==0) return reject(Error(error.trim() || "Workspace command failed."));
      try {resolve(JSON.parse(output));} catch {reject(Error("Workbench returned an unreadable response."));}
    });
    child.stdin.on("error",()=>{});
    child.stdin.end(JSON.stringify(args));
  });
}

async function readBody(req) {
  if (!/^application\/json(?:\s*;|$)/i.test(req.headers["content-type"] || "")) throw Error("Use application/json.");
  const pieces=[]; let bytes=0;
  for await(const piece of req) {
    bytes+=piece.length;
    if(bytes>6000000) throw Error("Request exceeds 6 MB.");
    pieces.push(piece);
  }
  return JSON.parse(Buffer.concat(pieces).toString("utf8"));
}

async function mountWorkspace(initial,{registry,appTools}={}) {
  registry=path.resolve(registry || process.env.APEX_WORKSPACE_HOME ||
    path.join(process.env.LOCALAPPDATA || process.env.XDG_STATE_HOME || path.join(os.homedir(),".local","state"),"ApexWorkbench"));
  const children=new Map(),bindings=new Map();
  async function invoke(name,args={}) {
    const result=await runEnvironment(registry,name,args);
    if(name==="prepare_environment" && children.has(args.projectId)) {
      const previous=children.get(args.projectId);children.delete(args.projectId);
      await previous.then(panel=>panel.close()).catch(()=>{});
    }
    return result;
  }
  const catalog=await invoke("catalog");
  const names=new Set(catalog.map(x=>x.name));
  const first=initial?await invoke("add_project",{path:path.resolve(initial)}):null;
  const nonce=randomBytes(24).toString("hex");
  async function select(id) {
    if(!bindings.has(id)) bindings.set(id,await invoke("select_project",{projectId:id}));
    return bindings.get(id);
  }
  async function panel(id) {
    const binding=await select(id);
    if(!children.has(id)) {
      const promise=invoke("inspect_environment",{projectId:id})
        .then(env=>mountWorkbench(binding.path,{appTools:id===first?.id?appTools:undefined,
          workDirectories:env.prepared?env.directories:undefined}))
        .catch(error=>{children.delete(id);throw error;});
      children.set(id,promise);
    }
    return children.get(id);
  }
  const json=(res,code,value)=>res.writeHead(code,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"}).end(JSON.stringify(value));
  async function rpc(message) {
    const {id,method,params={}}=message || {};
    const fail=(code,message)=>({jsonrpc:"2.0",id:id??null,error:{code,message}});
    const ok=result=>({jsonrpc:"2.0",id,result});
    if(message?.jsonrpc!=="2.0" || typeof method!=="string") return fail(-32600,"Invalid MCP request.");
    if(id===undefined) return null;
    if(method==="initialize") return ok({protocolVersion:versions.includes(params.protocolVersion)?params.protocolVersion:versions[0],
      capabilities:{tools:{}},serverInfo:{name:"apex-workbench-projects",version:"1.0.0"}});
    if(method==="ping") return ok({});
    if(method==="tools/list") return ok({tools:catalog});
    if(method!=="tools/call") return fail(-32601,"Unknown MCP method.");
    if(!names.has(params.name)) return fail(-32602,"Unknown workspace tool.");
    try {
      const result=await invoke(params.name,params.arguments || {});
      return ok({structuredContent:result,content:[{type:"text",text:JSON.stringify(result)}]});
    } catch(error) {return ok({isError:true,content:[{type:"text",text:error.message}]});}
  }
  async function serve(req,res) {
    const port=req.socket.localPort;
    if(!["127.0.0.1:"+port,"localhost:"+port].includes(req.headers.host) ||
      (req.headers.origin && req.headers.origin!=="http://"+req.headers.host)) return json(res,403,{error:"Use the local workspace origin."});
    const relative=new URL(req.url,"http://"+req.headers.host).pathname.slice(base.length);
    const isRpc=relative==="projects/mcp";
    if(relative==="projects/api" || isRpc) {
      if(req.method==="GET" && !isRpc) return json(res,200,{token:nonce,initial:first?.id || null,...await invoke("list_projects")});
      if(req.method!=="POST") return json(res,405,{error:"Use POST."});
      if(!isRpc) {
        const candidate=Buffer.from(req.headers["x-csrf-token"] || "");
        if(candidate.length!==nonce.length || !timingSafeEqual(candidate,Buffer.from(nonce))) return json(res,403,{error:"Reload the project picker."});
      }
      const body=await readBody(req);
      if(isRpc) {
        if(req.headers["mcp-protocol-version"] && !versions.includes(req.headers["mcp-protocol-version"])) return json(res,400,{error:"Unsupported MCP protocol version."});
        const reply=await rpc(body);
        return reply?json(res,200,reply):res.writeHead(202).end();
      }
      if(!names.has(body.name)) return json(res,400,{error:"Unknown workspace action."});
      return json(res,200,await invoke(body.name,body.arguments || {}));
    }
    const assets={"":"index.html","projects/app.js":"app.js","projects/styles.css":"styles.css"};
    if(Object.hasOwn(assets,relative)) {
      if(!["GET","HEAD"].includes(req.method)) return json(res,405,{error:"Use GET."});
      const asset=assets[relative], type={".html":"text/html",".js":"text/javascript",".css":"text/css"}[path.extname(asset)];
      const bytes=await fs.readFile(path.join(__dirname,"../web/projects",asset));
      res.writeHead(200,{"Content-Type":type+"; charset=utf-8","Cache-Control":"no-store","X-Content-Type-Options":"nosniff",
        "Content-Security-Policy":"default-src 'self'; frame-src 'self'; frame-ancestors 'self'; object-src 'none'; base-uri 'none'"});
      return res.end(req.method==="HEAD"?undefined:bytes);
    }
    const match=/^p\/([0-9a-f]{20})\/(.*)$/.exec(relative);
    const projected=match?match[1]:first?.id;
    if(!projected) return json(res,404,{error:"Choose a registered project."});
    if(!match && relative!=="mcp" && !relative.startsWith("api/")) return json(res,404,{error:"Unknown workspace route."});
    const child=await panel(projected);
    if(match) req.url=base+match[2]+new URL(req.url,"http://"+req.headers.host).search;
    child.handle(req,res);
  }
  return {
    handle(req,res) {
      if(!req.url.startsWith(base)) return false;
      serve(req,res).catch(error=>{if(!res.headersSent) json(res,400,{error:error.message});else res.end();});
      return true;
    },
    close() { for(const promise of children.values()) promise.then(child=>child.close()).catch(()=>{}); }
  };
}

module.exports={mountWorkspace};
if(require.main===module) {
  const [initial,port="8794",registry]=process.argv.slice(2);
  mountWorkspace(initial,{registry}).then(workspace=>{
    const server=http.createServer((req,res)=>{
      if(req.url==="/") return res.writeHead(302,{Location:base}).end();
      if(!workspace.handle(req,res)) res.writeHead(404).end();
    });
    server.on("close",workspace.close);process.once("exit",workspace.close);
    for(const signal of ["SIGINT","SIGTERM"]) process.once(signal,()=>server.close());
    server.listen(Number(port),"127.0.0.1",()=>console.log("Workbench workspace: http://127.0.0.1:"+server.address().port+base));
  }).catch(error=>{console.error(error.message);process.exitCode=1;});
}
