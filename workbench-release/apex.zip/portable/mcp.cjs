"use strict";

const {execFileSync} = require("node:child_process");
const fs = require("node:fs/promises");
const path = require("node:path");
const {efforts} = require("../web/panel/profile");
const {inspectRun, runIdPattern} = require("./run-history.cjs");

const protocol = "2025-11-25";
const versions = [protocol, "2025-06-18", "2025-03-26"];
const profile = {type: "string", enum: ["audited", "fast"]};
function tool(name, description, properties, required) {
  return {name, description, inputSchema: {type: "object", properties, required, additionalProperties: false}};
}
const tools = [
  tool("set_repair_budget", "Save the named project profile repair limit.",
    {profile, value: {type: "integer", minimum: 1, maximum: 20}}, ["profile", "value"]),
  tool("set_builder_effort", "Save the named project profile builder effort.",
    {profile, value: {type: "string", enum: efforts}}, ["profile", "value"]),
  tool("inspect_run", "Read project run identities, recorded transitions, check receipts and task events. Omit runId for the active or latest run.",
    {runId: {type: "string", pattern: runIdPattern.source}}, [])
];

function profileCommand(root, ...args) {
  const text = execFileSync("ruby", [path.join(root, ".harness/bin/harness"), "setup", ...args, "--project", root],
    {cwd: root, encoding: "utf8", maxBuffer: 12 * 1024 * 1024, windowsHide: true});
  return JSON.parse(text);
}

async function callTool(root, definition, args, registered) {
  const {properties, required} = definition.inputSchema;
  if (!args || typeof args !== "object" || Array.isArray(args) ||
      Object.keys(args).some(key => !Object.hasOwn(properties, key)) ||
      required.some(key => !Object.hasOwn(args, key))) throw new Error("Invalid tool arguments.");
  for (const [key, value] of Object.entries(args)) {
    const rule = properties[key];
    const valid = {string: typeof value === "string", boolean: typeof value === "boolean", integer: Number.isSafeInteger(value)};
    if (!valid[rule.type]) throw new Error("Invalid type for " + key);
    if (rule.enum && !rule.enum.includes(value)) throw new Error("Unsupported " + key + ".");
    if (rule.type === "integer" && (!Number.isInteger(value) || value < rule.minimum || value > rule.maximum)) throw new Error("Use an integer from 1 to 20.");
    if (rule.pattern && (typeof value !== "string" || !runIdPattern.test(value))) throw new Error("Invalid run identity.");
  }
  if (registered.has(definition.name)) return registered.get(definition.name).handle(args);
  if (definition.name === "get_profile") return profileCommand(root, "profile-export");
  if (definition.name !== "inspect_run") profileCommand(root, "profile-setting", args.profile, definition.name, String(args.value));
  if (definition.name === "inspect_run") return inspectRun(root, args.runId);
  return {profile: args.profile, field: definition.name === "set_repair_budget" ? "stages.buildReview.limit" : "stages.build.effort", value: args.value};
}

// App code registers handlers at host startup. Profile data can select registered names only.
async function rpc(root, message, registrations = []) {
  const {id, method, params = {}} = message || {};
  const error = (code, detail) => ({jsonrpc: "2.0", id: id ?? null, error: {code, message: detail}});
  if (message?.jsonrpc !== "2.0" || typeof method !== "string" || (id !== undefined && typeof id !== "string" && !Number.isInteger(id))) return error(-32600, "Invalid request.");
  if (id === undefined) return null;
  if (!params || typeof params !== "object" || Array.isArray(params)) return error(-32602, "Invalid parameters.");
  const registered = new Map();
  if (registrations.length) {
    let allowed = [];
    try { allowed = JSON.parse(await fs.readFile(path.join(root, ".harness/profile.json"), "utf8")).permittedTools; }
    catch (error) { if (error.code !== "ENOENT") throw error; }
    for (const entry of registrations) {
      if (!allowed.includes(entry.name)) continue;
      const schema = entry.inputSchema;
      if (!entry.name.startsWith("app_") || typeof entry.handle !== "function" ||
          schema?.type !== "object" || schema.additionalProperties !== false ||
          !schema.properties || !Array.isArray(schema.required) ||
          Object.values(schema.properties).some(rule => !["integer", "string", "boolean"].includes(rule.type) ||
            Object.keys(rule).some(key => !["type", "enum", "minimum", "maximum"].includes(key)))) {
        throw Error("Invalid app tool contract.");
      }
      registered.set(entry.name, entry);
    }
  }
  const available = [...tools, tool("get_profile", "Read the project profile.", {}, []),
    ...Array.from(registered.values(), ({name, description, inputSchema}) => ({name, description, inputSchema}))];
  let result;
  switch (method) {
    case "initialize":
      if (typeof params.protocolVersion !== "string" || !params.clientInfo || !params.capabilities) return error(-32602, "Missing client initialization fields.");
      result = {protocolVersion: versions.includes(params.protocolVersion) ? params.protocolVersion : protocol,
        capabilities: {tools: {}}, serverInfo: {name: "workbench", version: "1.0.0"}};
      break;
    case "ping": result = {}; break;
    case "tools/list": result = {tools: available}; break;
    case "tools/call": {
      const definition = available.find(item => item.name === params.name);
      if (!definition) return error(-32602, "Unknown tool.");
      try {
        const value = await callTool(root, definition, params.arguments === undefined ? {} : params.arguments, registered);
        result = {structuredContent: value, content: [{type: "text", text: JSON.stringify(value)}]};
      } catch (failure) {
        result = {isError: true, content: [{type: "text", text: failure.message}]};
      }
      break;
    }
    default: return error(-32601, "Unknown method.");
  }
  return {jsonrpc: "2.0", id, result};
}

if (require.main === module) {
  const [project, modulePath] = process.argv.slice(2);
  const registrations = modulePath ? require(modulePath) : [];
  let input = "";
  process.stdin.setEncoding("utf8");
  process.stdin.on("data", part => { input += part; });
  process.stdin.on("end", async () => {
    try { console.log(JSON.stringify(await rpc(project, JSON.parse(input), registrations))); }
    catch (error) { console.error(error.message); process.exitCode = 1; }
  });
}
module.exports = {rpc};
