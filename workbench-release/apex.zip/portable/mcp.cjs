"use strict";

const {execFileSync} = require("node:child_process");
const fs = require("node:fs/promises");
const path = require("node:path");
const {efforts} = require("../web/panel/profile");
const {inspectRun, runIdPattern} = require("./run-history.cjs");

const protocol = "2025-11-25";
const versions = [protocol, "2025-06-18", "2025-03-26"];
const profile = {type: "string", enum: ["audited", "fast"]};
const revision = {type:"string"};
const qualityOperations = {
  quality_status: "status", quality_validate: "validate", quality_draft: "draft",
  quality_trial: "trial", quality_evidence: "export"
};
const qualityRouteOperations = {quality_routes:"discover", quality_prepare_route:"prepare"};
function tool(name, description, properties, required) {
  return {name, description, inputSchema: {type: "object", properties, required, additionalProperties: false}};
}
const tools = [
  tool("set_repair_budget", "Save the named project profile repair limit.",
    {profile, value: {type: "integer", minimum: 1, maximum: 20}}, ["profile", "value"]),
  tool("set_builder_effort", "Save the named project profile builder effort.",
    {profile, value: {type: "string", enum: efforts}}, ["profile", "value"]),
  tool("inspect_run", "Read project run identities, recorded transitions, check receipts and task events. Omit runId for the active or latest run.",
    {runId: {type: "string", pattern: runIdPattern.source}}, []),
  tool("project_capabilities", "Inspect the selected checkout for app components, preview commands, tests, files, and Git refs.", {}, []),
  tool("quality_status", "Read the project quality policy, draft, and recorded trials.", {}, []),
  tool("quality_validate", "Validate a proposed quality definition and return its revision.",
    {definition:{type:"object"}}, ["definition"]),
  tool("quality_draft", "Propose a quality draft for human review. This does not activate it.",
    {definition:{type:"object"},base_revision:revision,expected_revision:revision}, ["definition"]),
  tool("quality_trial", "Run the published quality policy against one or two committed Git revisions.",
    {revision,refs:{type:"array",items:{type:"string"},minItems:1,maxItems:2}}, ["revision","refs"]),
  tool("quality_evidence", "Read the shareable report for a recorded quality trial.",
    {id:{type:"string"}}, ["id"]),
  tool("quality_routes", "Discover HTTP routes and Electron IPC channels. Runtime discovery loads an installed local Rails app.",
    {runtime:{type:"boolean"},app:{type:"string"}}, []),
  tool("quality_prepare_route", "Trace one route and add checks and grading criteria to a Quality draft. Published rules are unchanged.",
    {route_id:{type:"string"},method:{type:"string"},path:{type:"string"},source_path:{type:"string"},
      base_revision:revision,expected_revision:revision}, [])
];

function profileCommand(root, ...args) {
  const text = execFileSync(process.env.HARNESS_RUBY || "ruby", [path.join(root, ".harness/bin/harness"), "setup", ...args, "--project", root],
    {cwd: root, encoding: "utf8", maxBuffer: 12 * 1024 * 1024, windowsHide: true});
  return JSON.parse(text);
}

async function callTool(root, definition, args, registered) {
  const {properties, required} = definition.inputSchema;
  if (!args || typeof args !== "object" || Array.isArray(args) ||
      Object.keys(args).some(key => !Object.hasOwn(properties, key)) ||
      required.some(key => !Object.hasOwn(args, key))) throw new Error("Invalid tool arguments.");
  for (const [key, value] of Object.entries(args)) {
    const rule = properties[key];
    const valid = {string: typeof value === "string", boolean: typeof value === "boolean", integer: Number.isSafeInteger(value),
      object: value !== null && typeof value === "object" && !Array.isArray(value), array: Array.isArray(value)};
    if (!valid[rule.type]) throw new Error("Invalid type for " + key);
    if (rule.enum && !rule.enum.includes(value)) throw new Error("Unsupported " + key + ".");
    if (rule.type === "integer" && (!Number.isInteger(value) || value < rule.minimum || value > rule.maximum)) throw new Error("Use an integer from 1 to 20.");
    if (rule.pattern && (typeof value !== "string" || !runIdPattern.test(value))) throw new Error("Invalid run identity.");
  }
  if (registered.has(definition.name)) return registered.get(definition.name).handle(args);
  if (definition.name === "project_capabilities") {
    const reply = execFileSync(process.env.HARNESS_PYTHON || "python",
      [path.join(__dirname, "../project_capabilities.py"), "--project", root],
      {cwd:root, encoding:"utf8", maxBuffer:16*1024*1024, windowsHide:true, timeout:45000});
    return JSON.parse(reply);
  }
  if (Object.hasOwn(qualityRouteOperations, definition.name)) {
    const operation = qualityRouteOperations[definition.name];
    const reply = execFileSync(process.env.HARNESS_PYTHON || "python",
      [path.join(__dirname, "../quality_routes.py"), operation, "--project", root],
      {input:JSON.stringify(args), cwd:root, encoding:"utf8", maxBuffer:16*1024*1024, windowsHide:true, timeout:args.runtime ? 140000 : 65000});
    return JSON.parse(reply);
  }
  if (Object.hasOwn(qualityOperations, definition.name)) {
    const operation = qualityOperations[definition.name];
    const input = operation === "trial" ? {...args, policy:"published"} :
      operation === "draft" ? {base_revision:null, expected_revision:null, ...args} : args;
    const reply = execFileSync(process.env.HARNESS_PYTHON || "python",
      [path.join(__dirname, "../quality.py"), operation, "--project", root],
      {input:JSON.stringify(input), cwd:root, encoding:"utf8", maxBuffer:16*1024*1024,
       windowsHide:true, timeout:operation === "trial" ? 240000 : 20000});
    return JSON.parse(reply);
  }
  if (definition.name === "get_profile") return profileCommand(root, "profile-export");
  if (definition.name !== "inspect_run") profileCommand(root, "profile-setting", args.profile, definition.name, String(args.value));
  if (definition.name === "inspect_run") return inspectRun(root, args.runId);
  return {profile: args.profile, field: definition.name === "set_repair_budget" ? "stages.buildReview.limit" : "stages.build.effort", value: args.value};
}

function registeredTool(entry) {
  const schema = entry.inputSchema;
  if (!/^app_[a-z][a-z0-9_]{0,63}$/.test(entry.name) ||
      typeof entry.handle !== "function" || schema?.type !== "object" || schema.additionalProperties !== false ||
      !schema.properties || !Array.isArray(schema.required) ||
      Object.values(schema.properties).some(rule => !["integer", "string", "boolean"].includes(rule.type) ||
        Object.keys(rule).some(key => !["type", "enum", "minimum", "maximum"].includes(key)))) {
    throw Error("Invalid app tool contract.");
  }
  return entry;
}

function describeTools(registrations) {
  const available = [...tools, ...registrations.map(registeredTool)];
  return available.map(({name, description}) => ({name, description: typeof description === "string" ? description : "", app: name.startsWith("app_")}));
}

// App code registers handlers at host startup. Profile data can select registered names only.
async function rpc(root, message, registrations = []) {
  const {id, method, params = {}} = message || {};
  const error = (code, detail) => ({jsonrpc: "2.0", id: id ?? null, error: {code, message: detail}});
  if (message?.jsonrpc !== "2.0" || typeof method !== "string" || (id !== undefined && typeof id !== "string" && !Number.isInteger(id))) return error(-32600, "Invalid request.");
  if (id === undefined) return null;
  if (!params || typeof params !== "object" || Array.isArray(params)) return error(-32602, "Invalid parameters.");
  const registered = new Map();
  if (registrations.length) {
    let allowed = [];
    try { allowed = JSON.parse(await fs.readFile(path.join(root, ".harness/profile.json"), "utf8")).permittedTools ?? []; }
    catch (error) { if (error.code !== "ENOENT") throw error; }
    for (const entry of registrations) {
      if (!allowed.includes(entry.name)) continue;
      registered.set(entry.name, registeredTool(entry));
    }
  }
  const available = [...tools, tool("get_profile", "Read the project profile.", {}, []),
    ...Array.from(registered.values(), ({name, description, inputSchema}) => ({name, description, inputSchema}))];
  let result;
  switch (method) {
    case "initialize":
      if (typeof params.protocolVersion !== "string" || !params.clientInfo || !params.capabilities) return error(-32602, "Missing client initialization fields.");
      result = {protocolVersion: versions.includes(params.protocolVersion) ? params.protocolVersion : protocol,
        capabilities: {tools: {}}, serverInfo: {name: "workbench", version: "1.0.0"}};
      break;
    case "ping": result = {}; break;
    case "tools/list": result = {tools: available}; break;
    case "tools/call": {
      const definition = available.find(item => item.name === params.name);
      if (!definition) return error(-32602, "Unknown tool.");
      try {
        const value = await callTool(root, definition, params.arguments === undefined ? {} : params.arguments, registered);
        result = {structuredContent: value, content: [{type: "text", text: JSON.stringify(value)}]};
      } catch (failure) {
        result = {isError: true, content: [{type: "text", text: failure.message}]};
      }
      break;
    }
    default: return error(-32601, "Unknown method.");
  }
  return {jsonrpc: "2.0", id, result};
}

if (require.main === module) {
  const [project, modulePath] = process.argv.slice(2);
  const registrations = modulePath ? require(modulePath) : [];
  if (project === "--app-tool-catalog") {
    console.log(JSON.stringify(describeTools(registrations)));
    return;
  }
  let input = "";
  process.stdin.setEncoding("utf8");
  process.stdin.on("data", part => { input += part; });
  process.stdin.on("end", async () => {
    try { console.log(JSON.stringify(await rpc(project, JSON.parse(input), registrations))); }
    catch (error) { console.error(error.message); process.exitCode = 1; }
  });
}
module.exports = {rpc};
