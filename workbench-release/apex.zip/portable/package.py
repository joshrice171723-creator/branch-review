"""Export the manifest-selected distribution. Verify each byte before publication."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import tempfile
from zipfile import ZipFile, ZIP_DEFLATED


def export(root, destination, project=None):
    manifest = (root / "MANIFEST.sha256").read_bytes()
    files = {}
    for line in manifest.decode().splitlines():
        digest, name = line.split("  ", 1)
        path = PurePosixPath(name)
        source = root / path
        if (path.is_absolute() or "\\\\" in name or any(part.startswith(".") or part == "__pycache__" for part in path.parts)
                or source.resolve() != source or not source.is_file() or name in files):
            raise ValueError("Invalid distribution path: " + name)
        data = source.read_bytes()
        if hashlib.sha256(data).hexdigest() != digest:
            raise ValueError("Manifest mismatch: " + name)
        files[name] = data
    if project:
        # An extracted kit can export another project. Replace the previous portable profile.
        manifest = b"".join(line for line in manifest.splitlines(keepends=True)
                            if not line.rstrip().endswith(b"  project-profile.json"))
        result = subprocess.run(["ruby", str(root / "bin/harness"), "setup", "profile-export",
                                 "--project", str(project)], capture_output=True, encoding="utf-8", check=True)
        profile = json.loads(result.stdout)
        restricted = re.compile(r"(?:(?<!\w)[A-Za-z]:[\\/]|/(?:Users|home)/[^/\s]+/|-----BEGIN [A-Z ]*PRIVATE KEY-----|"
                                r"(?:sk-proj-|ghp_)[a-zA-Z0-9_-]{12,}|://[^/\s]+:[^/\s]+@)")
        data = (json.dumps(profile, ensure_ascii=False, indent=2) + "\n").encode()
        if restricted.search(data.decode()):
            raise ValueError("Remove machine paths or credential material from the portable profile.")
        files["project-profile.json"] = data
        manifest = manifest.rstrip() + ("\n" + hashlib.sha256(data).hexdigest() + "  project-profile.json\n").encode()
    files["MANIFEST.sha256"] = manifest
    if destination.resolve() in {root / name for name in files}:
        raise ValueError("Choose a separate archive path")
    with tempfile.NamedTemporaryFile(dir=destination.parent, delete=False) as draft:
        temp = Path(draft.name)
    try:
        with ZipFile(temp, "w", compression=ZIP_DEFLATED) as archive:
            for name, data in files.items():
                archive.writestr(name, data)
        os.replace(temp, destination)
    finally:
        temp.unlink(missing_ok=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("archive", type=Path)
    parser.add_argument("--project", type=Path, help="Include this project profile")
    args = parser.parse_args()
    export(Path(__file__).resolve().parents[1], args.archive, args.project)
