"""Project registration, native harness setup, and ownership-checked workspace cleanup."""
import argparse
from contextlib import closing
import hashlib
import json
import os
from pathlib import Path
import shutil
import sqlite3
import stat
import subprocess
import sys
import tempfile


RUNTIME = Path(__file__).resolve().parents[1]
ID = {"type":"string","pattern":"^[0-9a-f]{20}$"}
WORD = {"type":"string","minLength":1}


def tool(name, description, fields=None, required=()):
    return {"name":name,"description":description,"inputSchema":{"type":"object","additionalProperties":False,
            "properties":fields or {},"required":list(required)}}


TOOLS = [
    tool("list_projects","List registered projects and their stable IDs."),
    tool("add_project","Register an existing local project directory.",{"path":WORD},["path"]),
    tool("select_project","Open the project-bound panel for this registered project.",{"projectId":ID},["projectId"]),
    tool("inspect_environment","Read the project runtime, checks, tool availability, and managed work directory.",{"projectId":ID},["projectId"]),
    tool("prepare_environment","Install the runtime, apply the project profile, and prepare its scratch and temporary directories.",
         {"projectId":ID,"discoverChecks":{"type":"boolean"},"upgradeRuntime":{"type":"boolean"},
          "profile":{"type":"object"},"checks":{"type":"array","items":{"type":"object"}}},["projectId"]),
    tool("get_project_profile","Read the complete executable project profile.",{"projectId":ID},["projectId"]),
    tool("apply_project_profile","Validate and apply a complete profile for future tasks.",
         {"projectId":ID,"profile":{"type":"object"}},["projectId","profile"]),
    tool("configure_project_checks","Set the project's inherited checks and update its saved profile.",
         {"projectId":ID,"checks":{"type":"array","items":{"type":"object"}}},["projectId","checks"]),
    tool("preview_cleanup","List the files that belong to the managed work directories and produce a cleanup ID.",{"projectId":ID},["projectId"]),
    tool("clean_environment","Clean the managed work directories if they still match this preview.",
         {"projectId":ID,"previewId":WORD},["projectId","previewId"])
]


def constrained(root, target):
    if target.resolve() != target or not target.is_relative_to(root):
        raise ValueError("The managed path leaves its project or contains a link.")
    return target


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def project_id(path):
    return hashlib.sha256(os.path.normcase(str(path)).encode()).hexdigest()[:20]


def native(project, *args, data=None, install=False):
    script = (RUNTIME if install else project/".harness") / "bin/harness"
    cmd = ["ruby",str(script),*args,"--project",str(project)]
    draft = None
    try:
        if data is not None:
            with tempfile.NamedTemporaryFile(dir=project/".harness",suffix=".json",mode="w",encoding="utf8",delete=False) as draft:
                json.dump(data,draft)
            cmd += ["--file",draft.name]
        result = subprocess.run(cmd,cwd=project,capture_output=True,timeout=120,encoding="utf8",errors="replace")
        if result.returncode:
            raise ValueError((result.stderr or result.stdout or "Workbench command failed.").strip()[:2500])
        return json.loads(result.stdout)
    finally:
        if draft is not None:
            Path(draft.name).unlink(missing_ok=True)


def candidates(project):
    def check(name,argv):
        return [{"name":name,"argv":argv,"cwd":".","required":True,"benchmark":False,"phases":["baseline","after"]}]
    manifest = project / "package.json"
    if manifest.is_file():
        try:
            metadata=read_json(manifest)
        except (OSError,ValueError):
            metadata={}
        scripts=metadata.get("scripts",{}) if isinstance(metadata,dict) else {}
        if isinstance(scripts,dict) and isinstance(scripts.get("test"),str) and "no test specified" not in scripts["test"].lower():
            return check("project_tests",["npm","test"])
    for directory in ["tests","test","."]:
        folder = project/directory
        if folder.is_dir() and any(folder.glob("test*.py")):
            return check("python_tests",["python","-m","unittest","discover","-s",directory])
    if (project/"go.mod").is_file(): return check("go_tests",["go","test","./..."])
    if (project/"Cargo.toml").is_file(): return check("cargo_tests",["cargo","test"])
    if (project/"bin/rails").is_file(): return check("rails_tests",["ruby","bin/rails","test"])
    return []


def lifecycle(project):
    home=project/".harness"
    pointer=home/"active_task"
    if not pointer.exists(): return None
    run=pointer.read_text(encoding="utf8").strip()
    if not run or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-" for c in run):
        raise ValueError("The project has an invalid active task record.")
    folder=constrained(home,home/"tasks"/run)
    if not (folder/"task.json").is_file(): raise ValueError("The active task record is unavailable.")
    states=sorted((folder/"lifecycle").glob("*.json"))
    return {"id":run,"status":read_json(states[-1])["status"] if states else "active"}


def managed(project, create=False):
    home=constrained(project,project/".harness")
    folder=constrained(home,home/"workspace-env")
    marker=folder/"owner.json"
    owner={"version":1,"projectId":project_id(project)}
    if not folder.exists():
        if not create: return None
        folder.mkdir()
        try: marker.write_text(json.dumps(owner),encoding="utf8")
        except BaseException:
            folder.rmdir()
            raise
    if not marker.is_file() or constrained(folder,marker) != marker or read_json(marker)!=owner:
        raise ValueError("The work directory has no matching ownership record.")
    for name in ("scratch","tmp"):
        target=constrained(folder,folder/name)
        if create: target.mkdir(exist_ok=True)
    return folder


def inspect(project):
    home=constrained(project,project/".harness")
    installed=(home/"portable/mount.cjs").is_file() and (home/"bin/harness").is_file()
    config=read_json(home/"project.json") if (home/"project.json").is_file() else {}
    applied=(home/"profile.json").is_file() and not (home/"profile.disabled").exists()
    config_profile=read_json(home/"profile.json") if applied else {}
    folder=managed(project) if home.is_dir() else None
    checks=config_profile.get("checks",config.get("checks",[]))
    programs=dict.fromkeys(["ruby","python","node","codex","muse",*(check["argv"][0] for check in checks if check.get("argv"))])
    return {"projectId":project_id(project),"name":project.name,"path":str(project),"installed":installed,
            "prepared":bool(folder),"profileApplied":applied,"engine":config.get("engine",{}).get("version"),
            "activeTask":lifecycle(project),"checks":[check["name"] for check in checks],"suggestedChecks":candidates(project),
            "programs":{name:shutil.which(name) is not None for name in programs},
            "directories":{name:str(folder/name) for name in ("scratch","tmp")} if folder else {}}


def prepare(project,args):
    current=inspect(project)
    if current["activeTask"] and current["activeTask"]["status"]=="active":
        raise ValueError("Finish or pause the active task before preparing this environment.")
    home=project/".harness"
    if home.exists() and not (home/"project.json").is_file(): raise ValueError("An existing .harness directory has no project configuration.")
    if not current["installed"] or args.get("upgradeRuntime"):
        native(project,"setup","install",install=True)
    profile=args["profile"] if "profile" in args else native(project,"setup","profile-export")
    if "checks" in args:
        configure_checks(project,args["checks"],profile)
    else:
        if not profile.get("checks") and args.get("discoverChecks",True): profile["checks"]=candidates(project)
        native(project,"setup","profile-import",data=profile)
    managed(project,create=True)
    return inspect(project)


def configure_checks(project,checks,profile=None):
    active=lifecycle(project)
    if active and active["status"]=="active": raise ValueError("Finish or pause the active task before changing project checks.")
    home=project/".harness"
    old_config=read_json(home/"project.json")
    old_names={row["name"] for row in old_config.get("checks",[])}
    applied=(home/"profile.json").is_file()
    disabled=(home/"profile.disabled").exists()
    target=profile if profile is not None else native(project,"setup","profile-export")
    names={row["name"] for row in checks}
    target["checks"]=checks+[row for row in target.get("checks",[]) if row["name"] not in old_names|names]
    native(project,"setup","configure",data={**old_config,"checks":checks})
    try:
        if applied or profile is not None:
            native(project,"setup","profile-import",data=target)
            if disabled and profile is None: native(project,"setup","profile-disable")
    except Exception:
        native(project,"setup","configure",data=old_config)
        raise
    return inspect(project)


def cleanup(project,expected=None):
    folder=managed(project)
    entries=[]
    if folder:
        for name in ("scratch","tmp"):
            base=constrained(folder,folder/name)
            for item in sorted(base.rglob("*")):
                props=item.lstat()
                if item.is_symlink() or getattr(props,"st_file_attributes",0)&getattr(stat,"FILE_ATTRIBUTE_REPARSE_POINT",0):
                    raise ValueError("Remove the link from the managed directory before cleanup.")
                constrained(base,item)
                entries.append({"path":item.relative_to(folder).as_posix(),"type":"directory" if item.is_dir() else "file",
                                "size":props.st_size if item.is_file() else 0,"modifiedNs":props.st_mtime_ns})
    digest=hashlib.sha256(json.dumps([project_id(project),entries],sort_keys=True).encode()).hexdigest()
    info={"projectId":project_id(project),"previewId":digest,"entries":entries,"bytes":sum(row["size"] for row in entries)}
    if expected is None: return info
    if expected!=digest: raise ValueError("The managed files changed. Preview cleanup again.")
    active=lifecycle(project)
    if active and active["status"]=="active": raise ValueError("Finish or pause the active task before cleanup.")
    # Delete only entries in the verified inventory. New files are never swept up by a recursive delete.
    for entry in reversed(entries):
        target=constrained(folder,folder/entry["path"])
        if entry["type"]=="directory": target.rmdir()
        else: target.unlink()
    return {"projectId":project_id(project),"removed":len(entries),"bytes":info["bytes"]}


def dispatch(registry,name,args):
    spec=next((item["inputSchema"] for item in TOOLS if item["name"]==name),None)
    if not spec or not isinstance(args,dict) or set(args)-set(spec["properties"]) or set(spec["required"])-set(args):
        raise ValueError("Invalid workspace tool or arguments.")
    types={"string":str,"object":dict,"array":list,"boolean":bool}
    if any(not isinstance(value,types[spec["properties"][key]["type"]]) for key,value in args.items()):
        raise ValueError("Invalid workspace argument type.")
    registry.mkdir(parents=True,exist_ok=True)
    with closing(sqlite3.connect(registry/"projects.sqlite3",timeout=120)) as db, db:
        db.execute("CREATE TABLE IF NOT EXISTS projects (id TEXT PRIMARY KEY, path TEXT UNIQUE NOT NULL)")
        if name=="add_project":
            raw=Path(args["path"])
            if not raw.is_absolute(): raise ValueError("Enter an absolute project directory.")
            path=raw.resolve(strict=True)
            if not path.is_dir() or ".harness" in path.parts: raise ValueError("Select a project directory outside the harness runtime.")
            key=project_id(path)
            db.execute("INSERT OR IGNORE INTO projects VALUES (?,?)",(key,str(path)))
            return {"id":key,"name":path.name or str(path),"path":str(path)}
        if name=="list_projects":
            return {"projects":[{"id":key,"name":Path(raw).name or raw,"path":raw} for key,raw in db.execute("SELECT id,path FROM projects ORDER BY path")]}
        row=db.execute("SELECT path FROM projects WHERE id=?",(args["projectId"],)).fetchone()
        if row is None: raise ValueError("Select a registered project.")
        project=Path(row[0])
        if project.resolve(strict=True)!=project or not project.is_dir(): raise ValueError("The registered project moved. Select its new location.")
        if name in {"prepare_environment","configure_project_checks","clean_environment","apply_project_profile"}: db.execute("BEGIN IMMEDIATE")
        if name=="select_project": return {"id":args["projectId"],"name":project.name,"path":str(project),"panel":"/__workbench/p/"+args["projectId"]+"/"}
        if name=="inspect_environment": return inspect(project)
        if name=="prepare_environment": return prepare(project,args)
        if name=="configure_project_checks": return configure_checks(project,args["checks"])
        if name=="preview_cleanup": return cleanup(project)
        if name=="clean_environment": return cleanup(project,args["previewId"])
        if name=="get_project_profile": return native(project,"setup","profile-export")
        return native(project,"setup","profile-import",data=args["profile"])


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("registry",type=Path)
    parser.add_argument("name")
    options=parser.parse_args()
    try:
        result=TOOLS if options.name=="catalog" else dispatch(options.registry,options.name,json.load(sys.stdin))
        print(json.dumps(result))
    except (ValueError,OSError,KeyError,TypeError,sqlite3.Error,subprocess.SubprocessError) as error:
        print(str(error),file=sys.stderr)
        sys.exit(1)
