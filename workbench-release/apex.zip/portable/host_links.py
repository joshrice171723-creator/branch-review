"""Read optional links to installed local hosts for this project."""
import json
from pathlib import Path
from urllib.parse import urlsplit


def host_links(project):
    if not project:
        return []
    root=Path(project)/".harness/hosts"
    if not root.is_dir() or root.resolve()!=root:
        return []
    links=[]
    for entry in sorted(root.glob("*.json"))[:24]:
        try:
            if entry.resolve()!=entry or entry.stat().st_size>4096:
                continue
            value=json.loads(entry.read_text(encoding="utf8"))
            label=value["name"]
            address=urlsplit(value["url"])
            if (value.get("version")==1 and isinstance(label,str) and 0<len(label)<=64 and
                    address.scheme=="http" and address.hostname in {"127.0.0.1","localhost"} and
                    address.port and address.username is None and address.password is None):
                links.append({"name":label,"url":address.geturl()})
        except (ValueError,OSError,TypeError,KeyError):
            continue
    return links
