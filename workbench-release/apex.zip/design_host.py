"""Connect a Design review group to this project's running Branch Review host."""
from http.client import HTTPConnection
import json
from pathlib import Path
from urllib.parse import quote, urlsplit

from portable.host_links import host_links


def loopback_origin(value):
    parsed = urlsplit(value)
    if (parsed.scheme != "http" or parsed.hostname not in ("localhost","127.0.0.1","::1") or
            parsed.username or parsed.password or not parsed.port):
        raise ValueError("Enter the local Branch Review address with its port.")
    return parsed.scheme + "://" + parsed.netloc


def preview_url(value):
    value = value.strip()
    if not value:
        return ""
    parsed = urlsplit(value)
    if (not parsed.hostname or parsed.username or parsed.password or
            (parsed.scheme != "https" and not (parsed.scheme == "http" and parsed.hostname in ("localhost","127.0.0.1","::1")))):
        raise ValueError("Enter an HTTPS app address or a local HTTP address.")
    return value


def request(origin, path, body=None, token=None):
    parsed = urlsplit(loopback_origin(origin))
    connection = HTTPConnection(parsed.hostname, parsed.port, timeout=95 if body is not None else 6)
    headers = {"Accept":"application/json"}
    if body is not None:
        headers.update({"Origin":origin,"X-Review-Token":token,"Content-Type":"application/json"})
    try:
        connection.request("POST" if body is not None else "GET", path,
                           json.dumps(body).encode("utf8") if body is not None else None, headers)
        res = connection.getresponse()
        data = res.read(16*1024*1024+1)
        if len(data)>16*1024*1024:
            raise ValueError("The Branch Review response is too large.")
        result = json.loads(data)
        if res.status != 200:
            raise ValueError(result.get("error") or "Branch Review could not complete the request.")
        return result
    except (OSError, json.JSONDecodeError) as error:
        raise ValueError("Open Branch Review for this project and retry.") from error
    finally:
        connection.close()


def origin_for(root, state):
    saved = state.get("reviewHost")
    if saved and state.get("mode") != "task":
        return loopback_origin(saved)
    registered = next((loopback_origin(row["url"]) for row in host_links(root)
                       if row["name"].casefold() == "branch review"), "")
    return registered or (loopback_origin(saved) if saved else "")


def check_project(root, origin):
    project = request(origin, "/api/workbench").get("project")
    if not project or Path(project).resolve()!=Path(root).resolve():
        raise ValueError("Branch Review is open on another project.")


def app_preview(root, state):
    selected = state.get("preview","")
    links = host_links(root)
    review_origin = origin_for(root,state)
    if not selected:
        selected = next((h["url"] for h in links if h["name"].casefold()!="branch review"),"")
    if not selected and review_origin:
        try:
            current = request(review_origin,"/api/state")
            changed = current.get("changed") or {}
            if Path(current.get("repository","")).resolve()==Path(root).resolve() and changed.get("proxy"):
                selected = "http://127.0.0.1:"+str(int(changed["proxy"]))+"/"
        except (ValueError, OSError):
            pass
    if not selected:
        return {"url":"","status":"Enter the address of the app running for this project."}
    selected = preview_url(selected)
    parsed = urlsplit(selected)
    if parsed.scheme=="http":
        connection = HTTPConnection(parsed.hostname,parsed.port or 80,timeout=3)
        try:
            connection.request("GET",parsed.path+("?"+parsed.query if parsed.query else "") or "/")
            if not 200 <= connection.getresponse().status < 400:
                return {"url":"","status":"The app did not return a working page.","address":selected}
        except OSError:
            return {"url":"","status":"Start the project app or change its address.","address":selected}
        finally:
            connection.close()
    return {"url":selected,"status":"Project preview","address":selected}


def group_run(build, group):
    return next((a["task"] for a in reversed(build["attempts"])
                 if a["slice"] in group["slices"] and a["outcome"]=="completed"), None)


def group_review(root, state, build, group):
    task = group_run(build,group)
    origin = origin_for(root,state)
    if not origin:
        return {"status":"disconnected","message":"Connect Branch Review for this project."}
    if not task:
        return {"status":"waiting","message":"Complete the slice checks before Branch Review."}
    check_project(root,origin)
    target = {"runId":task,"url":origin+"/?workbenchRun="+quote(task)+"#workbench"}
    try:
        result = request(origin,"/api/workbench-review?run="+quote(task))
    except ValueError as error:
        return dict(target,status="waiting",message=str(error))
    if result.get("status") == "not-exported" and result.get("runId") == task:
        return dict(result, url=target["url"])
    if (result.get("runId")!=task or result.get("commit")!=group["sha"] or
            result.get("ref")!="refs/heads/"+build["branch"] or
            (result.get("base") is not None and result["base"]!=group.get("base"))):
        raise ValueError("The Branch Review handoff differs from this group.")
    return dict(result,**{"url":target["url"]})


def approved_review(root, state, build, group):
    result = group_review(root,state,build,group)
    if (result.get("status")!="approved" or result.get("reviewedCommit")!=group["sha"] or
            not result.get("reviewId") or not (result.get("approval") or {}).get("reviewer") or
            [s.get("id") for s in result.get("slices", [])] != group["slices"] or
            not result.get("checklist") or result.get("findings") or
            any(c.get("status") not in ("passed","not-applicable") for c in result["checklist"])):
        raise ValueError(result.get("message") or "Complete and approve this exact commit in Branch Review.")
    return result


def push_approved(root, state, build, group, saved, expected_target):
    result = approved_review(root,state,build,group)
    if saved.get("reviewId")!=result["reviewId"] or saved.get("runId")!=result["runId"]:
        raise ValueError("The Branch Review decision changed. Refresh the group.")
    if not expected_target or expected_target != result.get("pushTarget"):
        raise ValueError("The GitHub destination changed. Refresh the group and confirm its destination.")
    origin = origin_for(root,state)
    token = request(origin,"/api/state").get("token")
    if not token:
        raise ValueError("Reconnect Branch Review before pushing.")
    pushed = request(origin,"/api/workbench-push",{"runId":result["runId"],"commit":group["sha"],"expectedTarget":expected_target},token).get("result",{})
    if pushed.get("commit")!=group["sha"] or pushed.get("ref")!=result["ref"] or pushed.get("repository")!=expected_target:
        raise ValueError("Branch Review could not confirm the requested remote branch.")
    return pushed
