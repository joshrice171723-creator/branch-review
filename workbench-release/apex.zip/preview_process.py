"""Own one explicitly started project preview and its process group."""
from contextlib import ExitStack
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import sys
import threading
from urllib.parse import urlsplit

from audited_flow import owned
from chat_workflow import load, write_json
from design_progress import running
from project_command import resolve_argv
from workflow_job import WindowsProcessGroup, process_group


LOG_BYTES = 64 * 1024


def listening(url):
    if not url:
        return False
    address = urlsplit(url)
    hosts = ("127.0.0.1", "::1") if address.hostname == "localhost" else (address.hostname,)
    for host in hosts:
        try:
            with socket.create_connection((host, address.port), timeout=0.25):
                return True
        except OSError:
            pass
    return False


class PreviewProcess:
    def __init__(self, project):
        self.project = Path(project).resolve(strict=True)
        self.folder = self.project / ".harness" / "design" / "preview-process"
        self.settings_path = self.folder / "settings.json"
        self.log_path = self.folder / "preview.log"
        self.owner_path = self.folder / "owner"
        self.lock = threading.RLock()
        self.child = None
        self.group = None
        self.owner = None
        self.exit_code = None

    def confined(self, path):
        if path.resolve() != path:
            raise ValueError("The preview files must belong to this project.")
        return path

    def directory(self, value):
        if not isinstance(value, str) or not value.strip() or "\0" in value or Path(value).is_absolute():
            raise ValueError("Enter a preview directory relative to this project.")
        target = (self.project / value).resolve()
        if not target.is_relative_to(self.project) or not target.is_dir():
            raise ValueError("The preview directory must be inside this project.")
        return target

    def validated(self, payload):
        if not isinstance(payload, dict):
            raise ValueError("Save the preview command first.")
        argv = payload.get("argv")
        if (not isinstance(argv, list) or not argv or
                not all(isinstance(value, str) and "\0" not in value for value in argv) or not argv[0].strip()):
            raise ValueError("Enter a preview executable and its arguments.")
        cwd = self.directory(payload.get("cwd", "."))
        url = payload.get("url", "")
        if not isinstance(url, str) or any(ord(char) <= 32 or ord(char) == 127 for char in url):
            raise ValueError("Enter a local HTTP preview address with its port.")
        if not url:
            return dict(argv=argv, cwd=cwd.relative_to(self.project).as_posix(), url="")
        try:
            address = urlsplit(url)
            if (address.scheme != "http" or address.hostname not in {"127.0.0.1", "localhost", "::1"} or
                    not address.port or address.username is not None or address.password is not None):
                raise ValueError()
        except ValueError as exc:
            raise ValueError("Enter a local HTTP preview address with its port.") from exc
        return dict(argv=argv, cwd=cwd.relative_to(self.project).as_posix(), url=url)

    def settings(self):
        value = load(self.confined(self.settings_path))
        return self.validated(value) if value is not None else None

    def owner_folder(self):
        return self.confined(self.owner_path / "run.lock").parent

    def log(self):
        try:
            with self.confined(self.log_path).open("rb") as stream:
                stream.seek(max(0, stream.seek(0, os.SEEK_END) - LOG_BYTES))
                return stream.read(LOG_BYTES).decode("utf-8", errors="replace")
        except FileNotFoundError:
            return ""

    def status(self):
        with self.lock:
            settings = self.settings()
            if not settings:
                return dict(settings=None, state="unconfigured", owned=False, url="", log="")
            url = settings["url"]
            ready = listening(url)
            if self.child is not None and self.child.poll() is not None:
                self.reap(self.child)
            if self.child is not None:
                state = "running" if ready or not url else "starting"
            elif ready:
                state = "external"
            elif running(self.owner_folder()):
                state = "starting"
            else:
                state = "exited" if self.exit_code is not None else "stopped"
            result = dict(settings=settings, state=state, owned=self.child is not None, url=url, log=self.log())
            if self.exit_code is not None:
                result["exitCode"] = self.exit_code
            return result

    def setup(self, payload):
        settings = self.validated(payload)
        with self.lock:
            if self.child is not None and self.child.poll() is not None:
                self.reap(self.child)
            if self.child is not None:
                raise ValueError("Stop the managed preview before changing its settings.")
            with ExitStack() as stack:
                try:
                    stack.enter_context(owned(self.owner_folder()))
                except (BlockingIOError, PermissionError) as exc:
                    raise ValueError("Stop the managed preview before changing its settings.") from exc
                write_json(self.confined(self.settings_path), settings)
                self.exit_code = None
            return self.status()

    def command(self, argv, cwd):
        argv = resolve_argv(argv)
        first = argv[0]
        executable = shutil.which(first if not any(sep in first for sep in ("/", "\\")) else str(cwd / first))
        if not executable:
            raise ValueError("The preview executable was not found.")
        if os.name == "nt" and Path(executable).suffix.lower() in {".bat", ".cmd"}:
            raise ValueError("Use a native preview executable with literal arguments.")
        return [executable, *argv[1:]]

    def start(self):
        with self.lock, ExitStack() as stack:
            if self.child is not None:
                if self.child.poll() is None:
                    return self.status()
                self.reap(self.child)
            try:
                stack.enter_context(owned(self.owner_folder()))
            except (BlockingIOError, PermissionError):
                return self.status()
            settings = self.settings()
            if not settings:
                raise ValueError("Save the preview command and address first.")
            if not listening(settings["url"]):
                self.spawn(settings)
                self.owner = stack.pop_all()
                self.exit_code = None
                threading.Thread(target=self.wait, args=(self.child,), daemon=True).start()
        return self.status()

    def spawn(self, settings):
        cwd = self.directory(settings["cwd"])
        command = self.command(settings["argv"], cwd)
        windows = os.name == "nt"
        flags = process_group()
        if windows:
            flags["creationflags"] |= subprocess.CREATE_NO_WINDOW
        with self.confined(self.log_path).open("wb") as log:
            child = subprocess.Popen([sys.executable, "-X", "utf8", str(Path(__file__).resolve()), "--owned-preview"]
                                     if windows else command, cwd=cwd, stdin=subprocess.PIPE if windows else subprocess.DEVNULL,
                                     stdout=log, stderr=subprocess.STDOUT, **flags)
        try:
            if windows:
                self.group = WindowsProcessGroup(child)
                with child.stdin:
                    child.stdin.write(json.dumps(command).encode("utf-8") + b"\n")
        except (OSError, ValueError):
            child.kill()
            child.wait()
            if self.group:
                self.group.close()
                self.group = None
            raise
        self.child = child

    def wait(self, child):
        child.wait()
        with self.lock:
            if self.child is child:
                self.reap(child)

    def reap(self, child):
        self.exit_code = child.returncode
        self.child = None
        try:
            if self.group:
                self.group.terminate()
        finally:
            if self.group:
                self.group.close()
                self.group = None
            self.owner.close()
            self.owner = None

    def close(self):
        with self.lock:
            child = self.child
            if child is None:
                return
            if child.poll() is None:
                if self.group:
                    self.group.terminate()
                else:
                    try:
                        os.killpg(child.pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass
                try:
                    child.wait(timeout=4)
                except subprocess.TimeoutExpired:
                    if self.group:
                        self.group.terminate()
                    else:
                        try:
                            os.killpg(child.pid, signal.SIGKILL)
                        except ProcessLookupError:
                            pass
                    child.wait(timeout=4)
            self.reap(child)
            self.exit_code = None

    def stop(self):
        self.close()
        return self.status()


if __name__ == "__main__" and sys.argv[1:] == ["--owned-preview"]:
    command = sys.stdin.buffer.readline()
    if command:
        raise SystemExit(subprocess.call(json.loads(command), stdin=subprocess.DEVNULL))
