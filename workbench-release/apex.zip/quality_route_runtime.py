"""Refresh realized route metadata from an explicitly selected Rails application."""
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
from tempfile import TemporaryFile
from time import monotonic, sleep

from workflow_job import WindowsProcessGroup, process_group


TIMEOUT_SECONDS = 120
MAX_OUTPUT = 2 * 1024 * 1024
MAX_ROUTES = 1500
MAX_DIRECTORIES = 5000
MARKER = b"WORKBENCH_RAILS_ROUTES "
SKIP = {"node_modules", "vendor", "tmp", "log", "storage", "coverage", "build", "dist"}
METHOD = re.compile(r"[A-Z][A-Z0-9-]{0,23}|\*")

RUNNER = r'''
require "json"
limit = __MAX_ROUTES__
rows = []
omitted = false
Rails.application.routes.routes.each do |route|
  verb = route.verb.to_s
  methods = verb.empty? ? ["*"] : verb.scan(/\b[A-Z][A-Z0-9-]*\b/).uniq
  omitted ||= methods.empty?
  methods.each do |method|
    if rows.length == limit
      omitted = true
      break
    end
    rows << {method: method, path: route.path.spec.to_s, controller: route.defaults[:controller]&.to_s,
             action: route.defaults[:action]&.to_s, name: route.name&.to_s}
  end
  break if rows.length == limit && omitted
end
STDOUT.binmode
STDOUT.write("\nWORKBENCH_RAILS_ROUTES " + JSON.generate({routes: rows, omitted: omitted}) + "\n")
'''.replace("__MAX_ROUTES__", str(MAX_ROUTES))


def rails_root(project, app):
    def is_app(directory):
        return all(path.is_file() and path.resolve().is_relative_to(directory)
                   for path in (directory / "bin" / "rails", directory / "config" / "application.rb"))

    if app is not None:
        if not isinstance(app, str) or not app.strip() or "\0" in app or Path(app).is_absolute():
            raise ValueError("Select a Rails app directory relative to this project.")
        directory = (project / app).resolve()
        if not directory.is_relative_to(project) or not is_app(directory):
            raise ValueError("Select a Rails app in this project with bin/rails and config/application.rb.")
        return directory
    if is_app(project):
        return project
    matches = []
    for number, (path, children, _) in enumerate(os.walk(project), start=1):
        if number > MAX_DIRECTORIES:
            raise ValueError("Select a Rails app directory to avoid scanning the whole project.")
        directory = Path(path)
        children[:] = [name for name in children if not name.startswith(".") and name not in SKIP
                       and not (directory / name).is_symlink()]
        if directory.resolve() == directory and is_app(directory):
            matches.append(directory)
            if len(matches) > 1:
                raise ValueError("Select a Rails app directory. This project contains multiple Rails apps.")
            children.clear()
    if not matches:
        raise ValueError("Rails runtime routes require an app with bin/rails and config/application.rb.")
    return matches[0]


def capture(command, cwd):
    """Bound the boot time and output of the local Rails runner."""
    flags = process_group()
    if os.name == "nt":
        flags["creationflags"] |= subprocess.CREATE_NO_WINDOW
    deadline = monotonic() + TIMEOUT_SECONDS
    environment = dict(os.environ, RAILS_ENV="development", RACK_ENV="development")
    environment.pop("BUNDLE_GEMFILE", None)
    with TemporaryFile() as output:
        with subprocess.Popen(command, cwd=cwd, stdin=subprocess.DEVNULL, stdout=output,
                              stderr=subprocess.STDOUT, env=environment, **flags) as proc:
            group = None
            try:
                if os.name == "nt":
                    try:
                        group = WindowsProcessGroup(proc)
                    except OSError:
                        if proc.poll() is None:
                            raise
                while proc.poll() is None:
                    if os.fstat(output.fileno()).st_size > MAX_OUTPUT:
                        raise ValueError("Rails startup exceeded the route refresh output limit.")
                    if monotonic() >= deadline:
                        raise subprocess.TimeoutExpired(command, TIMEOUT_SECONDS)
                    sleep(0.04)
            finally:
                if group:
                    try:
                        group.terminate()
                    finally:
                        group.close()
                elif proc.poll() is None:
                    if os.name == "nt":
                        proc.kill()
                    else:
                        try:
                            os.killpg(proc.pid, signal.SIGKILL)
                        except ProcessLookupError:
                            pass
        output.seek(0)
        result = output.read(MAX_OUTPUT + 1)
        if len(result) > MAX_OUTPUT:
            raise ValueError("Rails startup exceeded the route refresh output limit.")
        return proc.returncode, result


def boot_warning(output):
    if any(marker in output for marker in (b"Bundler::GemNotFound", b"Gem::MissingSpec", b"Could not find gem", b"LoadError")):
        return "Rails could not load its local dependencies. Check the bundle and refresh routes again."
    if any(marker in output for marker in (b"ActiveRecord::ConnectionNotEstablished", b"ActiveRecord::NoDatabaseError",
                                           b"PG::ConnectionBad", b"Mysql2::Error::ConnectionError", b"SQLite3::CantOpenException")):
        return "Rails could not open its development database. Start the local database or check its configuration."
    return "Rails could not boot in development. Check startup with ruby bin/rails routes from the selected app."


def discover_rails_runtime(project, *, app=None):
    """Boot a local development app for metadata. The caller keeps source results on failure."""
    def fallback(message):
        return dict(verified=False, routes=[], warnings=[message])

    try:
        project = Path(project).resolve(strict=True)
        directory = rails_root(project, app)
        ruby = shutil.which("ruby")
        if not ruby:
            return fallback("Ruby was not found on PATH. Configure the local Rails runtime and refresh routes again.")
        code, output = capture([ruby, "bin/rails", "runner", "-e", "development", RUNNER], directory)
        if code:
            return fallback(boot_warning(output))
        receipt = next((line[len(MARKER):] for line in reversed(output.splitlines()) if line.startswith(MARKER)), None)
        if receipt is None:
            return fallback("Rails did not return route metadata. Check the selected app's local Rails runner.")
        data = json.loads(receipt)
        if (not isinstance(data, dict) or not isinstance(data.get("routes"), list) or len(data["routes"]) > MAX_ROUTES or
                not isinstance(data.get("omitted"), bool)):
            return fallback("Rails returned invalid route metadata.")
        app_root = directory.relative_to(project).as_posix()
        routes = []
        for row in data["routes"]:
            if (not isinstance(row, dict) or not isinstance(row.get("method"), str) or not METHOD.fullmatch(row["method"]) or
                    not isinstance(row.get("path"), str) or not row["path"].startswith("/") or
                    any(row.get(key) is not None and not isinstance(row[key], str) for key in ("controller", "action", "name"))):
                return fallback("Rails returned invalid route metadata.")
            routes.append(dict(method=row["method"], path=row["path"], controller=row.get("controller"),
                               action=row.get("action"), name=row.get("name"), app_root=app_root))
        warnings = ["Rails returned a bounded route list. Some realized routes were omitted."] if data["omitted"] else []
        return dict(verified=True, routes=routes, warnings=warnings)
    except subprocess.TimeoutExpired:
        return fallback("Rails route refresh timed out. Check the selected app's development startup.")
    except json.JSONDecodeError:
        return fallback("Rails returned invalid route metadata.")
    except ValueError as exc:
        return fallback(str(exc))
    except OSError:
        return fallback("The local Rails runner could not start. Check Ruby and the selected app directory.")
