"""Exercise installed profiles, coordinator receipts, public activity, and the mounted API."""
from contextlib import contextmanager
import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from zipfile import ZipFile

from activity import page
from audited_flow import Runtime, read, run
from server import create_server


ROOT = Path(__file__).resolve().parent
DECISIONS = dict(scope_confirmed="confirmed", code_changes="allow_scoped", migrations="deny",
                 dependencies="deny", engine_integration="confirmed")

# Both providers start with "exec". Python executes this fixture from the project directory.
AGENT = '''import json, sys, time
from pathlib import Path
home = Path(".harness")
args = sys.argv[1:]
muse = "--prompt-file" in args
if muse and (home / "provider-failure").exists():
    print("unauthorized PRIVATE-PROVIDER-TEXT", file=sys.stderr)
    sys.exit(7)
prompt = Path(args[args.index("--prompt-file")+1]).read_text(encoding="utf-8") if muse else sys.stdin.read()
stage = next((s for s in ("planReview","buildReview","finalReview","build","plan")
              if "ASSIGNED-" + s + "!" in prompt), None)
assert stage, "No stage assignment delivered"
with (home / "calls.jsonl").open("a", encoding="utf-8") as calls:
    calls.write(json.dumps(dict(stage=stage, args=args, prompt=prompt)) + "\\n")
def emit(event):
    print(json.dumps(event), flush=True)
if muse:
    emit(dict(payload_type="turn.input.user", payload=dict(prompt="PRIVATE-INPUT")))
    emit(dict(payload_type="run.model.configured", payload=dict(model_id="muse-spark-1.3")))
else:
    emit(dict(type="thread.started"))
if (home / ("hold-" + stage)).exists():
    start = time.monotonic()
    while not (home / ("release-" + stage)).exists():
        if time.monotonic()-start > 60: raise RuntimeError("Activity was not delivered")
        time.sleep(.05)
if stage == "plan":
    reply = {"question":"Which label?"} if (home / "question").exists() and '["Which label?", "Blue"]' not in prompt else {"plan":"Write the label"}
    if "Supply answers for the existing question" in prompt:
        choices = json.loads((home / "candidate-labels.json").read_text())
        assert all(label in prompt for label in choices)
        reply = {"question": "Which label?", "suggestions": choices}
elif stage == "build":
    assert "--sandbox" in args and "workspace-write" in args
    Path("result.txt").write_text("Blue")
    reply = "Wrote result.txt"
else:
    schema = json.loads(Path(args[args.index("--output-schema")+1]).read_text())
    reply = {"verdict":"pass","reason":"Checked the label"}
    if "criteria" in schema["properties"]:
        reply["criteria"] = [dict(id=row["id"],verdict="pass",evidence=["result.txt contains Blue"],reason="Checked")
                              for row in json.loads((home/"templates/REVIEW.json").read_text())["criteria"]]
text = reply if isinstance(reply,str) else json.dumps(reply)
if muse:
    emit(dict(payload_type="run.terminal.completed",payload=dict(text=text)))
else:
    emit(dict(type="item.completed",item=dict(type="agent_message",text=text)))
    emit(dict(type="turn.completed"))
'''


def cli(root, *args, ok=True, script=None):
    executable = script or root / ".harness/bin/harness"
    result = subprocess.run(["ruby", str(executable), *args, "--project", str(root)], cwd=root,
                            capture_output=True, encoding="utf-8", timeout=60)
    if not ok:
        return result
    if result.returncode:
        raise AssertionError(result.stderr + result.stdout)
    return json.loads(result.stdout)


def write_json(path, value):
    path.write_text(json.dumps(value), encoding="utf-8")
    return str(path)


def setup(root, mode="fast"):
    cli(root, "setup", "install", script=ROOT / "bin/harness")
    home = root / ".harness"
    (root / "exec").write_text(AGENT, encoding="utf-8")
    settings = read(home / "project.json")
    settings["checks"] = [dict(name="label", argv=["ruby", "-e",
        "abort unless File.read('result.txt') == 'Blue' && !File.exist?('.harness/fail')"],
        required=True, benchmark=False, phases=["after"])]
    cli(root, "setup", "configure", "--file", write_json(home / "settings.json", settings))
    profile = cli(root, "setup", "profile-export")
    profile["active"] = mode
    profile["permittedTools"] = ["app_label"]
    for selected in profile["profiles"].values():
        selected["rules"] += " SHARED-RULE"
        for stage, spec in selected["stages"].items():
            spec["instructions"] += " ASSIGNED-" + stage + "!"
            if spec["provider"] == "Muse":
                spec["model"] = "muse-spark-1.3"
    # A stage-only attachment has a different marker from its instruction.
    profile["documents"].append(dict(id="local", name="Label", filename="label.md",
                                     source="Upload", content="AUDITOR-DOCUMENT"))
    profile["profiles"][mode]["stages"]["buildReview"]["docs"].append("local")
    return profile


def apply(root, profile):
    return cli(root, "setup", "profile-import", "--file", write_json(root / ".harness/import.json", profile))


def start(root):
    return cli(root, "build", "--action", "Write label", "--scope", "result.txt",
               "--file", write_json(root / ".harness/answers.json", DECISIONS))["task_id"]


@contextmanager
def service(root):
    server = create_server(root, 0, sys.executable, bound=True)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield "http://127.0.0.1:" + str(server.server_port) + "/__workbench/"
    finally:
        server.shutdown()
        server.server_close()
        thread.join()


def request(base, path, data=None, token=""):
    body = json.dumps(data).encode() if data is not None else None
    req = Request(base + path, data=body, headers={"Content-Type": "application/json", "X-CSRF-Token": token})
    with urlopen(req, timeout=60) as response:
        raw = response.read()
        return json.loads(raw) if raw and "application/json" in response.headers.get("Content-Type", "") else raw


class PortablePanel(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        self.home = self.root / ".harness"
        env = patch.dict(os.environ, {"APEX_MUSE_EXECUTABLE": sys.executable})
        env.start()
        self.addCleanup(env.stop)

    def test_fast_finish_with_final_review_disabled(self):
        profile = setup(self.root)
        self.assertEqual(apply(self.root, profile), profile)
        tid = start(self.root)
        rt = Runtime(self.root, tid, sys.executable)
        updated = copy.deepcopy(profile)
        updated["active"] = "audited"
        apply(self.root, updated)
        self.assertEqual(rt.task["profile"], profile)
        invalid = copy.deepcopy(updated)
        invalid["profiles"]["audited"]["stages"]["buildReview"]["enabled"] = False
        result = cli(self.root, "setup", "profile-import", "--file", write_json(self.home / "bad.json", invalid), ok=False)
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(cli(self.root, "setup", "profile-export"), updated)
        original_cli = rt.cli

        # Copy the live ledger before the irreversible finish transition.
        with tempfile.TemporaryDirectory() as tmp:
            clone = Path(tmp).resolve() / "app"
            def capture(args, **kwargs):
                if args[:2] == ["task", "finish"]:
                    shutil.copytree(self.root, clone, ignore=shutil.ignore_patterns("run.lock"))
                return original_cli(args, **kwargs)
            with patch.object(rt, "cli", side_effect=capture):
                self.assertIn("Completed", run(rt))
            self.assert_fast_gates(Runtime(clone, tid, sys.executable))
        history = cli(self.root, "runs", "show", tid)
        self.assertEqual(history["lifecycle"]["status"], "completed")
        self.assertEqual([row["verdict"] for row in history["audits"]], ["pass", "pass", "skipped"])
        self.assertEqual(len(history["audits"][1]["criteria"]), 6)
        self.assertEqual(history["ledger"]["verdict"], "pass")
        calls = [json.loads(s) for s in (self.home / "calls.jsonl").read_text().splitlines()]
        self.assertEqual([c["stage"] for c in calls], ["plan", "planReview", "build", "buildReview"])
        for call in calls:
            self.assertIn("SHARED-RULE", call["prompt"])
            self.assertIn("Workbench runs scheduled checks", call["prompt"])
            self.assertNotIn("Run verify and report all failed or missing gates.", call["prompt"])
            self.assertEqual("AUDITOR-DOCUMENT" in call["prompt"], call["stage"] == "buildReview")
            model = "muse-spark-1.3" if call["stage"].endswith("Review") else "gpt-6.2-astra"
            self.assertIn(model, call["args"])

    def assert_fast_gates(self, rt):
        def blocked(issue):
            result = rt.cli(["task", "finish"], required=False)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn(issue, result.stderr)
        review = read(rt.folder / "review.json")
        incomplete = dict(review, criteria=review["criteria"][:-1])
        bad = ["internal", "review", "--file", write_json(rt.home / "bad.json", incomplete)]
        self.assertNotEqual(rt.cli(bad, required=False).returncode, 0)
        blocked("no evidence")
        rt.cli(["internal", "review", "--file", str(rt.folder / "review.json")])
        (rt.project / "result.txt").write_text("Red")
        blocked("different source snapshot")
        (rt.project / "result.txt").write_text("Blue")
        (rt.home / "fail").touch()
        self.assertFalse(rt.check("after")[0]["ok"])
        blocked("check failed")
        (rt.home / "fail").unlink()
        self.assertTrue(rt.check("after")[0]["ok"])
        skip = read(rt.folder / "skip.json")
        self.assertNotEqual(rt.cli(["internal", "audit-step", "--file",
            write_json(rt.home / "bad.json", dict(skip, profile_sha256="0"*64))], required=False).returncode, 0)
        rt.cli(["internal", "audit-step", "--file", write_json(rt.home / "bad.json", dict(skip, plan_sha256="0"*64))])
        blocked("reviewed plan")

    def test_native_question_resume_and_live_cursor(self):
        profile = setup(self.root)
        profile["profiles"]["fast"]["stages"]["finalReview"]["enabled"] = True
        for name in ("question", "hold-plan", "hold-planReview"):
            (self.home / name).touch()
        write_json(self.home / "candidate-labels.json", ["Blue", "Amber"])
        with service(self.root) as base:
            state = request(base, "api/state")
            post = lambda path, body: request(base, path, body, state["csrf_token"])
            post("api/profile", profile)
            for mode in ("audit", "refactor"):
                with self.assertRaises(HTTPError) as failure:
                    post("api/task", dict(mode=mode, action="Read label", scope="result.txt"))
                self.assertIn(f"both baseline and after phases for {mode}: label", failure.exception.read().decode())
            self.assertEqual(request(base, "api/state")["runs"], [])
            self.assertFalse((self.home / "active_task").exists())
            tid = post("api/task", dict(mode="build", action="Write label", scope="result.txt; candidate labels Blue and Amber",
                                        answers=DECISIONS))["created"]["data"]["task_id"]
            cursor, received = 0, []
            def wait_for(predicate):
                nonlocal cursor
                deadline = time.monotonic() + 150
                while time.monotonic() < deadline:
                    chunk = request(base, f"api/events?id={tid}&after={cursor}")
                    received.extend(chunk["events"])
                    cursor = chunk["cursor"]
                    if predicate():
                        return
                    time.sleep(.1)
                self.fail("Timed out waiting for stage or public activity")
            def done(job):
                info = request(base, "api/job?id=" + job["id"])
                self.assertNotEqual(info["state"], "failed", info.get("error"))
                return info["state"] == "completed"
            job = post("api/chat", {"message": "/run"})
            wait_for(lambda: any(e["activity"] == "Session started" for e in received))
            self.assertFalse(done(job))
            post("api/chat/cancel", {"id": job["id"]})
            wait_for(lambda: request(base, "api/job?id=" + job["id"])["state"] == "cancelled")
            self.assertTrue(any(e["stage"] == "plan" and e["activity"] == "Run cancelled" for e in
                                request(base, f"api/events?id={tid}")["events"]))
            (self.home / "release-plan").touch()
            job = post("api/chat", {"message": "/run"})
            wait_for(lambda: done(job))
            pending = request(base, "api/state")["active_task"]
            self.assertEqual((pending["id"], pending["loop_stage"], pending["question"]), (tid, "question", "Which label?"))
            job = post("api/chat", {"message": "Blue"})
            wait_for(lambda: any(e["stage"] == "plan_review" and "muse-spark-1.3" in e["activity"] for e in received))
            self.assertFalse(done(job))
            (self.home / "release-planReview").touch()
            wait_for(lambda: done(job))
            wait_for(lambda: received[-1]["stage"] == "completed")
            self.assertEqual(received, page(self.root, tid, 0)["events"])
            self.assertEqual(len(received), len({e["cursor"] for e in received}))
            self.assertNotIn("PRIVATE-INPUT", json.dumps(received))
            self.assertNotIn("AUDITOR-DOCUMENT", json.dumps(received))
            self.assertTrue(any(e["stage"] == "final_review" and e["actor"] == "Muse" for e in received))
            history = cli(self.root, "runs", "show", tid)
            self.assertEqual(history["lifecycle"]["status"], "completed")
            self.assertEqual(history["audits"][-1]["verdict"], "pass")

    def test_audited_rejects_skip(self):
        profile = setup(self.root, "audited")
        stages = profile["profiles"]["audited"]["stages"]
        stages["plan"]["provider"] = "Muse"
        stages["plan"]["model"] = ""
        efforts = {"plan": "low", "planReview": "medium", "buildReview": "high", "finalReview": "xhigh"}
        for stage, effort in efforts.items():
            stages[stage]["effort"] = effort
        apply(self.root, profile)
        rt = Runtime(self.root, start(self.root), sys.executable)
        # Resolve the default command once through PATH, including the Windows .cmd launcher.
        if os.name == "nt":
            (self.home / "muse.cmd").write_text(f'@"{sys.executable}" %*\n', encoding="utf-8")
        else:
            (self.home / "muse").symlink_to(sys.executable)
        agent = rt.agent
        def probe(stage, prompt, write=False):
            if stage == "plan_review":
                with patch.dict(os.environ, {"APEX_MUSE_EXECUTABLE": "", "PATH": str(self.home) + os.pathsep + os.environ["PATH"]}):
                    (self.home / "provider-failure").touch()
                    with self.assertRaisesRegex(ValueError, "Muse exited with code 7 during plan_review. Authentication failed.") as failure:
                        agent(stage, prompt, write)
                    self.assertNotIn("PRIVATE-PROVIDER-TEXT", str(failure.exception))
                    (self.home / "provider-failure").unlink()
            if stage == "final_review":
                skip = dict(read(rt.folder / "audit.json"), stage=stage, verdict="skipped")
                attempt = rt.cli(["internal", "audit-step", "--file", write_json(self.home / "skip.json", skip)], required=False)
                self.assertIn("Skip conflicts", attempt.stderr)
                self.assertNotEqual(rt.cli(["task", "finish"], required=False).returncode, 0)
            return agent(stage, prompt, write)
        with patch.object(rt, "agent", side_effect=probe):
            self.assertIn("Completed", run(rt))
        calls = [json.loads(line) for line in (self.home / "calls.jsonl").read_text().splitlines()]
        muse_calls = [call for call in calls if "--prompt-file" in call["args"]]
        self.assertEqual([call["stage"] for call in muse_calls], list(efforts))
        for call in muse_calls:
            with self.subTest(stage=call["stage"]):
                args = call["args"]
                self.assertEqual(args.count("--reasoning-effort"), 1)
                index = args.index("--reasoning-effort")
                self.assertEqual(args[index + 1:index + 2], [efforts[call["stage"]]])

    def test_pinned_feedback_routes_and_limits(self):
        from test_audited_flow import FakeRuntime
        from audited_flow import return_to
        profile = json.loads(subprocess.check_output(["node", str(ROOT / "portable/profile.cjs"), "default"]))
        rt = FakeRuntime(self.root)
        rt.task["profile"] = profile
        stages = profile["profiles"]["audited"]["stages"]
        state = dict(stage="plan_review", history=[], returns={})
        stages["planReview"]["limit"] = 1
        with patch.object(rt, "cli", wraps=rt.cli) as invoked:
            return_to(rt, state, "plan_review", "replan", "Missing scope")
            self.assertEqual(state["stage"], "plan")
            stages["buildReview"]["route"] = "plan"
            return_to(rt, state, "build_review", "repair", "Change the plan")
            self.assertEqual(state["stage"], "plan")
            return_to(rt, state, "final_review", "repair", "Repair output")
            self.assertEqual(state["stage"], "build")
            self.assertIn(["task", "repair-round", "--reason", "Repair output"], [c.args[0] for c in invoked.call_args_list])
            return_to(rt, state, "plan_review", "replan", "Still missing scope")
            self.assertEqual(state["stage"], "stopped")
        events = [json.loads(line) for line in (rt.folder / "activity.jsonl").read_text().splitlines()]
        self.assertEqual([e["stage"] for e in events if e["activity"].startswith("Finding")],
                         ["plan_review", "build_review", "final_review"])

    def test_packaged_mount_settings_tools_and_project_isolation(self):
        archive = self.root / "kit.zip"
        kit = self.root / "kit"
        donor = self.root / "donor"
        donor.mkdir()
        exported = setup(donor)
        preset_files = {doc["filename"] for doc in exported["documents"] if doc["source"] != "Upload"}
        self.assertEqual(preset_files, {"TASK_EXECUTION_STANDARD.md", "STANDARDS.md", "PERFORMANCE.md", "REVIEW.md"})
        apply(donor, exported)
        subprocess.run([sys.executable, str(ROOT / "portable/package.py"), str(archive),
                        "--project", str(donor)], check=True)
        with ZipFile(archive) as package:
            package.extractall(kit)
            entries = {line.split("  ", 1)[1]: line[:64] for line in
                       package.read("MANIFEST.sha256").decode().splitlines()}
            self.assertEqual(set(package.namelist()), set(entries) | {"MANIFEST.sha256"})
            for name, digest in entries.items():
                content = (kit / name).read_bytes()
                self.assertEqual(hashlib.sha256(content).hexdigest(), digest, name)
                self.assertNotIn(str(ROOT).encode(), content, name)
                self.assertNotIn(".harness", Path(name).parts)
        first, second = self.root / "first", self.root / "second"
        installer = kit / "bin/harness"
        for root in (first, second):
            root.mkdir()
            cli(root, "setup", "install", script=installer)
        self.assertEqual(read(kit / "project-profile.json"), exported)
        cli(first, "setup", "profile-import", "--file", str(kit / "project-profile.json"), script=installer)
        other = start(second)
        owner = start(first)
        tasks = first / ".harness/tasks"
        def records():
            return {p.relative_to(tasks): p.read_bytes() for p in tasks.rglob("*") if p.is_file()}
        before = records()
        for _ in range(2):
            cli(first, "setup", "install", script=installer)
            self.assertEqual(before, records())
        registry = first / "tools.cjs"
        registry.write_text("""
const fs = require("node:fs");
module.exports = ["app_label", "app_hidden"].map(name => ({
  name, description: "Record the selected test label",
  inputSchema: {type: "object", properties: {label: {type: "string", enum: ["blue"]}},
    required: ["label"], additionalProperties: false},
  handle({label}) {fs.appendFileSync(".harness/calls.txt", label); return {label};}
}));""")
        # The host keeps its original route and delegates the panel prefix.
        host = first / "host.cjs"
        host.write_text("""
const http = require("node:http");
const {mountWorkbench} = require("./.harness/portable/mount.cjs");
mountWorkbench(".", {appTools: "tools.cjs"}).then(panel => {
  const server = http.createServer((req, res) => {
    if (!panel.handle(req, res)) res.end("Factory host");
  });
  server.listen(0, "127.0.0.1", () => console.log(server.address().port));
  process.stdin.resume();
  process.stdin.on("end", () => {panel.close(); server.close();});
});""")
        env = dict(os.environ, HARNESS_PYTHON=sys.executable)
        with subprocess.Popen(["node", str(host)], cwd=first, env=env, stdin=subprocess.PIPE,
                              stdout=subprocess.PIPE, text=True, encoding="utf-8") as proc:
            try:
                port = int(proc.stdout.readline())
                origin = "http://127.0.0.1:" + str(port) + "/"
                self.assertEqual(request(origin, ""), b"Factory host")
                base = origin + "__workbench/"
                panel = request(base, "")
                self.assertIn(b"Live run", panel)
                self.assertIn(b"<title>Workbench</title>", panel)
                self.assertNotIn(b"factory", panel.lower())
                for asset in ["app.js", "profile.js", "live.js", "models.js", "mcp-client.js", "design.js"]:
                    script = request(base, asset)
                    self.assertEqual(script, (kit / "web/panel" / asset).read_bytes())
                    self.assertNotIn(b"factory", script.lower(), asset)
                from io import BytesIO
                with ZipFile(BytesIO(request(base, "api/package"))) as installed_kit:
                    self.assertEqual(json.loads(installed_kit.read("project-profile.json")), exported)
                    self.assertEqual(installed_kit.namelist().count("project-profile.json"), 1)
                state = request(base, "api/state")
                request(base, "api/design/draft", dict(revision=0, plan="Mounted draft", roadmap=[]), state["csrf_token"])
                request(base, "api/design/layout", dict(name="panes", value="stack"), state["csrf_token"])
                self.assertEqual(request(base, "api/design")["plan"], "Mounted draft")
                hosts = first / ".harness/hosts"
                hosts.mkdir(exist_ok=True)
                write_json(hosts / "app.json", dict(version=1, name="Local app", url=origin))
                self.assertEqual(request(base, "api/design/preview")["url"], origin)
                with subprocess.Popen([sys.executable, str(kit / "server.py"), "--project", str(second), "--port", "0"],
                                      stdout=subprocess.PIPE, text=True) as standalone:
                    try:
                        address = standalone.stdout.readline().strip().split()[-1] + "/"
                        with urlopen(address + "__workbench/") as landing:
                            second_panel = landing.geturl()
                        other_state = request(second_panel, "api/state")
                        self.assertEqual(request(second_panel, "design.js"), (kit / "web/panel/design.js").read_bytes())
                        self.assertEqual(request(second_panel, "api/design")["revision"], 0)
                        request(second_panel, "api/design/draft", dict(revision=0, plan="Standalone draft", roadmap=[]),
                                other_state["csrf_token"])
                        request(second_panel, "api/design/layout", dict(name="panes", value="beside"), other_state["csrf_token"])
                        self.assertEqual(request(base, "api/design")["plan"], "Mounted draft")
                        for selected in (first, second, first, second):
                            selected_state = request(address, "api/project", {"path": str(selected)}, other_state["csrf_token"])
                            other_state = selected_state
                            with urlopen(address + "__workbench/") as landing:
                                selected_panel = landing.geturl()
                            expected = "Mounted draft" if selected == first else "Standalone draft"
                            self.assertEqual(request(selected_panel, "api/state")["design_layout"]["panes"],
                                             "stack" if selected == first else "beside")
                            self.assertEqual(request(selected_panel, "api/design")["plan"], expected)
                            self.assertEqual(request(selected_panel, "api/design/preview")["url"], origin if selected == first else "")
                    finally:
                        standalone.terminate()
                        standalone.wait(timeout=10)
                self.assertEqual(state["project"]["label"], first.name)
                self.assertEqual(state["config"]["engine"]["version"], read(first / ".harness/project.json")["engine"]["version"])
                self.assertEqual([row["id"] for row in state["runs"]], [owner])
                with self.assertRaises(HTTPError):
                    request(base, "api/project", {"path": str(second)}, state["csrf_token"])
                with self.assertRaises(HTTPError):
                    request(base, "api/events?id=" + other)
                with self.assertRaises(HTTPError):
                    request(base, "api/artifact?path=" + other + "/task.json")
                def rpc(method, params):
                    return request(base, "mcp", dict(jsonrpc="2.0", id=1, method=method, params=params))
                def call(name, **args):
                    return rpc("tools/call", {"name": name, "arguments": args})
                init = rpc("initialize", dict(clientInfo={"name":"test","version":"1"},
                                              capabilities={}, protocolVersion="2025-11-25"))
                self.assertEqual(init["result"]["capabilities"], {"tools": {}})
                self.assertEqual(init["result"]["serverInfo"]["name"], "workbench")
                names = [t["name"] for t in rpc("tools/list", {})["result"]["tools"]]
                self.assertIn("app_label", names)
                self.assertIn("project_capabilities", names)
                registered = {tool["name"] for tool in request(base, "api/app-tools") if tool["app"]}
                self.assertEqual(registered, {"app_label", "app_hidden"})
                catalog = request(base, "api/project-capabilities")
                self.assertEqual(call("project_capabilities")["result"]["structuredContent"], catalog)
                self.assertEqual(catalog["schema_version"], 1)
                self.assertNotIn("app_hidden", names)
                self.assertEqual(call("inspect_run")["result"]["structuredContent"]["ids"], [owner])
                self.assertTrue(call("inspect_run", runId=other)["result"]["isError"])
                self.assertEqual(call("set_repair_budget", profile="fast", value=6)["result"]["structuredContent"]["value"], 6)
                self.assertEqual(request(base, "api/profile")["profiles"]["fast"]["stages"]["buildReview"]["limit"], 6)
                self.assertEqual(cli(second, "setup", "profile-export")["profiles"]["fast"]["stages"]["buildReview"]["limit"], 1)
                self.assertIn("error", call("app_hidden", label="blue"))
                self.assertTrue(call("app_label", label=1)["result"]["isError"])
                self.assertTrue(call("app_label", label="red")["result"]["isError"])
                self.assertFalse((first / ".harness/calls.txt").exists())
                self.assertEqual(call("app_label", label="blue")["result"]["structuredContent"], {"label":"blue"})
                self.assertEqual((first / ".harness/calls.txt").read_text(), "blue")
                self.assertEqual(records(), before)
            finally:
                proc.stdin.close()
                proc.wait(timeout=20)
