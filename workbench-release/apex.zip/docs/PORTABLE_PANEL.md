# Portable harness panel

For the standalone project picker and workspace MCP tools, use the [project workspace](PROJECTS.md).

Use Ruby 3.1+, Python 3.10+, and Node 22+. Put each runtime and selected agent CLI on PATH.
Use the existing local Codex and Muse sign-ins.

## Install and launch

Run these PowerShell commands from the Workbench distribution. Set the project to your app directory.

```powershell
$project = (Resolve-Path ../my-app).Path
ruby bin/harness setup install --project "$project"
python server.py --bound --project "$project" --port 8792
```

Open http://127.0.0.1:8792/__workbench/ for the panel. Open http://127.0.0.1:8792/ for native Workbench.
Use **Project setup** to configure checks and benchmark contracts. Launch without `--bound` for standalone project selection.
Stop active jobs before upgrading. Repeat the install command from the distribution.
The installer retains project configuration, engine pins, task evidence, and loop history.

## Design and run

1. Open **Stage designer** from **Design** to configure agents, profiles, and stages. Both profiles use the V2.10 preset.
2. Upload text files in **Documents**. Assign them to a stage or to **Shared rules**.
3. Open **Preview instructions** to inspect the shared rules, stage instructions, and assigned documents.
4. Use **Shared rules** to inspect check commands and permitted app tool names. Each check uses literal arguments.
5. Select **Apply profile**. The server validates both profiles. New tasks pin the applied profile and digest.
6. In **Live run**, enter the action and scope. Record each required decision. Select **Run task**.
7. Select a suggested answer or type your own. Submit the answer to resume the same task.
8. Use **History** to inspect previous runs. The native **Task runs** view provides artifact reads.

Codex supports planning, building, and audits. Muse supports read-only planning and audits.
An empty Codex model uses the configured project model. Muse supports its CLI default model.
Each Codex or Muse stage uses the reasoning effort pinned when the task starts.
Workbench passes that value to Muse with `--reasoning-effort`, including when Muse selects its default model.
Workbench finds Muse on PATH, including Windows command launchers. Set `APEX_MUSE_EXECUTABLE` to choose another executable.
Audit and refactor profiles require baseline and after phases for each check.
Unsupported stage assignments fail on apply. Gate stages execute the configured checks and verification.
Use **Simulate run** to inspect return routes and limits.

Fast can disable the final audit. Its build reviewer must then supply six quality criteria.
The immutable skip records the profile digest, plan digest, and checked snapshot.
Audited requires passing plan, build, and final audits. Existing manual tasks keep their original workflow.

Run `setup profile-disable --project PATH` to use the native project workflow for future tasks.
Apply the saved profile to enable it again.

Use the installed coordinator to run or resume an agreed task from the CLI.

```powershell
ruby "$project/.harness/bin/harness" loop --project "$project"
ruby "$project/.harness/bin/harness" loop --project "$project" --answer "Use the approved label"
```

## Export and import

Use **Export profile** to download draft JSON or the installed kit.
The kit includes the applied profiles and their documents. **Import** loads Factory v1 JSON.
Select **Apply profile** to save the imported draft. Profiles without checks inherit the destination checks.

```powershell
ruby bin/harness setup profile-export --project "$project" | Set-Content -Encoding utf8NoBOM profile.json
$profileFile = (Resolve-Path profile.json).Path
ruby bin/harness setup profile-import --project "$project" --file "$profileFile"
python portable/package.py ../workbench-kit.zip --project "$project"
python -m zipfile -e ../workbench-kit.zip ../workbench-kit
Set-Location ../workbench-kit
$destination = (Resolve-Path ../second-app).Path
$profileFile = (Resolve-Path project-profile.json).Path
ruby bin/harness setup install --project "$destination"
ruby bin/harness setup profile-import --project "$destination" --file "$profileFile"
```

The archive contains manifest-selected files and the exported profile. Omit `--project` for a runtime-only archive.
Review uploaded text and check arguments before export. Supply credentials through the host environment.
Supply referenced check scripts in the destination app. The destination keeps its own engine configuration.

## Mount in Node

Start a project-bound Node host at http://127.0.0.1:8794/__workbench/.

```powershell
node "$destination/.harness/portable/mount.cjs" "$destination" 8794
```

Mount the panel beside an existing Node HTTP request handler. Pass the selected project directory and your app handler to this function.
Listen on the returned server with a loopback address.

```javascript
const {createServer} = require("node:http");
const {mountWorkbench} = require("./.harness/portable/mount.cjs");

async function createAppServer(projectDirectory, appHandler) {
  const panel = await mountWorkbench(projectDirectory);
  const server = createServer((req, res) => {
    if (!panel.handle(req, res)) appHandler(req, res);
  });
  server.on("close", panel.close);
  return server;
}
module.exports = {createAppServer};
```

## MCP and activity

Use Streamable HTTP at http://127.0.0.1:8794/__workbench/mcp.
Initialize, send the initialized notification, and call `tools/list`.
Use `get_profile`, `inspect_run`, `set_repair_budget`, and `set_builder_effort`.
Settings changes apply to future tasks.

For an app-specific tool, create a host-owned CommonJS registry such as `tools.cjs`.

```javascript
module.exports = [{
  name: "app_label",
  description: "Return a display label for a project status.",
  inputSchema: {
    type: "object", additionalProperties: false, required: ["status"],
    properties: {status: {type: "string", enum: ["ready", "waiting"]}}
  },
  handle({status}) { return {label: status.toUpperCase()}; }
}];
```

Add `app_label` under **Permitted app tool names** and apply. Start the host with the registry argument.

```powershell
node "$destination/.harness/portable/mount.cjs" "$destination" 8794 tools.cjs
```

Embedded hosts pass `{appTools: "tools.cjs"}` to `mountWorkbench`.
Use flat string, boolean, or integer arguments. The contract supports enum values and integer limits.
The host supplies handlers. The profile selects permitted names.

Read `api/events?id=TASK_ID&after=0` relative to the panel URL.
Pass the returned cursor to the next request. Each page contains up to 200 complete events.
Events identify the run, issuing stage, actor, timestamp, and public activity.
Legacy runs retain their original history. New activity appends under `.harness/loops/<id>/activity.jsonl`.

## Project Design workspace

Open Design in the project panel. The standalone server and mounted panel use the same project records.
Choose stacked or side-by-side panes. Each project stores its view, tab, and pane layout.

Use the project conversation to edit the draft with the configured planning agent.
Save a draft revision before approving its milestones and slices.
Select a suggested answer, change its text, and submit it. Selecting a suggestion leaves the question pending.

Use **Generate mockup** to generate a PNG from the conversation and draft.
Use a signed-in Codex CLI with image generation, or set `OPENAI_API_KEY` for the Images API.
Set `WORKBENCH_IMAGE_MODEL` to choose the Images API model.
Select a version to revise or attach to a slice.
Enter the project app address in **Preview** to use the running app.

Apply a build profile. Select **Start build** on the Plan tab.
Choose a slice, milestone, or the whole plan. Set the review frequency separately.
Review defaults to each slice. The coordinator records each stage and commits checked changes locally.
Workbench keeps pre-existing tracked and untracked changes out of slice commits.
Keep these changes as they were when you started the build.
Open any stage to inspect its steps. The spinner follows the active coordinator.
Connect Branch Review to the same project under **Build**.
Open its human checklist. Inspect the diff, check results, and attached mockups.
Record a finding against the affected slices to request repair.
Approve the exact commit in Branch Review to close the group.
Use **Push to GitHub** to push that commit to the displayed repository and branch. Select **Continue** to advance.

Open [Quality](QUALITY.md) to edit reusable checks, benchmarks, and rubrics.
Run a trial on committed refs and inspect the evidence before publishing the policy.
Use the project MCP endpoint to read or propose a Quality draft, validate it, run a published policy, or export trial evidence.

Design records and PNG versions live under `.harness/design/`.
Each build links its slice attempts to native task and coordinator records.
Open History to inspect the steps, attempts, outcomes, and return reasons.
