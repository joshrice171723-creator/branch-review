# Workbench projects

Open one workspace for several local projects. Each project has its own profile, checks, work directories, and run history.

## Open the workspace

From the extracted distribution, run the following command. Replace the example path with an existing directory.

```powershell
node portable/workspace.cjs "C:\projects\my-app" 8794
```

Open [Workbench projects](http://127.0.0.1:8794/__workbench/). Choose **Add project** to register another directory.
The standalone launcher stores the project list in the platform state directory. Set `APEX_WORKSPACE_HOME` to choose another location.

In **Environment**, select **Prepare environment**. Workbench installs its runtime, applies the profile, and creates managed work directories.
It retains existing check definitions. For a new project, it can suggest npm, Python, Go, Cargo, or Rails tests.
A project can supply its own check commands through the profile. Use **Workbench** to configure its agents or start a task.

## Connect an MCP client

Use Streamable HTTP at `http://127.0.0.1:8794/__workbench/projects/mcp`.
Call `add_project` with an absolute directory. Use the returned `id` as `projectId` for subsequent calls.

| Tool | Purpose |
|---|---|
| `list_projects` and `select_project` | Find a project and obtain its bound panel URL. |
| `inspect_environment` | Read installed tools, engine, checks, active task, and work directories. |
| `prepare_environment` | Install the runtime, apply a profile, and prepare scratch and temporary directories. |
| `get_project_profile` and `apply_project_profile` | Read or apply the executable profile for future tasks. |
| `configure_project_checks` | Update inherited check definitions and their entries in the saved profile. |
| `preview_cleanup` and `clean_environment` | Inspect managed entries, then remove the entries from that preview. |

Pass `checks` to supply explicit check definitions. Set `discoverChecks` to `false` to skip automatic suggestions.
Set `upgradeRuntime` to `true` to refresh an existing runtime. Finish or pause active work before setup or cleanup.
The bound runner receives its own `TEMP`, `TMP`, `TMPDIR`, and `APEX_WORKSPACE_SCRATCH` paths.

For cleanup, pass the returned `previewId` and `projectId` to `clean_environment`.
Workbench checks the ownership marker and the current inventory before deleting files under `.harness/workspace-env/scratch` and `tmp`.
Project source, Git changes, profiles, and run evidence have separate locations.

## Embed Workbench

Use `mountWorkbench(project)` for a panel bound to one project. Use `mountWorkspace(initialProject, options)` for a project picker.
Both use the same panel assets and runner. A workspace may register app tools for its initial project through `options.appTools`.
The launcher exposes workspace MCP separately from each project's MCP endpoint.

A local host can register a completed-run action under `.harness/hosts/`. Store a JSON file with `version: 1`, a display `name`, and a loopback HTTP `url`.
History adds the selected run ID as `workbenchRun` when opening that host. The host validates the run and project before using it.
