# Project Quality

Use Quality to define checks, benchmarks, and review rubrics for one project. Start from the existing project checks when a project has no Quality policy. Configure benchmark metrics and thresholds in Quality. Legacy benchmark contracts continue to apply to legacy tasks.

## Define and publish a policy

1. Open Quality and edit the draft. Keep IDs stable when you change names or instructions.
2. Test the draft against one or two committed Git refs. Use an approved revision and a known failing revision when available.
3. Inspect results, fixtures, and raw output. Resolve infrastructure errors and repeat the trial.
4. Publish the tested draft. Explicitly confirm a completed trial with failed checks or thresholds.
5. Commit the published workbench-quality.json in the host project to share the policy.

Publication requires a human action in the Workbench panel. Agents can submit drafts. Agent trials use the committed policy. Each trial records its definition and revision. Publication records identify the exact trial. The local .harness/quality directory keeps drafts, trial evidence, and publication history. Git records policy history when you commit the policy file.

## Define checks and benchmarks

Give checks an argv array, a project-relative working directory, and a timeout. Mark checks required when they must pass. Run baseline and after checks for refactors and audits. Feature and build tasks can also use after-only checks.

Each benchmark uses one check with baseline and after phases. Define the fixture files, workload scripts, numeric metrics, units, repetition count, reset command, and thresholds. The reset command runs before each measurement. A reset can construct generated fixtures. List files that define the workload so the trial can verify their hashes.

Write an object such as {"metrics":{"rows":50,"elapsed":13.2}} on the final nonempty stdout line. Include one numeric value per declared metric. Values must use the declared units. Workbench applies mean, median, min, or max before evaluating thresholds. Threshold operators are lte, gte, and eq.

Each trial runs in a disposable committed export. The result records exact commit SHAs, local environment, fixture and script hashes, samples, unit values, thresholds, and bounded raw output. The trial rejects a comparison if declared fixtures or scripts differ between refs. Use scripts and synthetic fixtures that work in a fresh export. Commands run with the local runner's operating system privileges.

## Review a task

New tasks pin the active Quality definition when they start. The workflow profile still controls stage assignments. Tasks with a pin use it for baseline, after checks, and audit receipts. Existing tasks keep their own settings and pins.

Define agent rubrics for plan, build, or final review. The audit must cite evidence for each required criterion in the pinned rubric. Workbench uses its existing review criteria when no custom rubric applies. Use a human Branch Review rubric for the independent review of the exact commit.

## Read or propose through the CLI

Run python quality.py status --project PROJECT to get the draft revision and publication. Other commands read JSON from stdin. Use validate with definition. Use draft with definition, base_revision, and expected_revision. Set base_revision to the publication revision or null. Set expected_revision to the draft revision you read. These values prevent overwriting a changed policy or draft.

Use trial with revision, refs, and policy set to published. The policy file must match the committed copy. Use evidence, export, or version with id. Export omits raw output and includes structured check results, metrics, source paths, and publication review metadata.


## Prepare Quality from a route

Open Prepare and select a Git-tracked HTTP route or Electron IPC channel. Enter the method and path manually when discovery misses a route. For a manual route, provide a tracked source file that contains the path or channel.

Prepare shows its source locations, traced implementation boundaries, and candidate data operations. Read the coverage gaps before relying on the trace. Static inspection does not execute requests or verify which queries run. A listed native test mentions the route. Its behavior and fixture coverage still require review.

Select Refresh Rails routes to observe an installed Rails application's route table. Rails loads the application without dispatching a request. Workbench reuses the observation while the tracked Rails source and commit match. Controller-only routes receive a controller source guard and disclose the missing declaration.

Prepare adds an after-only source guard and review criteria to the draft. The check can run in a fresh committed export. Prepare preserves earlier edits to the same check or criterion. Publish through the normal Quality flow after reviewing and testing the draft. Define benchmarks separately when the project has a measurement runner and controlled fixtures.
